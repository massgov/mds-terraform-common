"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/pino-std-serializers/lib/err-helpers.js
var require_err_helpers = __commonJS({
  "node_modules/pino-std-serializers/lib/err-helpers.js"(exports, module2) {
    "use strict";
    var isErrorLike = (err) => {
      return err && typeof err.message === "string";
    };
    var getErrorCause = (err) => {
      if (!err)
        return;
      const cause = err.cause;
      if (typeof cause === "function") {
        const causeResult = err.cause();
        return isErrorLike(causeResult) ? causeResult : void 0;
      } else {
        return isErrorLike(cause) ? cause : void 0;
      }
    };
    var _stackWithCauses = (err, seen) => {
      if (!isErrorLike(err))
        return "";
      const stack = err.stack || "";
      if (seen.has(err)) {
        return stack + "\ncauses have become circular...";
      }
      const cause = getErrorCause(err);
      if (cause) {
        seen.add(err);
        return stack + "\ncaused by: " + _stackWithCauses(cause, seen);
      } else {
        return stack;
      }
    };
    var stackWithCauses = (err) => _stackWithCauses(err, /* @__PURE__ */ new Set());
    var _messageWithCauses = (err, seen, skip) => {
      if (!isErrorLike(err))
        return "";
      const message = skip ? "" : err.message || "";
      if (seen.has(err)) {
        return message + ": ...";
      }
      const cause = getErrorCause(err);
      if (cause) {
        seen.add(err);
        const skipIfVErrorStyleCause = typeof err.cause === "function";
        return message + (skipIfVErrorStyleCause ? "" : ": ") + _messageWithCauses(cause, seen, skipIfVErrorStyleCause);
      } else {
        return message;
      }
    };
    var messageWithCauses = (err) => _messageWithCauses(err, /* @__PURE__ */ new Set());
    module2.exports = {
      isErrorLike,
      getErrorCause,
      stackWithCauses,
      messageWithCauses
    };
  }
});

// node_modules/pino-std-serializers/lib/err-proto.js
var require_err_proto = __commonJS({
  "node_modules/pino-std-serializers/lib/err-proto.js"(exports, module2) {
    "use strict";
    var seen = Symbol("circular-ref-tag");
    var rawSymbol = Symbol("pino-raw-err-ref");
    var pinoErrProto = Object.create({}, {
      type: {
        enumerable: true,
        writable: true,
        value: void 0
      },
      message: {
        enumerable: true,
        writable: true,
        value: void 0
      },
      stack: {
        enumerable: true,
        writable: true,
        value: void 0
      },
      aggregateErrors: {
        enumerable: true,
        writable: true,
        value: void 0
      },
      raw: {
        enumerable: false,
        get: function() {
          return this[rawSymbol];
        },
        set: function(val) {
          this[rawSymbol] = val;
        }
      }
    });
    Object.defineProperty(pinoErrProto, rawSymbol, {
      writable: true,
      value: {}
    });
    module2.exports = {
      pinoErrProto,
      pinoErrorSymbols: {
        seen,
        rawSymbol
      }
    };
  }
});

// node_modules/pino-std-serializers/lib/err.js
var require_err = __commonJS({
  "node_modules/pino-std-serializers/lib/err.js"(exports, module2) {
    "use strict";
    module2.exports = errSerializer;
    var { messageWithCauses, stackWithCauses, isErrorLike } = require_err_helpers();
    var { pinoErrProto, pinoErrorSymbols } = require_err_proto();
    var { seen } = pinoErrorSymbols;
    var { toString } = Object.prototype;
    function errSerializer(err) {
      if (!isErrorLike(err)) {
        return err;
      }
      err[seen] = void 0;
      const _err = Object.create(pinoErrProto);
      _err.type = toString.call(err.constructor) === "[object Function]" ? err.constructor.name : err.name;
      _err.message = messageWithCauses(err);
      _err.stack = stackWithCauses(err);
      if (Array.isArray(err.errors)) {
        _err.aggregateErrors = err.errors.map((err2) => errSerializer(err2));
      }
      for (const key in err) {
        if (_err[key] === void 0) {
          const val = err[key];
          if (isErrorLike(val)) {
            if (key !== "cause" && !Object.prototype.hasOwnProperty.call(val, seen)) {
              _err[key] = errSerializer(val);
            }
          } else {
            _err[key] = val;
          }
        }
      }
      delete err[seen];
      _err.raw = err;
      return _err;
    }
  }
});

// node_modules/pino-std-serializers/lib/err-with-cause.js
var require_err_with_cause = __commonJS({
  "node_modules/pino-std-serializers/lib/err-with-cause.js"(exports, module2) {
    "use strict";
    module2.exports = errWithCauseSerializer;
    var { isErrorLike } = require_err_helpers();
    var { pinoErrProto, pinoErrorSymbols } = require_err_proto();
    var { seen } = pinoErrorSymbols;
    var { toString } = Object.prototype;
    function errWithCauseSerializer(err) {
      if (!isErrorLike(err)) {
        return err;
      }
      err[seen] = void 0;
      const _err = Object.create(pinoErrProto);
      _err.type = toString.call(err.constructor) === "[object Function]" ? err.constructor.name : err.name;
      _err.message = err.message;
      _err.stack = err.stack;
      if (Array.isArray(err.errors)) {
        _err.aggregateErrors = err.errors.map((err2) => errWithCauseSerializer(err2));
      }
      if (isErrorLike(err.cause) && !Object.prototype.hasOwnProperty.call(err.cause, seen)) {
        _err.cause = errWithCauseSerializer(err.cause);
      }
      for (const key in err) {
        if (_err[key] === void 0) {
          const val = err[key];
          if (isErrorLike(val)) {
            if (!Object.prototype.hasOwnProperty.call(val, seen)) {
              _err[key] = errWithCauseSerializer(val);
            }
          } else {
            _err[key] = val;
          }
        }
      }
      delete err[seen];
      _err.raw = err;
      return _err;
    }
  }
});

// node_modules/pino-std-serializers/lib/req.js
var require_req = __commonJS({
  "node_modules/pino-std-serializers/lib/req.js"(exports, module2) {
    "use strict";
    module2.exports = {
      mapHttpRequest,
      reqSerializer
    };
    var rawSymbol = Symbol("pino-raw-req-ref");
    var pinoReqProto = Object.create({}, {
      id: {
        enumerable: true,
        writable: true,
        value: ""
      },
      method: {
        enumerable: true,
        writable: true,
        value: ""
      },
      url: {
        enumerable: true,
        writable: true,
        value: ""
      },
      query: {
        enumerable: true,
        writable: true,
        value: ""
      },
      params: {
        enumerable: true,
        writable: true,
        value: ""
      },
      headers: {
        enumerable: true,
        writable: true,
        value: {}
      },
      remoteAddress: {
        enumerable: true,
        writable: true,
        value: ""
      },
      remotePort: {
        enumerable: true,
        writable: true,
        value: ""
      },
      raw: {
        enumerable: false,
        get: function() {
          return this[rawSymbol];
        },
        set: function(val) {
          this[rawSymbol] = val;
        }
      }
    });
    Object.defineProperty(pinoReqProto, rawSymbol, {
      writable: true,
      value: {}
    });
    function reqSerializer(req) {
      const connection = req.info || req.socket;
      const _req = Object.create(pinoReqProto);
      _req.id = typeof req.id === "function" ? req.id() : req.id || (req.info ? req.info.id : void 0);
      _req.method = req.method;
      if (req.originalUrl) {
        _req.url = req.originalUrl;
      } else {
        const path = req.path;
        _req.url = typeof path === "string" ? path : req.url ? req.url.path || req.url : void 0;
      }
      if (req.query) {
        _req.query = req.query;
      }
      if (req.params) {
        _req.params = req.params;
      }
      _req.headers = req.headers;
      _req.remoteAddress = connection && connection.remoteAddress;
      _req.remotePort = connection && connection.remotePort;
      _req.raw = req.raw || req;
      return _req;
    }
    function mapHttpRequest(req) {
      return {
        req: reqSerializer(req)
      };
    }
  }
});

// node_modules/pino-std-serializers/lib/res.js
var require_res = __commonJS({
  "node_modules/pino-std-serializers/lib/res.js"(exports, module2) {
    "use strict";
    module2.exports = {
      mapHttpResponse,
      resSerializer
    };
    var rawSymbol = Symbol("pino-raw-res-ref");
    var pinoResProto = Object.create({}, {
      statusCode: {
        enumerable: true,
        writable: true,
        value: 0
      },
      headers: {
        enumerable: true,
        writable: true,
        value: ""
      },
      raw: {
        enumerable: false,
        get: function() {
          return this[rawSymbol];
        },
        set: function(val) {
          this[rawSymbol] = val;
        }
      }
    });
    Object.defineProperty(pinoResProto, rawSymbol, {
      writable: true,
      value: {}
    });
    function resSerializer(res) {
      const _res = Object.create(pinoResProto);
      _res.statusCode = res.headersSent ? res.statusCode : null;
      _res.headers = res.getHeaders ? res.getHeaders() : res._headers;
      _res.raw = res;
      return _res;
    }
    function mapHttpResponse(res) {
      return {
        res: resSerializer(res)
      };
    }
  }
});

// node_modules/pino-std-serializers/index.js
var require_pino_std_serializers = __commonJS({
  "node_modules/pino-std-serializers/index.js"(exports, module2) {
    "use strict";
    var errSerializer = require_err();
    var errWithCauseSerializer = require_err_with_cause();
    var reqSerializers = require_req();
    var resSerializers = require_res();
    module2.exports = {
      err: errSerializer,
      errWithCause: errWithCauseSerializer,
      mapHttpRequest: reqSerializers.mapHttpRequest,
      mapHttpResponse: resSerializers.mapHttpResponse,
      req: reqSerializers.reqSerializer,
      res: resSerializers.resSerializer,
      wrapErrorSerializer: function wrapErrorSerializer(customSerializer) {
        if (customSerializer === errSerializer)
          return customSerializer;
        return function wrapErrSerializer(err) {
          return customSerializer(errSerializer(err));
        };
      },
      wrapRequestSerializer: function wrapRequestSerializer(customSerializer) {
        if (customSerializer === reqSerializers.reqSerializer)
          return customSerializer;
        return function wrappedReqSerializer(req) {
          return customSerializer(reqSerializers.reqSerializer(req));
        };
      },
      wrapResponseSerializer: function wrapResponseSerializer(customSerializer) {
        if (customSerializer === resSerializers.resSerializer)
          return customSerializer;
        return function wrappedResSerializer(res) {
          return customSerializer(resSerializers.resSerializer(res));
        };
      }
    };
  }
});

// node_modules/pino/lib/caller.js
var require_caller = __commonJS({
  "node_modules/pino/lib/caller.js"(exports, module2) {
    "use strict";
    function noOpPrepareStackTrace(_, stack) {
      return stack;
    }
    module2.exports = function getCallers() {
      const originalPrepare = Error.prepareStackTrace;
      Error.prepareStackTrace = noOpPrepareStackTrace;
      const stack = new Error().stack;
      Error.prepareStackTrace = originalPrepare;
      if (!Array.isArray(stack)) {
        return void 0;
      }
      const entries = stack.slice(2);
      const fileNames = [];
      for (const entry of entries) {
        if (!entry) {
          continue;
        }
        fileNames.push(entry.getFileName());
      }
      return fileNames;
    };
  }
});

// node_modules/fast-redact/lib/validator.js
var require_validator = __commonJS({
  "node_modules/fast-redact/lib/validator.js"(exports, module2) {
    "use strict";
    module2.exports = validator;
    function validator(opts = {}) {
      const {
        ERR_PATHS_MUST_BE_STRINGS = () => "fast-redact - Paths must be (non-empty) strings",
        ERR_INVALID_PATH = (s) => `fast-redact \u2013 Invalid path (${s})`
      } = opts;
      return function validate({ paths }) {
        paths.forEach((s) => {
          if (typeof s !== "string") {
            throw Error(ERR_PATHS_MUST_BE_STRINGS());
          }
          try {
            if (/〇/.test(s))
              throw Error();
            const expr = (s[0] === "[" ? "" : ".") + s.replace(/^\*/, "\u3007").replace(/\.\*/g, ".\u3007").replace(/\[\*\]/g, "[\u3007]");
            if (/\n|\r|;/.test(expr))
              throw Error();
            if (/\/\*/.test(expr))
              throw Error();
            Function(`
            'use strict'
            const o = new Proxy({}, { get: () => o, set: () => { throw Error() } });
            const \u3007 = null;
            o${expr}
            if ([o${expr}].length !== 1) throw Error()`)();
          } catch (e) {
            throw Error(ERR_INVALID_PATH(s));
          }
        });
      };
    }
  }
});

// node_modules/fast-redact/lib/rx.js
var require_rx = __commonJS({
  "node_modules/fast-redact/lib/rx.js"(exports, module2) {
    "use strict";
    module2.exports = /[^.[\]]+|\[((?:.)*?)\]/g;
  }
});

// node_modules/fast-redact/lib/parse.js
var require_parse = __commonJS({
  "node_modules/fast-redact/lib/parse.js"(exports, module2) {
    "use strict";
    var rx = require_rx();
    module2.exports = parse;
    function parse({ paths }) {
      const wildcards = [];
      var wcLen = 0;
      const secret = paths.reduce(function(o, strPath, ix) {
        var path = strPath.match(rx).map((p) => p.replace(/'|"|`/g, ""));
        const leadingBracket = strPath[0] === "[";
        path = path.map((p) => {
          if (p[0] === "[")
            return p.substr(1, p.length - 2);
          else
            return p;
        });
        const star = path.indexOf("*");
        if (star > -1) {
          const before = path.slice(0, star);
          const beforeStr = before.join(".");
          const after = path.slice(star + 1, path.length);
          const nested = after.length > 0;
          wcLen++;
          wildcards.push({
            before,
            beforeStr,
            after,
            nested
          });
        } else {
          o[strPath] = {
            path,
            val: void 0,
            precensored: false,
            circle: "",
            escPath: JSON.stringify(strPath),
            leadingBracket
          };
        }
        return o;
      }, {});
      return { wildcards, wcLen, secret };
    }
  }
});

// node_modules/fast-redact/lib/redactor.js
var require_redactor = __commonJS({
  "node_modules/fast-redact/lib/redactor.js"(exports, module2) {
    "use strict";
    var rx = require_rx();
    module2.exports = redactor;
    function redactor({ secret, serialize, wcLen, strict, isCensorFct, censorFctTakesPath }, state) {
      const redact = Function("o", `
    if (typeof o !== 'object' || o == null) {
      ${strictImpl(strict, serialize)}
    }
    const { censor, secret } = this
    ${redactTmpl(secret, isCensorFct, censorFctTakesPath)}
    this.compileRestore()
    ${dynamicRedactTmpl(wcLen > 0, isCensorFct, censorFctTakesPath)}
    ${resultTmpl(serialize)}
  `).bind(state);
      if (serialize === false) {
        redact.restore = (o) => state.restore(o);
      }
      return redact;
    }
    function redactTmpl(secret, isCensorFct, censorFctTakesPath) {
      return Object.keys(secret).map((path) => {
        const { escPath, leadingBracket, path: arrPath } = secret[path];
        const skip = leadingBracket ? 1 : 0;
        const delim = leadingBracket ? "" : ".";
        const hops = [];
        var match;
        while ((match = rx.exec(path)) !== null) {
          const [, ix] = match;
          const { index, input } = match;
          if (index > skip)
            hops.push(input.substring(0, index - (ix ? 0 : 1)));
        }
        var existence = hops.map((p) => `o${delim}${p}`).join(" && ");
        if (existence.length === 0)
          existence += `o${delim}${path} != null`;
        else
          existence += ` && o${delim}${path} != null`;
        const circularDetection = `
      switch (true) {
        ${hops.reverse().map((p) => `
          case o${delim}${p} === censor:
            secret[${escPath}].circle = ${JSON.stringify(p)}
            break
        `).join("\n")}
      }
    `;
        const censorArgs = censorFctTakesPath ? `val, ${JSON.stringify(arrPath)}` : `val`;
        return `
      if (${existence}) {
        const val = o${delim}${path}
        if (val === censor) {
          secret[${escPath}].precensored = true
        } else {
          secret[${escPath}].val = val
          o${delim}${path} = ${isCensorFct ? `censor(${censorArgs})` : "censor"}
          ${circularDetection}
        }
      }
    `;
      }).join("\n");
    }
    function dynamicRedactTmpl(hasWildcards, isCensorFct, censorFctTakesPath) {
      return hasWildcards === true ? `
    {
      const { wildcards, wcLen, groupRedact, nestedRedact } = this
      for (var i = 0; i < wcLen; i++) {
        const { before, beforeStr, after, nested } = wildcards[i]
        if (nested === true) {
          secret[beforeStr] = secret[beforeStr] || []
          nestedRedact(secret[beforeStr], o, before, after, censor, ${isCensorFct}, ${censorFctTakesPath})
        } else secret[beforeStr] = groupRedact(o, before, censor, ${isCensorFct}, ${censorFctTakesPath})
      }
    }
  ` : "";
    }
    function resultTmpl(serialize) {
      return serialize === false ? `return o` : `
    var s = this.serialize(o)
    this.restore(o)
    return s
  `;
    }
    function strictImpl(strict, serialize) {
      return strict === true ? `throw Error('fast-redact: primitives cannot be redacted')` : serialize === false ? `return o` : `return this.serialize(o)`;
    }
  }
});

// node_modules/fast-redact/lib/modifiers.js
var require_modifiers = __commonJS({
  "node_modules/fast-redact/lib/modifiers.js"(exports, module2) {
    "use strict";
    module2.exports = {
      groupRedact,
      groupRestore,
      nestedRedact,
      nestedRestore
    };
    function groupRestore({ keys, values, target }) {
      if (target == null)
        return;
      const length = keys.length;
      for (var i = 0; i < length; i++) {
        const k = keys[i];
        target[k] = values[i];
      }
    }
    function groupRedact(o, path, censor, isCensorFct, censorFctTakesPath) {
      const target = get(o, path);
      if (target == null)
        return { keys: null, values: null, target: null, flat: true };
      const keys = Object.keys(target);
      const keysLength = keys.length;
      const pathLength = path.length;
      const pathWithKey = censorFctTakesPath ? [...path] : void 0;
      const values = new Array(keysLength);
      for (var i = 0; i < keysLength; i++) {
        const key = keys[i];
        values[i] = target[key];
        if (censorFctTakesPath) {
          pathWithKey[pathLength] = key;
          target[key] = censor(target[key], pathWithKey);
        } else if (isCensorFct) {
          target[key] = censor(target[key]);
        } else {
          target[key] = censor;
        }
      }
      return { keys, values, target, flat: true };
    }
    function nestedRestore(instructions) {
      for (let i = 0; i < instructions.length; i++) {
        const { target, path, value } = instructions[i];
        let current = target;
        for (let i2 = path.length - 1; i2 > 0; i2--) {
          current = current[path[i2]];
        }
        current[path[0]] = value;
      }
    }
    function nestedRedact(store, o, path, ns, censor, isCensorFct, censorFctTakesPath) {
      const target = get(o, path);
      if (target == null)
        return;
      const keys = Object.keys(target);
      const keysLength = keys.length;
      for (var i = 0; i < keysLength; i++) {
        const key = keys[i];
        specialSet(store, target, key, path, ns, censor, isCensorFct, censorFctTakesPath);
      }
      return store;
    }
    function has(obj, prop) {
      return obj !== void 0 && obj !== null ? "hasOwn" in Object ? Object.hasOwn(obj, prop) : Object.prototype.hasOwnProperty.call(obj, prop) : false;
    }
    function specialSet(store, o, k, path, afterPath, censor, isCensorFct, censorFctTakesPath) {
      const afterPathLen = afterPath.length;
      const lastPathIndex = afterPathLen - 1;
      const originalKey = k;
      var i = -1;
      var n;
      var nv;
      var ov;
      var oov = null;
      var wc = null;
      var kIsWc;
      var wcov;
      var consecutive = false;
      var level = 0;
      var depth = 0;
      var redactPathCurrent = tree();
      ov = n = o[k];
      if (typeof n !== "object")
        return;
      while (n != null && ++i < afterPathLen) {
        depth += 1;
        k = afterPath[i];
        oov = ov;
        if (k !== "*" && !wc && !(typeof n === "object" && k in n)) {
          break;
        }
        if (k === "*") {
          if (wc === "*") {
            consecutive = true;
          }
          wc = k;
          if (i !== lastPathIndex) {
            continue;
          }
        }
        if (wc) {
          const wcKeys = Object.keys(n);
          for (var j = 0; j < wcKeys.length; j++) {
            const wck = wcKeys[j];
            wcov = n[wck];
            kIsWc = k === "*";
            if (consecutive) {
              redactPathCurrent = node(redactPathCurrent, wck, depth);
              level = i;
              ov = iterateNthLevel(wcov, level - 1, k, path, afterPath, censor, isCensorFct, censorFctTakesPath, originalKey, n, nv, ov, kIsWc, wck, i, lastPathIndex, redactPathCurrent, store, o[originalKey], depth + 1);
            } else {
              if (kIsWc || typeof wcov === "object" && wcov !== null && k in wcov) {
                if (kIsWc) {
                  ov = wcov;
                } else {
                  ov = wcov[k];
                }
                nv = i !== lastPathIndex ? ov : isCensorFct ? censorFctTakesPath ? censor(ov, [...path, originalKey, ...afterPath]) : censor(ov) : censor;
                if (kIsWc) {
                  const rv = restoreInstr(node(redactPathCurrent, wck, depth), ov, o[originalKey]);
                  store.push(rv);
                  n[wck] = nv;
                } else {
                  if (wcov[k] === nv) {
                  } else if (nv === void 0 && censor !== void 0 || has(wcov, k) && nv === ov) {
                    redactPathCurrent = node(redactPathCurrent, wck, depth);
                  } else {
                    redactPathCurrent = node(redactPathCurrent, wck, depth);
                    const rv = restoreInstr(node(redactPathCurrent, k, depth + 1), ov, o[originalKey]);
                    store.push(rv);
                    wcov[k] = nv;
                  }
                }
              }
            }
          }
          wc = null;
        } else {
          ov = n[k];
          redactPathCurrent = node(redactPathCurrent, k, depth);
          nv = i !== lastPathIndex ? ov : isCensorFct ? censorFctTakesPath ? censor(ov, [...path, originalKey, ...afterPath]) : censor(ov) : censor;
          if (has(n, k) && nv === ov || nv === void 0 && censor !== void 0) {
          } else {
            const rv = restoreInstr(redactPathCurrent, ov, o[originalKey]);
            store.push(rv);
            n[k] = nv;
          }
          n = n[k];
        }
        if (typeof n !== "object")
          break;
        if (ov === oov || typeof ov === "undefined") {
        }
      }
    }
    function get(o, p) {
      var i = -1;
      var l = p.length;
      var n = o;
      while (n != null && ++i < l) {
        n = n[p[i]];
      }
      return n;
    }
    function iterateNthLevel(wcov, level, k, path, afterPath, censor, isCensorFct, censorFctTakesPath, originalKey, n, nv, ov, kIsWc, wck, i, lastPathIndex, redactPathCurrent, store, parent, depth) {
      if (level === 0) {
        if (kIsWc || typeof wcov === "object" && wcov !== null && k in wcov) {
          if (kIsWc) {
            ov = wcov;
          } else {
            ov = wcov[k];
          }
          nv = i !== lastPathIndex ? ov : isCensorFct ? censorFctTakesPath ? censor(ov, [...path, originalKey, ...afterPath]) : censor(ov) : censor;
          if (kIsWc) {
            const rv = restoreInstr(redactPathCurrent, ov, parent);
            store.push(rv);
            n[wck] = nv;
          } else {
            if (wcov[k] === nv) {
            } else if (nv === void 0 && censor !== void 0 || has(wcov, k) && nv === ov) {
            } else {
              const rv = restoreInstr(node(redactPathCurrent, k, depth + 1), ov, parent);
              store.push(rv);
              wcov[k] = nv;
            }
          }
        }
      }
      for (const key in wcov) {
        if (typeof wcov[key] === "object") {
          redactPathCurrent = node(redactPathCurrent, key, depth);
          iterateNthLevel(wcov[key], level - 1, k, path, afterPath, censor, isCensorFct, censorFctTakesPath, originalKey, n, nv, ov, kIsWc, wck, i, lastPathIndex, redactPathCurrent, store, parent, depth + 1);
        }
      }
    }
    function tree() {
      return { parent: null, key: null, children: [], depth: 0 };
    }
    function node(parent, key, depth) {
      if (parent.depth === depth) {
        return node(parent.parent, key, depth);
      }
      var child = {
        parent,
        key,
        depth,
        children: []
      };
      parent.children.push(child);
      return child;
    }
    function restoreInstr(node2, value, target) {
      let current = node2;
      const path = [];
      do {
        path.push(current.key);
        current = current.parent;
      } while (current.parent != null);
      return { path, value, target };
    }
  }
});

// node_modules/fast-redact/lib/restorer.js
var require_restorer = __commonJS({
  "node_modules/fast-redact/lib/restorer.js"(exports, module2) {
    "use strict";
    var { groupRestore, nestedRestore } = require_modifiers();
    module2.exports = restorer;
    function restorer({ secret, wcLen }) {
      return function compileRestore() {
        if (this.restore)
          return;
        const paths = Object.keys(secret);
        const resetters = resetTmpl(secret, paths);
        const hasWildcards = wcLen > 0;
        const state = hasWildcards ? { secret, groupRestore, nestedRestore } : { secret };
        this.restore = Function(
          "o",
          restoreTmpl(resetters, paths, hasWildcards)
        ).bind(state);
      };
    }
    function resetTmpl(secret, paths) {
      return paths.map((path) => {
        const { circle, escPath, leadingBracket } = secret[path];
        const delim = leadingBracket ? "" : ".";
        const reset = circle ? `o.${circle} = secret[${escPath}].val` : `o${delim}${path} = secret[${escPath}].val`;
        const clear = `secret[${escPath}].val = undefined`;
        return `
      if (secret[${escPath}].val !== undefined) {
        try { ${reset} } catch (e) {}
        ${clear}
      }
    `;
      }).join("");
    }
    function restoreTmpl(resetters, paths, hasWildcards) {
      const dynamicReset = hasWildcards === true ? `
    const keys = Object.keys(secret)
    const len = keys.length
    for (var i = len - 1; i >= ${paths.length}; i--) {
      const k = keys[i]
      const o = secret[k]
      if (o.flat === true) this.groupRestore(o)
      else this.nestedRestore(o)
      secret[k] = null
    }
  ` : "";
      return `
    const secret = this.secret
    ${dynamicReset}
    ${resetters}
    return o
  `;
    }
  }
});

// node_modules/fast-redact/lib/state.js
var require_state = __commonJS({
  "node_modules/fast-redact/lib/state.js"(exports, module2) {
    "use strict";
    module2.exports = state;
    function state(o) {
      const {
        secret,
        censor,
        compileRestore,
        serialize,
        groupRedact,
        nestedRedact,
        wildcards,
        wcLen
      } = o;
      const builder = [{ secret, censor, compileRestore }];
      if (serialize !== false)
        builder.push({ serialize });
      if (wcLen > 0)
        builder.push({ groupRedact, nestedRedact, wildcards, wcLen });
      return Object.assign(...builder);
    }
  }
});

// node_modules/fast-redact/index.js
var require_fast_redact = __commonJS({
  "node_modules/fast-redact/index.js"(exports, module2) {
    "use strict";
    var validator = require_validator();
    var parse = require_parse();
    var redactor = require_redactor();
    var restorer = require_restorer();
    var { groupRedact, nestedRedact } = require_modifiers();
    var state = require_state();
    var rx = require_rx();
    var validate = validator();
    var noop = (o) => o;
    noop.restore = noop;
    var DEFAULT_CENSOR = "[REDACTED]";
    fastRedact.rx = rx;
    fastRedact.validator = validator;
    module2.exports = fastRedact;
    function fastRedact(opts = {}) {
      const paths = Array.from(new Set(opts.paths || []));
      const serialize = "serialize" in opts ? opts.serialize === false ? opts.serialize : typeof opts.serialize === "function" ? opts.serialize : JSON.stringify : JSON.stringify;
      const remove = opts.remove;
      if (remove === true && serialize !== JSON.stringify) {
        throw Error("fast-redact \u2013 remove option may only be set when serializer is JSON.stringify");
      }
      const censor = remove === true ? void 0 : "censor" in opts ? opts.censor : DEFAULT_CENSOR;
      const isCensorFct = typeof censor === "function";
      const censorFctTakesPath = isCensorFct && censor.length > 1;
      if (paths.length === 0)
        return serialize || noop;
      validate({ paths, serialize, censor });
      const { wildcards, wcLen, secret } = parse({ paths, censor });
      const compileRestore = restorer({ secret, wcLen });
      const strict = "strict" in opts ? opts.strict : true;
      return redactor({ secret, wcLen, serialize, strict, isCensorFct, censorFctTakesPath }, state({
        secret,
        censor,
        compileRestore,
        serialize,
        groupRedact,
        nestedRedact,
        wildcards,
        wcLen
      }));
    }
  }
});

// node_modules/pino/lib/symbols.js
var require_symbols = __commonJS({
  "node_modules/pino/lib/symbols.js"(exports, module2) {
    "use strict";
    var setLevelSym = Symbol("pino.setLevel");
    var getLevelSym = Symbol("pino.getLevel");
    var levelValSym = Symbol("pino.levelVal");
    var useLevelLabelsSym = Symbol("pino.useLevelLabels");
    var useOnlyCustomLevelsSym = Symbol("pino.useOnlyCustomLevels");
    var mixinSym = Symbol("pino.mixin");
    var lsCacheSym = Symbol("pino.lsCache");
    var chindingsSym = Symbol("pino.chindings");
    var asJsonSym = Symbol("pino.asJson");
    var writeSym = Symbol("pino.write");
    var redactFmtSym = Symbol("pino.redactFmt");
    var timeSym = Symbol("pino.time");
    var timeSliceIndexSym = Symbol("pino.timeSliceIndex");
    var streamSym = Symbol("pino.stream");
    var stringifySym = Symbol("pino.stringify");
    var stringifySafeSym = Symbol("pino.stringifySafe");
    var stringifiersSym = Symbol("pino.stringifiers");
    var endSym = Symbol("pino.end");
    var formatOptsSym = Symbol("pino.formatOpts");
    var messageKeySym = Symbol("pino.messageKey");
    var errorKeySym = Symbol("pino.errorKey");
    var nestedKeySym = Symbol("pino.nestedKey");
    var nestedKeyStrSym = Symbol("pino.nestedKeyStr");
    var mixinMergeStrategySym = Symbol("pino.mixinMergeStrategy");
    var msgPrefixSym = Symbol("pino.msgPrefix");
    var wildcardFirstSym = Symbol("pino.wildcardFirst");
    var serializersSym = Symbol.for("pino.serializers");
    var formattersSym = Symbol.for("pino.formatters");
    var hooksSym = Symbol.for("pino.hooks");
    var needsMetadataGsym = Symbol.for("pino.metadata");
    module2.exports = {
      setLevelSym,
      getLevelSym,
      levelValSym,
      useLevelLabelsSym,
      mixinSym,
      lsCacheSym,
      chindingsSym,
      asJsonSym,
      writeSym,
      serializersSym,
      redactFmtSym,
      timeSym,
      timeSliceIndexSym,
      streamSym,
      stringifySym,
      stringifySafeSym,
      stringifiersSym,
      endSym,
      formatOptsSym,
      messageKeySym,
      errorKeySym,
      nestedKeySym,
      wildcardFirstSym,
      needsMetadataGsym,
      useOnlyCustomLevelsSym,
      formattersSym,
      hooksSym,
      nestedKeyStrSym,
      mixinMergeStrategySym,
      msgPrefixSym
    };
  }
});

// node_modules/pino/lib/redaction.js
var require_redaction = __commonJS({
  "node_modules/pino/lib/redaction.js"(exports, module2) {
    "use strict";
    var fastRedact = require_fast_redact();
    var { redactFmtSym, wildcardFirstSym } = require_symbols();
    var { rx, validator } = fastRedact;
    var validate = validator({
      ERR_PATHS_MUST_BE_STRINGS: () => "pino \u2013 redacted paths must be strings",
      ERR_INVALID_PATH: (s) => `pino \u2013 redact paths array contains an invalid path (${s})`
    });
    var CENSOR = "[Redacted]";
    var strict = false;
    function redaction(opts, serialize) {
      const { paths, censor } = handle(opts);
      const shape = paths.reduce((o, str) => {
        rx.lastIndex = 0;
        const first = rx.exec(str);
        const next = rx.exec(str);
        let ns = first[1] !== void 0 ? first[1].replace(/^(?:"|'|`)(.*)(?:"|'|`)$/, "$1") : first[0];
        if (ns === "*") {
          ns = wildcardFirstSym;
        }
        if (next === null) {
          o[ns] = null;
          return o;
        }
        if (o[ns] === null) {
          return o;
        }
        const { index } = next;
        const nextPath = `${str.substr(index, str.length - 1)}`;
        o[ns] = o[ns] || [];
        if (ns !== wildcardFirstSym && o[ns].length === 0) {
          o[ns].push(...o[wildcardFirstSym] || []);
        }
        if (ns === wildcardFirstSym) {
          Object.keys(o).forEach(function(k) {
            if (o[k]) {
              o[k].push(nextPath);
            }
          });
        }
        o[ns].push(nextPath);
        return o;
      }, {});
      const result = {
        [redactFmtSym]: fastRedact({ paths, censor, serialize, strict })
      };
      const topCensor = (...args) => {
        return typeof censor === "function" ? serialize(censor(...args)) : serialize(censor);
      };
      return [...Object.keys(shape), ...Object.getOwnPropertySymbols(shape)].reduce((o, k) => {
        if (shape[k] === null) {
          o[k] = (value) => topCensor(value, [k]);
        } else {
          const wrappedCensor = typeof censor === "function" ? (value, path) => {
            return censor(value, [k, ...path]);
          } : censor;
          o[k] = fastRedact({
            paths: shape[k],
            censor: wrappedCensor,
            serialize,
            strict
          });
        }
        return o;
      }, result);
    }
    function handle(opts) {
      if (Array.isArray(opts)) {
        opts = { paths: opts, censor: CENSOR };
        validate(opts);
        return opts;
      }
      let { paths, censor = CENSOR, remove } = opts;
      if (Array.isArray(paths) === false) {
        throw Error("pino \u2013 redact must contain an array of strings");
      }
      if (remove === true)
        censor = void 0;
      validate({ paths, censor });
      return { paths, censor };
    }
    module2.exports = redaction;
  }
});

// node_modules/pino/lib/time.js
var require_time = __commonJS({
  "node_modules/pino/lib/time.js"(exports, module2) {
    "use strict";
    var nullTime = () => "";
    var epochTime = () => `,"time":${Date.now()}`;
    var unixTime = () => `,"time":${Math.round(Date.now() / 1e3)}`;
    var isoTime = () => `,"time":"${new Date(Date.now()).toISOString()}"`;
    module2.exports = { nullTime, epochTime, unixTime, isoTime };
  }
});

// node_modules/quick-format-unescaped/index.js
var require_quick_format_unescaped = __commonJS({
  "node_modules/quick-format-unescaped/index.js"(exports, module2) {
    "use strict";
    function tryStringify(o) {
      try {
        return JSON.stringify(o);
      } catch (e) {
        return '"[Circular]"';
      }
    }
    module2.exports = format;
    function format(f, args, opts) {
      var ss = opts && opts.stringify || tryStringify;
      var offset = 1;
      if (typeof f === "object" && f !== null) {
        var len = args.length + offset;
        if (len === 1)
          return f;
        var objects = new Array(len);
        objects[0] = ss(f);
        for (var index = 1; index < len; index++) {
          objects[index] = ss(args[index]);
        }
        return objects.join(" ");
      }
      if (typeof f !== "string") {
        return f;
      }
      var argLen = args.length;
      if (argLen === 0)
        return f;
      var str = "";
      var a = 1 - offset;
      var lastPos = -1;
      var flen = f && f.length || 0;
      for (var i = 0; i < flen; ) {
        if (f.charCodeAt(i) === 37 && i + 1 < flen) {
          lastPos = lastPos > -1 ? lastPos : 0;
          switch (f.charCodeAt(i + 1)) {
            case 100:
            case 102:
              if (a >= argLen)
                break;
              if (args[a] == null)
                break;
              if (lastPos < i)
                str += f.slice(lastPos, i);
              str += Number(args[a]);
              lastPos = i + 2;
              i++;
              break;
            case 105:
              if (a >= argLen)
                break;
              if (args[a] == null)
                break;
              if (lastPos < i)
                str += f.slice(lastPos, i);
              str += Math.floor(Number(args[a]));
              lastPos = i + 2;
              i++;
              break;
            case 79:
            case 111:
            case 106:
              if (a >= argLen)
                break;
              if (args[a] === void 0)
                break;
              if (lastPos < i)
                str += f.slice(lastPos, i);
              var type = typeof args[a];
              if (type === "string") {
                str += "'" + args[a] + "'";
                lastPos = i + 2;
                i++;
                break;
              }
              if (type === "function") {
                str += args[a].name || "<anonymous>";
                lastPos = i + 2;
                i++;
                break;
              }
              str += ss(args[a]);
              lastPos = i + 2;
              i++;
              break;
            case 115:
              if (a >= argLen)
                break;
              if (lastPos < i)
                str += f.slice(lastPos, i);
              str += String(args[a]);
              lastPos = i + 2;
              i++;
              break;
            case 37:
              if (lastPos < i)
                str += f.slice(lastPos, i);
              str += "%";
              lastPos = i + 2;
              i++;
              a--;
              break;
          }
          ++a;
        }
        ++i;
      }
      if (lastPos === -1)
        return f;
      else if (lastPos < flen) {
        str += f.slice(lastPos);
      }
      return str;
    }
  }
});

// node_modules/atomic-sleep/index.js
var require_atomic_sleep = __commonJS({
  "node_modules/atomic-sleep/index.js"(exports, module2) {
    "use strict";
    if (typeof SharedArrayBuffer !== "undefined" && typeof Atomics !== "undefined") {
      let sleep = function(ms) {
        const valid = ms > 0 && ms < Infinity;
        if (valid === false) {
          if (typeof ms !== "number" && typeof ms !== "bigint") {
            throw TypeError("sleep: ms must be a number");
          }
          throw RangeError("sleep: ms must be a number that is greater than 0 but less than Infinity");
        }
        Atomics.wait(nil, 0, 0, Number(ms));
      };
      const nil = new Int32Array(new SharedArrayBuffer(4));
      module2.exports = sleep;
    } else {
      let sleep = function(ms) {
        const valid = ms > 0 && ms < Infinity;
        if (valid === false) {
          if (typeof ms !== "number" && typeof ms !== "bigint") {
            throw TypeError("sleep: ms must be a number");
          }
          throw RangeError("sleep: ms must be a number that is greater than 0 but less than Infinity");
        }
        const target = Date.now() + Number(ms);
        while (target > Date.now()) {
        }
      };
      module2.exports = sleep;
    }
  }
});

// node_modules/sonic-boom/index.js
var require_sonic_boom = __commonJS({
  "node_modules/sonic-boom/index.js"(exports, module2) {
    "use strict";
    var fs = require("fs");
    var EventEmitter = require("events");
    var inherits = require("util").inherits;
    var path = require("path");
    var sleep = require_atomic_sleep();
    var BUSY_WRITE_TIMEOUT = 100;
    var kEmptyBuffer = Buffer.allocUnsafe(0);
    var MAX_WRITE = 16 * 1024;
    var kContentModeBuffer = "buffer";
    var kContentModeUtf8 = "utf8";
    function openFile(file, sonic) {
      sonic._opening = true;
      sonic._writing = true;
      sonic._asyncDrainScheduled = false;
      function fileOpened(err, fd) {
        if (err) {
          sonic._reopening = false;
          sonic._writing = false;
          sonic._opening = false;
          if (sonic.sync) {
            process.nextTick(() => {
              if (sonic.listenerCount("error") > 0) {
                sonic.emit("error", err);
              }
            });
          } else {
            sonic.emit("error", err);
          }
          return;
        }
        sonic.fd = fd;
        sonic.file = file;
        sonic._reopening = false;
        sonic._opening = false;
        sonic._writing = false;
        if (sonic.sync) {
          process.nextTick(() => sonic.emit("ready"));
        } else {
          sonic.emit("ready");
        }
        if (sonic._reopening || sonic.destroyed) {
          return;
        }
        if (!sonic._writing && sonic._len > sonic.minLength || sonic._flushPending) {
          sonic._actualWrite();
        }
      }
      const flags = sonic.append ? "a" : "w";
      const mode = sonic.mode;
      if (sonic.sync) {
        try {
          if (sonic.mkdir)
            fs.mkdirSync(path.dirname(file), { recursive: true });
          const fd = fs.openSync(file, flags, mode);
          fileOpened(null, fd);
        } catch (err) {
          fileOpened(err);
          throw err;
        }
      } else if (sonic.mkdir) {
        fs.mkdir(path.dirname(file), { recursive: true }, (err) => {
          if (err)
            return fileOpened(err);
          fs.open(file, flags, mode, fileOpened);
        });
      } else {
        fs.open(file, flags, mode, fileOpened);
      }
    }
    function SonicBoom(opts) {
      if (!(this instanceof SonicBoom)) {
        return new SonicBoom(opts);
      }
      let { fd, dest, minLength, maxLength, maxWrite, sync, append = true, mkdir, retryEAGAIN, fsync, contentMode, mode } = opts || {};
      fd = fd || dest;
      this._len = 0;
      this.fd = -1;
      this._bufs = [];
      this._lens = [];
      this._writing = false;
      this._ending = false;
      this._reopening = false;
      this._asyncDrainScheduled = false;
      this._flushPending = false;
      this._hwm = Math.max(minLength || 0, 16387);
      this.file = null;
      this.destroyed = false;
      this.minLength = minLength || 0;
      this.maxLength = maxLength || 0;
      this.maxWrite = maxWrite || MAX_WRITE;
      this.sync = sync || false;
      this.writable = true;
      this._fsync = fsync || false;
      this.append = append || false;
      this.mode = mode;
      this.retryEAGAIN = retryEAGAIN || (() => true);
      this.mkdir = mkdir || false;
      let fsWriteSync;
      let fsWrite;
      if (contentMode === kContentModeBuffer) {
        this._writingBuf = kEmptyBuffer;
        this.write = writeBuffer;
        this.flush = flushBuffer;
        this.flushSync = flushBufferSync;
        this._actualWrite = actualWriteBuffer;
        fsWriteSync = () => fs.writeSync(this.fd, this._writingBuf);
        fsWrite = () => fs.write(this.fd, this._writingBuf, this.release);
      } else if (contentMode === void 0 || contentMode === kContentModeUtf8) {
        this._writingBuf = "";
        this.write = write;
        this.flush = flush;
        this.flushSync = flushSync;
        this._actualWrite = actualWrite;
        fsWriteSync = () => fs.writeSync(this.fd, this._writingBuf, "utf8");
        fsWrite = () => fs.write(this.fd, this._writingBuf, "utf8", this.release);
      } else {
        throw new Error(`SonicBoom supports "${kContentModeUtf8}" and "${kContentModeBuffer}", but passed ${contentMode}`);
      }
      if (typeof fd === "number") {
        this.fd = fd;
        process.nextTick(() => this.emit("ready"));
      } else if (typeof fd === "string") {
        openFile(fd, this);
      } else {
        throw new Error("SonicBoom supports only file descriptors and files");
      }
      if (this.minLength >= this.maxWrite) {
        throw new Error(`minLength should be smaller than maxWrite (${this.maxWrite})`);
      }
      this.release = (err, n) => {
        if (err) {
          if ((err.code === "EAGAIN" || err.code === "EBUSY") && this.retryEAGAIN(err, this._writingBuf.length, this._len - this._writingBuf.length)) {
            if (this.sync) {
              try {
                sleep(BUSY_WRITE_TIMEOUT);
                this.release(void 0, 0);
              } catch (err2) {
                this.release(err2);
              }
            } else {
              setTimeout(fsWrite, BUSY_WRITE_TIMEOUT);
            }
          } else {
            this._writing = false;
            this.emit("error", err);
          }
          return;
        }
        this.emit("write", n);
        const releasedBufObj = releaseWritingBuf(this._writingBuf, this._len, n);
        this._len = releasedBufObj.len;
        this._writingBuf = releasedBufObj.writingBuf;
        if (this._writingBuf.length) {
          if (!this.sync) {
            fsWrite();
            return;
          }
          try {
            do {
              const n2 = fsWriteSync();
              const releasedBufObj2 = releaseWritingBuf(this._writingBuf, this._len, n2);
              this._len = releasedBufObj2.len;
              this._writingBuf = releasedBufObj2.writingBuf;
            } while (this._writingBuf.length);
          } catch (err2) {
            this.release(err2);
            return;
          }
        }
        if (this._fsync) {
          fs.fsyncSync(this.fd);
        }
        const len = this._len;
        if (this._reopening) {
          this._writing = false;
          this._reopening = false;
          this.reopen();
        } else if (len > this.minLength) {
          this._actualWrite();
        } else if (this._ending) {
          if (len > 0) {
            this._actualWrite();
          } else {
            this._writing = false;
            actualClose(this);
          }
        } else {
          this._writing = false;
          if (this.sync) {
            if (!this._asyncDrainScheduled) {
              this._asyncDrainScheduled = true;
              process.nextTick(emitDrain, this);
            }
          } else {
            this.emit("drain");
          }
        }
      };
      this.on("newListener", function(name) {
        if (name === "drain") {
          this._asyncDrainScheduled = false;
        }
      });
    }
    function releaseWritingBuf(writingBuf, len, n) {
      if (typeof writingBuf === "string" && Buffer.byteLength(writingBuf) !== n) {
        n = Buffer.from(writingBuf).subarray(0, n).toString().length;
      }
      len = Math.max(len - n, 0);
      writingBuf = writingBuf.slice(n);
      return { writingBuf, len };
    }
    function emitDrain(sonic) {
      const hasListeners = sonic.listenerCount("drain") > 0;
      if (!hasListeners)
        return;
      sonic._asyncDrainScheduled = false;
      sonic.emit("drain");
    }
    inherits(SonicBoom, EventEmitter);
    function mergeBuf(bufs, len) {
      if (bufs.length === 0) {
        return kEmptyBuffer;
      }
      if (bufs.length === 1) {
        return bufs[0];
      }
      return Buffer.concat(bufs, len);
    }
    function write(data) {
      if (this.destroyed) {
        throw new Error("SonicBoom destroyed");
      }
      const len = this._len + data.length;
      const bufs = this._bufs;
      if (this.maxLength && len > this.maxLength) {
        this.emit("drop", data);
        return this._len < this._hwm;
      }
      if (bufs.length === 0 || bufs[bufs.length - 1].length + data.length > this.maxWrite) {
        bufs.push("" + data);
      } else {
        bufs[bufs.length - 1] += data;
      }
      this._len = len;
      if (!this._writing && this._len >= this.minLength) {
        this._actualWrite();
      }
      return this._len < this._hwm;
    }
    function writeBuffer(data) {
      if (this.destroyed) {
        throw new Error("SonicBoom destroyed");
      }
      const len = this._len + data.length;
      const bufs = this._bufs;
      const lens = this._lens;
      if (this.maxLength && len > this.maxLength) {
        this.emit("drop", data);
        return this._len < this._hwm;
      }
      if (bufs.length === 0 || lens[lens.length - 1] + data.length > this.maxWrite) {
        bufs.push([data]);
        lens.push(data.length);
      } else {
        bufs[bufs.length - 1].push(data);
        lens[lens.length - 1] += data.length;
      }
      this._len = len;
      if (!this._writing && this._len >= this.minLength) {
        this._actualWrite();
      }
      return this._len < this._hwm;
    }
    function callFlushCallbackOnDrain(cb) {
      this._flushPending = true;
      const onDrain = () => {
        if (!this._fsync) {
          fs.fsync(this.fd, (err) => {
            this._flushPending = false;
            cb(err);
          });
        } else {
          this._flushPending = false;
          cb();
        }
        this.off("error", onError);
      };
      const onError = (err) => {
        this._flushPending = false;
        cb(err);
        this.off("drain", onDrain);
      };
      this.once("drain", onDrain);
      this.once("error", onError);
    }
    function flush(cb) {
      if (cb != null && typeof cb !== "function") {
        throw new Error("flush cb must be a function");
      }
      if (this.destroyed) {
        const error = new Error("SonicBoom destroyed");
        if (cb) {
          cb(error);
          return;
        }
        throw error;
      }
      if (this.minLength <= 0) {
        cb?.();
        return;
      }
      if (cb) {
        callFlushCallbackOnDrain.call(this, cb);
      }
      if (this._writing) {
        return;
      }
      if (this._bufs.length === 0) {
        this._bufs.push("");
      }
      this._actualWrite();
    }
    function flushBuffer(cb) {
      if (cb != null && typeof cb !== "function") {
        throw new Error("flush cb must be a function");
      }
      if (this.destroyed) {
        const error = new Error("SonicBoom destroyed");
        if (cb) {
          cb(error);
          return;
        }
        throw error;
      }
      if (this.minLength <= 0) {
        cb?.();
        return;
      }
      if (cb) {
        callFlushCallbackOnDrain.call(this, cb);
      }
      if (this._writing) {
        return;
      }
      if (this._bufs.length === 0) {
        this._bufs.push([]);
        this._lens.push(0);
      }
      this._actualWrite();
    }
    SonicBoom.prototype.reopen = function(file) {
      if (this.destroyed) {
        throw new Error("SonicBoom destroyed");
      }
      if (this._opening) {
        this.once("ready", () => {
          this.reopen(file);
        });
        return;
      }
      if (this._ending) {
        return;
      }
      if (!this.file) {
        throw new Error("Unable to reopen a file descriptor, you must pass a file to SonicBoom");
      }
      this._reopening = true;
      if (this._writing) {
        return;
      }
      const fd = this.fd;
      this.once("ready", () => {
        if (fd !== this.fd) {
          fs.close(fd, (err) => {
            if (err) {
              return this.emit("error", err);
            }
          });
        }
      });
      openFile(file || this.file, this);
    };
    SonicBoom.prototype.end = function() {
      if (this.destroyed) {
        throw new Error("SonicBoom destroyed");
      }
      if (this._opening) {
        this.once("ready", () => {
          this.end();
        });
        return;
      }
      if (this._ending) {
        return;
      }
      this._ending = true;
      if (this._writing) {
        return;
      }
      if (this._len > 0 && this.fd >= 0) {
        this._actualWrite();
      } else {
        actualClose(this);
      }
    };
    function flushSync() {
      if (this.destroyed) {
        throw new Error("SonicBoom destroyed");
      }
      if (this.fd < 0) {
        throw new Error("sonic boom is not ready yet");
      }
      if (!this._writing && this._writingBuf.length > 0) {
        this._bufs.unshift(this._writingBuf);
        this._writingBuf = "";
      }
      let buf = "";
      while (this._bufs.length || buf) {
        if (buf.length <= 0) {
          buf = this._bufs[0];
        }
        try {
          const n = fs.writeSync(this.fd, buf, "utf8");
          const releasedBufObj = releaseWritingBuf(buf, this._len, n);
          buf = releasedBufObj.writingBuf;
          this._len = releasedBufObj.len;
          if (buf.length <= 0) {
            this._bufs.shift();
          }
        } catch (err) {
          const shouldRetry = err.code === "EAGAIN" || err.code === "EBUSY";
          if (shouldRetry && !this.retryEAGAIN(err, buf.length, this._len - buf.length)) {
            throw err;
          }
          sleep(BUSY_WRITE_TIMEOUT);
        }
      }
      try {
        fs.fsyncSync(this.fd);
      } catch {
      }
    }
    function flushBufferSync() {
      if (this.destroyed) {
        throw new Error("SonicBoom destroyed");
      }
      if (this.fd < 0) {
        throw new Error("sonic boom is not ready yet");
      }
      if (!this._writing && this._writingBuf.length > 0) {
        this._bufs.unshift([this._writingBuf]);
        this._writingBuf = kEmptyBuffer;
      }
      let buf = kEmptyBuffer;
      while (this._bufs.length || buf.length) {
        if (buf.length <= 0) {
          buf = mergeBuf(this._bufs[0], this._lens[0]);
        }
        try {
          const n = fs.writeSync(this.fd, buf);
          buf = buf.subarray(n);
          this._len = Math.max(this._len - n, 0);
          if (buf.length <= 0) {
            this._bufs.shift();
            this._lens.shift();
          }
        } catch (err) {
          const shouldRetry = err.code === "EAGAIN" || err.code === "EBUSY";
          if (shouldRetry && !this.retryEAGAIN(err, buf.length, this._len - buf.length)) {
            throw err;
          }
          sleep(BUSY_WRITE_TIMEOUT);
        }
      }
    }
    SonicBoom.prototype.destroy = function() {
      if (this.destroyed) {
        return;
      }
      actualClose(this);
    };
    function actualWrite() {
      const release = this.release;
      this._writing = true;
      this._writingBuf = this._writingBuf || this._bufs.shift() || "";
      if (this.sync) {
        try {
          const written = fs.writeSync(this.fd, this._writingBuf, "utf8");
          release(null, written);
        } catch (err) {
          release(err);
        }
      } else {
        fs.write(this.fd, this._writingBuf, "utf8", release);
      }
    }
    function actualWriteBuffer() {
      const release = this.release;
      this._writing = true;
      this._writingBuf = this._writingBuf.length ? this._writingBuf : mergeBuf(this._bufs.shift(), this._lens.shift());
      if (this.sync) {
        try {
          const written = fs.writeSync(this.fd, this._writingBuf);
          release(null, written);
        } catch (err) {
          release(err);
        }
      } else {
        fs.write(this.fd, this._writingBuf, release);
      }
    }
    function actualClose(sonic) {
      if (sonic.fd === -1) {
        sonic.once("ready", actualClose.bind(null, sonic));
        return;
      }
      sonic.destroyed = true;
      sonic._bufs = [];
      sonic._lens = [];
      fs.fsync(sonic.fd, closeWrapped);
      function closeWrapped() {
        if (sonic.fd !== 1 && sonic.fd !== 2) {
          fs.close(sonic.fd, done);
        } else {
          done();
        }
      }
      function done(err) {
        if (err) {
          sonic.emit("error", err);
          return;
        }
        if (sonic._ending && !sonic._writing) {
          sonic.emit("finish");
        }
        sonic.emit("close");
      }
    }
    SonicBoom.SonicBoom = SonicBoom;
    SonicBoom.default = SonicBoom;
    module2.exports = SonicBoom;
  }
});

// node_modules/on-exit-leak-free/index.js
var require_on_exit_leak_free = __commonJS({
  "node_modules/on-exit-leak-free/index.js"(exports, module2) {
    "use strict";
    var refs = {
      exit: [],
      beforeExit: []
    };
    var functions = {
      exit: onExit,
      beforeExit: onBeforeExit
    };
    var registry;
    function ensureRegistry() {
      if (registry === void 0) {
        registry = new FinalizationRegistry(clear);
      }
    }
    function install(event) {
      if (refs[event].length > 0) {
        return;
      }
      process.on(event, functions[event]);
    }
    function uninstall(event) {
      if (refs[event].length > 0) {
        return;
      }
      process.removeListener(event, functions[event]);
      if (refs.exit.length === 0 && refs.beforeExit.length === 0) {
        registry = void 0;
      }
    }
    function onExit() {
      callRefs("exit");
    }
    function onBeforeExit() {
      callRefs("beforeExit");
    }
    function callRefs(event) {
      for (const ref of refs[event]) {
        const obj = ref.deref();
        const fn = ref.fn;
        if (obj !== void 0) {
          fn(obj, event);
        }
      }
      refs[event] = [];
    }
    function clear(ref) {
      for (const event of ["exit", "beforeExit"]) {
        const index = refs[event].indexOf(ref);
        refs[event].splice(index, index + 1);
        uninstall(event);
      }
    }
    function _register(event, obj, fn) {
      if (obj === void 0) {
        throw new Error("the object can't be undefined");
      }
      install(event);
      const ref = new WeakRef(obj);
      ref.fn = fn;
      ensureRegistry();
      registry.register(obj, ref);
      refs[event].push(ref);
    }
    function register(obj, fn) {
      _register("exit", obj, fn);
    }
    function registerBeforeExit(obj, fn) {
      _register("beforeExit", obj, fn);
    }
    function unregister(obj) {
      if (registry === void 0) {
        return;
      }
      registry.unregister(obj);
      for (const event of ["exit", "beforeExit"]) {
        refs[event] = refs[event].filter((ref) => {
          const _obj = ref.deref();
          return _obj && _obj !== obj;
        });
        uninstall(event);
      }
    }
    module2.exports = {
      register,
      registerBeforeExit,
      unregister
    };
  }
});

// node_modules/thread-stream/package.json
var require_package = __commonJS({
  "node_modules/thread-stream/package.json"(exports, module2) {
    module2.exports = {
      name: "thread-stream",
      version: "2.4.1",
      description: "A streaming way to send data to a Node.js Worker Thread",
      main: "index.js",
      types: "index.d.ts",
      dependencies: {
        "real-require": "^0.2.0"
      },
      devDependencies: {
        "@types/node": "^20.1.0",
        "@types/tap": "^15.0.0",
        desm: "^1.3.0",
        fastbench: "^1.0.1",
        husky: "^8.0.1",
        "pino-elasticsearch": "^6.0.0",
        "sonic-boom": "^3.0.0",
        standard: "^17.0.0",
        tap: "^16.2.0",
        "ts-node": "^10.8.0",
        typescript: "^4.7.2",
        "why-is-node-running": "^2.2.2"
      },
      scripts: {
        test: "standard && npm run transpile && tap test/*.test.*js && tap --ts test/*.test.*ts",
        "test:ci": "standard && npm run transpile && npm run test:ci:js && npm run test:ci:ts",
        "test:ci:js": 'tap --no-check-coverage --coverage-report=lcovonly "test/**/*.test.*js"',
        "test:ci:ts": 'tap --ts --no-check-coverage --coverage-report=lcovonly "test/**/*.test.*ts"',
        "test:yarn": 'npm run transpile && tap "test/**/*.test.js" --no-check-coverage',
        transpile: "sh ./test/ts/transpile.sh",
        prepare: "husky install"
      },
      standard: {
        ignore: [
          "test/ts/**/*"
        ]
      },
      repository: {
        type: "git",
        url: "git+https://github.com/mcollina/thread-stream.git"
      },
      keywords: [
        "worker",
        "thread",
        "threads",
        "stream"
      ],
      author: "Matteo Collina <hello@matteocollina.com>",
      license: "MIT",
      bugs: {
        url: "https://github.com/mcollina/thread-stream/issues"
      },
      homepage: "https://github.com/mcollina/thread-stream#readme"
    };
  }
});

// node_modules/thread-stream/lib/wait.js
var require_wait = __commonJS({
  "node_modules/thread-stream/lib/wait.js"(exports, module2) {
    "use strict";
    var MAX_TIMEOUT = 1e3;
    function wait(state, index, expected, timeout, done) {
      const max = Date.now() + timeout;
      let current = Atomics.load(state, index);
      if (current === expected) {
        done(null, "ok");
        return;
      }
      let prior = current;
      const check = (backoff) => {
        if (Date.now() > max) {
          done(null, "timed-out");
        } else {
          setTimeout(() => {
            prior = current;
            current = Atomics.load(state, index);
            if (current === prior) {
              check(backoff >= MAX_TIMEOUT ? MAX_TIMEOUT : backoff * 2);
            } else {
              if (current === expected)
                done(null, "ok");
              else
                done(null, "not-equal");
            }
          }, backoff);
        }
      };
      check(1);
    }
    function waitDiff(state, index, expected, timeout, done) {
      const max = Date.now() + timeout;
      let current = Atomics.load(state, index);
      if (current !== expected) {
        done(null, "ok");
        return;
      }
      const check = (backoff) => {
        if (Date.now() > max) {
          done(null, "timed-out");
        } else {
          setTimeout(() => {
            current = Atomics.load(state, index);
            if (current !== expected) {
              done(null, "ok");
            } else {
              check(backoff >= MAX_TIMEOUT ? MAX_TIMEOUT : backoff * 2);
            }
          }, backoff);
        }
      };
      check(1);
    }
    module2.exports = { wait, waitDiff };
  }
});

// node_modules/thread-stream/lib/indexes.js
var require_indexes = __commonJS({
  "node_modules/thread-stream/lib/indexes.js"(exports, module2) {
    "use strict";
    var WRITE_INDEX = 4;
    var READ_INDEX = 8;
    module2.exports = {
      WRITE_INDEX,
      READ_INDEX
    };
  }
});

// node_modules/thread-stream/index.js
var require_thread_stream = __commonJS({
  "node_modules/thread-stream/index.js"(exports, module2) {
    "use strict";
    var { version } = require_package();
    var { EventEmitter } = require("events");
    var { Worker } = require("worker_threads");
    var { join } = require("path");
    var { pathToFileURL } = require("url");
    var { wait } = require_wait();
    var {
      WRITE_INDEX,
      READ_INDEX
    } = require_indexes();
    var buffer = require("buffer");
    var assert3 = require("assert");
    var kImpl = Symbol("kImpl");
    var MAX_STRING = buffer.constants.MAX_STRING_LENGTH;
    var FakeWeakRef = class {
      constructor(value) {
        this._value = value;
      }
      deref() {
        return this._value;
      }
    };
    var FakeFinalizationRegistry = class {
      register() {
      }
      unregister() {
      }
    };
    var FinalizationRegistry2 = process.env.NODE_V8_COVERAGE ? FakeFinalizationRegistry : global.FinalizationRegistry || FakeFinalizationRegistry;
    var WeakRef2 = process.env.NODE_V8_COVERAGE ? FakeWeakRef : global.WeakRef || FakeWeakRef;
    var registry = new FinalizationRegistry2((worker) => {
      if (worker.exited) {
        return;
      }
      worker.terminate();
    });
    function createWorker(stream, opts) {
      const { filename, workerData } = opts;
      const bundlerOverrides = "__bundlerPathsOverrides" in globalThis ? globalThis.__bundlerPathsOverrides : {};
      const toExecute = bundlerOverrides["thread-stream-worker"] || join(__dirname, "lib", "worker.js");
      const worker = new Worker(toExecute, {
        ...opts.workerOpts,
        trackUnmanagedFds: false,
        workerData: {
          filename: filename.indexOf("file://") === 0 ? filename : pathToFileURL(filename).href,
          dataBuf: stream[kImpl].dataBuf,
          stateBuf: stream[kImpl].stateBuf,
          workerData: {
            $context: {
              threadStreamVersion: version
            },
            ...workerData
          }
        }
      });
      worker.stream = new FakeWeakRef(stream);
      worker.on("message", onWorkerMessage);
      worker.on("exit", onWorkerExit);
      registry.register(stream, worker);
      return worker;
    }
    function drain(stream) {
      assert3(!stream[kImpl].sync);
      if (stream[kImpl].needDrain) {
        stream[kImpl].needDrain = false;
        stream.emit("drain");
      }
    }
    function nextFlush(stream) {
      const writeIndex = Atomics.load(stream[kImpl].state, WRITE_INDEX);
      let leftover = stream[kImpl].data.length - writeIndex;
      if (leftover > 0) {
        if (stream[kImpl].buf.length === 0) {
          stream[kImpl].flushing = false;
          if (stream[kImpl].ending) {
            end(stream);
          } else if (stream[kImpl].needDrain) {
            process.nextTick(drain, stream);
          }
          return;
        }
        let toWrite = stream[kImpl].buf.slice(0, leftover);
        let toWriteBytes = Buffer.byteLength(toWrite);
        if (toWriteBytes <= leftover) {
          stream[kImpl].buf = stream[kImpl].buf.slice(leftover);
          write(stream, toWrite, nextFlush.bind(null, stream));
        } else {
          stream.flush(() => {
            if (stream.destroyed) {
              return;
            }
            Atomics.store(stream[kImpl].state, READ_INDEX, 0);
            Atomics.store(stream[kImpl].state, WRITE_INDEX, 0);
            while (toWriteBytes > stream[kImpl].data.length) {
              leftover = leftover / 2;
              toWrite = stream[kImpl].buf.slice(0, leftover);
              toWriteBytes = Buffer.byteLength(toWrite);
            }
            stream[kImpl].buf = stream[kImpl].buf.slice(leftover);
            write(stream, toWrite, nextFlush.bind(null, stream));
          });
        }
      } else if (leftover === 0) {
        if (writeIndex === 0 && stream[kImpl].buf.length === 0) {
          return;
        }
        stream.flush(() => {
          Atomics.store(stream[kImpl].state, READ_INDEX, 0);
          Atomics.store(stream[kImpl].state, WRITE_INDEX, 0);
          nextFlush(stream);
        });
      } else {
        destroy(stream, new Error("overwritten"));
      }
    }
    function onWorkerMessage(msg) {
      const stream = this.stream.deref();
      if (stream === void 0) {
        this.exited = true;
        this.terminate();
        return;
      }
      switch (msg.code) {
        case "READY":
          this.stream = new WeakRef2(stream);
          stream.flush(() => {
            stream[kImpl].ready = true;
            stream.emit("ready");
          });
          break;
        case "ERROR":
          destroy(stream, msg.err);
          break;
        case "EVENT":
          if (Array.isArray(msg.args)) {
            stream.emit(msg.name, ...msg.args);
          } else {
            stream.emit(msg.name, msg.args);
          }
          break;
        case "WARNING":
          process.emitWarning(msg.err);
          break;
        default:
          destroy(stream, new Error("this should not happen: " + msg.code));
      }
    }
    function onWorkerExit(code) {
      const stream = this.stream.deref();
      if (stream === void 0) {
        return;
      }
      registry.unregister(stream);
      stream.worker.exited = true;
      stream.worker.off("exit", onWorkerExit);
      destroy(stream, code !== 0 ? new Error("the worker thread exited") : null);
    }
    var ThreadStream = class extends EventEmitter {
      constructor(opts = {}) {
        super();
        if (opts.bufferSize < 4) {
          throw new Error("bufferSize must at least fit a 4-byte utf-8 char");
        }
        this[kImpl] = {};
        this[kImpl].stateBuf = new SharedArrayBuffer(128);
        this[kImpl].state = new Int32Array(this[kImpl].stateBuf);
        this[kImpl].dataBuf = new SharedArrayBuffer(opts.bufferSize || 4 * 1024 * 1024);
        this[kImpl].data = Buffer.from(this[kImpl].dataBuf);
        this[kImpl].sync = opts.sync || false;
        this[kImpl].ending = false;
        this[kImpl].ended = false;
        this[kImpl].needDrain = false;
        this[kImpl].destroyed = false;
        this[kImpl].flushing = false;
        this[kImpl].ready = false;
        this[kImpl].finished = false;
        this[kImpl].errored = null;
        this[kImpl].closed = false;
        this[kImpl].buf = "";
        this.worker = createWorker(this, opts);
      }
      write(data) {
        if (this[kImpl].destroyed) {
          error(this, new Error("the worker has exited"));
          return false;
        }
        if (this[kImpl].ending) {
          error(this, new Error("the worker is ending"));
          return false;
        }
        if (this[kImpl].flushing && this[kImpl].buf.length + data.length >= MAX_STRING) {
          try {
            writeSync(this);
            this[kImpl].flushing = true;
          } catch (err) {
            destroy(this, err);
            return false;
          }
        }
        this[kImpl].buf += data;
        if (this[kImpl].sync) {
          try {
            writeSync(this);
            return true;
          } catch (err) {
            destroy(this, err);
            return false;
          }
        }
        if (!this[kImpl].flushing) {
          this[kImpl].flushing = true;
          setImmediate(nextFlush, this);
        }
        this[kImpl].needDrain = this[kImpl].data.length - this[kImpl].buf.length - Atomics.load(this[kImpl].state, WRITE_INDEX) <= 0;
        return !this[kImpl].needDrain;
      }
      end() {
        if (this[kImpl].destroyed) {
          return;
        }
        this[kImpl].ending = true;
        end(this);
      }
      flush(cb) {
        if (this[kImpl].destroyed) {
          if (typeof cb === "function") {
            process.nextTick(cb, new Error("the worker has exited"));
          }
          return;
        }
        const writeIndex = Atomics.load(this[kImpl].state, WRITE_INDEX);
        wait(this[kImpl].state, READ_INDEX, writeIndex, Infinity, (err, res) => {
          if (err) {
            destroy(this, err);
            process.nextTick(cb, err);
            return;
          }
          if (res === "not-equal") {
            this.flush(cb);
            return;
          }
          process.nextTick(cb);
        });
      }
      flushSync() {
        if (this[kImpl].destroyed) {
          return;
        }
        writeSync(this);
        flushSync(this);
      }
      unref() {
        this.worker.unref();
      }
      ref() {
        this.worker.ref();
      }
      get ready() {
        return this[kImpl].ready;
      }
      get destroyed() {
        return this[kImpl].destroyed;
      }
      get closed() {
        return this[kImpl].closed;
      }
      get writable() {
        return !this[kImpl].destroyed && !this[kImpl].ending;
      }
      get writableEnded() {
        return this[kImpl].ending;
      }
      get writableFinished() {
        return this[kImpl].finished;
      }
      get writableNeedDrain() {
        return this[kImpl].needDrain;
      }
      get writableObjectMode() {
        return false;
      }
      get writableErrored() {
        return this[kImpl].errored;
      }
    };
    function error(stream, err) {
      setImmediate(() => {
        stream.emit("error", err);
      });
    }
    function destroy(stream, err) {
      if (stream[kImpl].destroyed) {
        return;
      }
      stream[kImpl].destroyed = true;
      if (err) {
        stream[kImpl].errored = err;
        error(stream, err);
      }
      if (!stream.worker.exited) {
        stream.worker.terminate().catch(() => {
        }).then(() => {
          stream[kImpl].closed = true;
          stream.emit("close");
        });
      } else {
        setImmediate(() => {
          stream[kImpl].closed = true;
          stream.emit("close");
        });
      }
    }
    function write(stream, data, cb) {
      const current = Atomics.load(stream[kImpl].state, WRITE_INDEX);
      const length = Buffer.byteLength(data);
      stream[kImpl].data.write(data, current);
      Atomics.store(stream[kImpl].state, WRITE_INDEX, current + length);
      Atomics.notify(stream[kImpl].state, WRITE_INDEX);
      cb();
      return true;
    }
    function end(stream) {
      if (stream[kImpl].ended || !stream[kImpl].ending || stream[kImpl].flushing) {
        return;
      }
      stream[kImpl].ended = true;
      try {
        stream.flushSync();
        let readIndex = Atomics.load(stream[kImpl].state, READ_INDEX);
        Atomics.store(stream[kImpl].state, WRITE_INDEX, -1);
        Atomics.notify(stream[kImpl].state, WRITE_INDEX);
        let spins = 0;
        while (readIndex !== -1) {
          Atomics.wait(stream[kImpl].state, READ_INDEX, readIndex, 1e3);
          readIndex = Atomics.load(stream[kImpl].state, READ_INDEX);
          if (readIndex === -2) {
            destroy(stream, new Error("end() failed"));
            return;
          }
          if (++spins === 10) {
            destroy(stream, new Error("end() took too long (10s)"));
            return;
          }
        }
        process.nextTick(() => {
          stream[kImpl].finished = true;
          stream.emit("finish");
        });
      } catch (err) {
        destroy(stream, err);
      }
    }
    function writeSync(stream) {
      const cb = () => {
        if (stream[kImpl].ending) {
          end(stream);
        } else if (stream[kImpl].needDrain) {
          process.nextTick(drain, stream);
        }
      };
      stream[kImpl].flushing = false;
      while (stream[kImpl].buf.length !== 0) {
        const writeIndex = Atomics.load(stream[kImpl].state, WRITE_INDEX);
        let leftover = stream[kImpl].data.length - writeIndex;
        if (leftover === 0) {
          flushSync(stream);
          Atomics.store(stream[kImpl].state, READ_INDEX, 0);
          Atomics.store(stream[kImpl].state, WRITE_INDEX, 0);
          continue;
        } else if (leftover < 0) {
          throw new Error("overwritten");
        }
        let toWrite = stream[kImpl].buf.slice(0, leftover);
        let toWriteBytes = Buffer.byteLength(toWrite);
        if (toWriteBytes <= leftover) {
          stream[kImpl].buf = stream[kImpl].buf.slice(leftover);
          write(stream, toWrite, cb);
        } else {
          flushSync(stream);
          Atomics.store(stream[kImpl].state, READ_INDEX, 0);
          Atomics.store(stream[kImpl].state, WRITE_INDEX, 0);
          while (toWriteBytes > stream[kImpl].buf.length) {
            leftover = leftover / 2;
            toWrite = stream[kImpl].buf.slice(0, leftover);
            toWriteBytes = Buffer.byteLength(toWrite);
          }
          stream[kImpl].buf = stream[kImpl].buf.slice(leftover);
          write(stream, toWrite, cb);
        }
      }
    }
    function flushSync(stream) {
      if (stream[kImpl].flushing) {
        throw new Error("unable to flush while flushing");
      }
      const writeIndex = Atomics.load(stream[kImpl].state, WRITE_INDEX);
      let spins = 0;
      while (true) {
        const readIndex = Atomics.load(stream[kImpl].state, READ_INDEX);
        if (readIndex === -2) {
          throw Error("_flushSync failed");
        }
        if (readIndex !== writeIndex) {
          Atomics.wait(stream[kImpl].state, READ_INDEX, readIndex, 1e3);
        } else {
          break;
        }
        if (++spins === 10) {
          throw new Error("_flushSync took too long (10s)");
        }
      }
    }
    module2.exports = ThreadStream;
  }
});

// node_modules/pino/lib/transport.js
var require_transport = __commonJS({
  "node_modules/pino/lib/transport.js"(exports, module2) {
    "use strict";
    var { createRequire } = require("module");
    var getCallers = require_caller();
    var { join, isAbsolute, sep } = require("path");
    var sleep = require_atomic_sleep();
    var onExit = require_on_exit_leak_free();
    var ThreadStream = require_thread_stream();
    function setupOnExit(stream) {
      onExit.register(stream, autoEnd);
      onExit.registerBeforeExit(stream, flush);
      stream.on("close", function() {
        onExit.unregister(stream);
      });
    }
    function buildStream(filename, workerData, workerOpts) {
      const stream = new ThreadStream({
        filename,
        workerData,
        workerOpts
      });
      stream.on("ready", onReady);
      stream.on("close", function() {
        process.removeListener("exit", onExit2);
      });
      process.on("exit", onExit2);
      function onReady() {
        process.removeListener("exit", onExit2);
        stream.unref();
        if (workerOpts.autoEnd !== false) {
          setupOnExit(stream);
        }
      }
      function onExit2() {
        if (stream.closed) {
          return;
        }
        stream.flushSync();
        sleep(100);
        stream.end();
      }
      return stream;
    }
    function autoEnd(stream) {
      stream.ref();
      stream.flushSync();
      stream.end();
      stream.once("close", function() {
        stream.unref();
      });
    }
    function flush(stream) {
      stream.flushSync();
    }
    function transport(fullOptions) {
      const { pipeline, targets, levels, dedupe, options = {}, worker = {}, caller = getCallers() } = fullOptions;
      const callers = typeof caller === "string" ? [caller] : caller;
      const bundlerOverrides = "__bundlerPathsOverrides" in globalThis ? globalThis.__bundlerPathsOverrides : {};
      let target = fullOptions.target;
      if (target && targets) {
        throw new Error("only one of target or targets can be specified");
      }
      if (targets) {
        target = bundlerOverrides["pino-worker"] || join(__dirname, "worker.js");
        options.targets = targets.map((dest) => {
          return {
            ...dest,
            target: fixTarget(dest.target)
          };
        });
      } else if (pipeline) {
        target = bundlerOverrides["pino-pipeline-worker"] || join(__dirname, "worker-pipeline.js");
        options.targets = pipeline.map((dest) => {
          return {
            ...dest,
            target: fixTarget(dest.target)
          };
        });
      }
      if (levels) {
        options.levels = levels;
      }
      if (dedupe) {
        options.dedupe = dedupe;
      }
      return buildStream(fixTarget(target), options, worker);
      function fixTarget(origin) {
        origin = bundlerOverrides[origin] || origin;
        if (isAbsolute(origin) || origin.indexOf("file://") === 0) {
          return origin;
        }
        if (origin === "pino/file") {
          return join(__dirname, "..", "file.js");
        }
        let fixTarget2;
        for (const filePath of callers) {
          try {
            const context = filePath === "node:repl" ? process.cwd() + sep : filePath;
            fixTarget2 = createRequire(context).resolve(origin);
            break;
          } catch (err) {
            continue;
          }
        }
        if (!fixTarget2) {
          throw new Error(`unable to determine transport target for "${origin}"`);
        }
        return fixTarget2;
      }
    }
    module2.exports = transport;
  }
});

// node_modules/pino/lib/tools.js
var require_tools = __commonJS({
  "node_modules/pino/lib/tools.js"(exports, module2) {
    "use strict";
    var format = require_quick_format_unescaped();
    var { mapHttpRequest, mapHttpResponse } = require_pino_std_serializers();
    var SonicBoom = require_sonic_boom();
    var onExit = require_on_exit_leak_free();
    var {
      lsCacheSym,
      chindingsSym,
      writeSym,
      serializersSym,
      formatOptsSym,
      endSym,
      stringifiersSym,
      stringifySym,
      stringifySafeSym,
      wildcardFirstSym,
      nestedKeySym,
      formattersSym,
      messageKeySym,
      errorKeySym,
      nestedKeyStrSym,
      msgPrefixSym
    } = require_symbols();
    var { isMainThread } = require("worker_threads");
    var transport = require_transport();
    function noop() {
    }
    function genLog(level, hook) {
      if (!hook)
        return LOG;
      return function hookWrappedLog(...args) {
        hook.call(this, args, LOG, level);
      };
      function LOG(o, ...n) {
        if (typeof o === "object") {
          let msg = o;
          if (o !== null) {
            if (o.method && o.headers && o.socket) {
              o = mapHttpRequest(o);
            } else if (typeof o.setHeader === "function") {
              o = mapHttpResponse(o);
            }
          }
          let formatParams;
          if (msg === null && n.length === 0) {
            formatParams = [null];
          } else {
            msg = n.shift();
            formatParams = n;
          }
          if (typeof this[msgPrefixSym] === "string" && msg !== void 0 && msg !== null) {
            msg = this[msgPrefixSym] + msg;
          }
          this[writeSym](o, format(msg, formatParams, this[formatOptsSym]), level);
        } else {
          let msg = o === void 0 ? n.shift() : o;
          if (typeof this[msgPrefixSym] === "string" && msg !== void 0 && msg !== null) {
            msg = this[msgPrefixSym] + msg;
          }
          this[writeSym](null, format(msg, n, this[formatOptsSym]), level);
        }
      }
    }
    function asString(str) {
      let result = "";
      let last = 0;
      let found = false;
      let point = 255;
      const l = str.length;
      if (l > 100) {
        return JSON.stringify(str);
      }
      for (var i = 0; i < l && point >= 32; i++) {
        point = str.charCodeAt(i);
        if (point === 34 || point === 92) {
          result += str.slice(last, i) + "\\";
          last = i;
          found = true;
        }
      }
      if (!found) {
        result = str;
      } else {
        result += str.slice(last);
      }
      return point < 32 ? JSON.stringify(str) : '"' + result + '"';
    }
    function asJson(obj, msg, num, time) {
      const stringify2 = this[stringifySym];
      const stringifySafe = this[stringifySafeSym];
      const stringifiers = this[stringifiersSym];
      const end = this[endSym];
      const chindings = this[chindingsSym];
      const serializers = this[serializersSym];
      const formatters = this[formattersSym];
      const messageKey = this[messageKeySym];
      const errorKey = this[errorKeySym];
      let data = this[lsCacheSym][num] + time;
      data = data + chindings;
      let value;
      if (formatters.log) {
        obj = formatters.log(obj);
      }
      const wildcardStringifier = stringifiers[wildcardFirstSym];
      let propStr = "";
      for (const key in obj) {
        value = obj[key];
        if (Object.prototype.hasOwnProperty.call(obj, key) && value !== void 0) {
          if (serializers[key]) {
            value = serializers[key](value);
          } else if (key === errorKey && serializers.err) {
            value = serializers.err(value);
          }
          const stringifier = stringifiers[key] || wildcardStringifier;
          switch (typeof value) {
            case "undefined":
            case "function":
              continue;
            case "number":
              if (Number.isFinite(value) === false) {
                value = null;
              }
            case "boolean":
              if (stringifier)
                value = stringifier(value);
              break;
            case "string":
              value = (stringifier || asString)(value);
              break;
            default:
              value = (stringifier || stringify2)(value, stringifySafe);
          }
          if (value === void 0)
            continue;
          const strKey = asString(key);
          propStr += "," + strKey + ":" + value;
        }
      }
      let msgStr = "";
      if (msg !== void 0) {
        value = serializers[messageKey] ? serializers[messageKey](msg) : msg;
        const stringifier = stringifiers[messageKey] || wildcardStringifier;
        switch (typeof value) {
          case "function":
            break;
          case "number":
            if (Number.isFinite(value) === false) {
              value = null;
            }
          case "boolean":
            if (stringifier)
              value = stringifier(value);
            msgStr = ',"' + messageKey + '":' + value;
            break;
          case "string":
            value = (stringifier || asString)(value);
            msgStr = ',"' + messageKey + '":' + value;
            break;
          default:
            value = (stringifier || stringify2)(value, stringifySafe);
            msgStr = ',"' + messageKey + '":' + value;
        }
      }
      if (this[nestedKeySym] && propStr) {
        return data + this[nestedKeyStrSym] + propStr.slice(1) + "}" + msgStr + end;
      } else {
        return data + propStr + msgStr + end;
      }
    }
    function asChindings(instance, bindings) {
      let value;
      let data = instance[chindingsSym];
      const stringify2 = instance[stringifySym];
      const stringifySafe = instance[stringifySafeSym];
      const stringifiers = instance[stringifiersSym];
      const wildcardStringifier = stringifiers[wildcardFirstSym];
      const serializers = instance[serializersSym];
      const formatter = instance[formattersSym].bindings;
      bindings = formatter(bindings);
      for (const key in bindings) {
        value = bindings[key];
        const valid = key !== "level" && key !== "serializers" && key !== "formatters" && key !== "customLevels" && bindings.hasOwnProperty(key) && value !== void 0;
        if (valid === true) {
          value = serializers[key] ? serializers[key](value) : value;
          value = (stringifiers[key] || wildcardStringifier || stringify2)(value, stringifySafe);
          if (value === void 0)
            continue;
          data += ',"' + key + '":' + value;
        }
      }
      return data;
    }
    function hasBeenTampered(stream) {
      return stream.write !== stream.constructor.prototype.write;
    }
    var hasNodeCodeCoverage = process.env.NODE_V8_COVERAGE || process.env.V8_COVERAGE;
    function buildSafeSonicBoom(opts) {
      const stream = new SonicBoom(opts);
      stream.on("error", filterBrokenPipe);
      if (!hasNodeCodeCoverage && !opts.sync && isMainThread) {
        onExit.register(stream, autoEnd);
        stream.on("close", function() {
          onExit.unregister(stream);
        });
      }
      return stream;
      function filterBrokenPipe(err) {
        if (err.code === "EPIPE") {
          stream.write = noop;
          stream.end = noop;
          stream.flushSync = noop;
          stream.destroy = noop;
          return;
        }
        stream.removeListener("error", filterBrokenPipe);
        stream.emit("error", err);
      }
    }
    function autoEnd(stream, eventName) {
      if (stream.destroyed) {
        return;
      }
      if (eventName === "beforeExit") {
        stream.flush();
        stream.on("drain", function() {
          stream.end();
        });
      } else {
        stream.flushSync();
      }
    }
    function createArgsNormalizer(defaultOptions) {
      return function normalizeArgs(instance, caller, opts = {}, stream) {
        if (typeof opts === "string") {
          stream = buildSafeSonicBoom({ dest: opts });
          opts = {};
        } else if (typeof stream === "string") {
          if (opts && opts.transport) {
            throw Error("only one of option.transport or stream can be specified");
          }
          stream = buildSafeSonicBoom({ dest: stream });
        } else if (opts instanceof SonicBoom || opts.writable || opts._writableState) {
          stream = opts;
          opts = {};
        } else if (opts.transport) {
          if (opts.transport instanceof SonicBoom || opts.transport.writable || opts.transport._writableState) {
            throw Error("option.transport do not allow stream, please pass to option directly. e.g. pino(transport)");
          }
          if (opts.transport.targets && opts.transport.targets.length && opts.formatters && typeof opts.formatters.level === "function") {
            throw Error("option.transport.targets do not allow custom level formatters");
          }
          let customLevels;
          if (opts.customLevels) {
            customLevels = opts.useOnlyCustomLevels ? opts.customLevels : Object.assign({}, opts.levels, opts.customLevels);
          }
          stream = transport({ caller, ...opts.transport, levels: customLevels });
        }
        opts = Object.assign({}, defaultOptions, opts);
        opts.serializers = Object.assign({}, defaultOptions.serializers, opts.serializers);
        opts.formatters = Object.assign({}, defaultOptions.formatters, opts.formatters);
        if (opts.prettyPrint) {
          throw new Error("prettyPrint option is no longer supported, see the pino-pretty package (https://github.com/pinojs/pino-pretty)");
        }
        const { enabled, onChild } = opts;
        if (enabled === false)
          opts.level = "silent";
        if (!onChild)
          opts.onChild = noop;
        if (!stream) {
          if (!hasBeenTampered(process.stdout)) {
            stream = buildSafeSonicBoom({ fd: process.stdout.fd || 1 });
          } else {
            stream = process.stdout;
          }
        }
        return { opts, stream };
      };
    }
    function stringify(obj, stringifySafeFn) {
      try {
        return JSON.stringify(obj);
      } catch (_) {
        try {
          const stringify2 = stringifySafeFn || this[stringifySafeSym];
          return stringify2(obj);
        } catch (_2) {
          return '"[unable to serialize, circular reference is too complex to analyze]"';
        }
      }
    }
    function buildFormatters(level, bindings, log) {
      return {
        level,
        bindings,
        log
      };
    }
    function normalizeDestFileDescriptor(destination) {
      const fd = Number(destination);
      if (typeof destination === "string" && Number.isFinite(fd)) {
        return fd;
      }
      if (destination === void 0) {
        return 1;
      }
      return destination;
    }
    module2.exports = {
      noop,
      buildSafeSonicBoom,
      asChindings,
      asJson,
      genLog,
      createArgsNormalizer,
      stringify,
      buildFormatters,
      normalizeDestFileDescriptor
    };
  }
});

// node_modules/pino/lib/levels.js
var require_levels = __commonJS({
  "node_modules/pino/lib/levels.js"(exports, module2) {
    "use strict";
    var {
      lsCacheSym,
      levelValSym,
      useOnlyCustomLevelsSym,
      streamSym,
      formattersSym,
      hooksSym
    } = require_symbols();
    var { noop, genLog } = require_tools();
    var levels = {
      trace: 10,
      debug: 20,
      info: 30,
      warn: 40,
      error: 50,
      fatal: 60
    };
    var levelMethods = {
      fatal: (hook) => {
        const logFatal = genLog(levels.fatal, hook);
        return function(...args) {
          const stream = this[streamSym];
          logFatal.call(this, ...args);
          if (typeof stream.flushSync === "function") {
            try {
              stream.flushSync();
            } catch (e) {
            }
          }
        };
      },
      error: (hook) => genLog(levels.error, hook),
      warn: (hook) => genLog(levels.warn, hook),
      info: (hook) => genLog(levels.info, hook),
      debug: (hook) => genLog(levels.debug, hook),
      trace: (hook) => genLog(levels.trace, hook)
    };
    var nums = Object.keys(levels).reduce((o, k) => {
      o[levels[k]] = k;
      return o;
    }, {});
    var initialLsCache = Object.keys(nums).reduce((o, k) => {
      o[k] = '{"level":' + Number(k);
      return o;
    }, {});
    function genLsCache(instance) {
      const formatter = instance[formattersSym].level;
      const { labels } = instance.levels;
      const cache = {};
      for (const label in labels) {
        const level = formatter(labels[label], Number(label));
        cache[label] = JSON.stringify(level).slice(0, -1);
      }
      instance[lsCacheSym] = cache;
      return instance;
    }
    function isStandardLevel(level, useOnlyCustomLevels) {
      if (useOnlyCustomLevels) {
        return false;
      }
      switch (level) {
        case "fatal":
        case "error":
        case "warn":
        case "info":
        case "debug":
        case "trace":
          return true;
        default:
          return false;
      }
    }
    function setLevel(level) {
      const { labels, values } = this.levels;
      if (typeof level === "number") {
        if (labels[level] === void 0)
          throw Error("unknown level value" + level);
        level = labels[level];
      }
      if (values[level] === void 0)
        throw Error("unknown level " + level);
      const preLevelVal = this[levelValSym];
      const levelVal = this[levelValSym] = values[level];
      const useOnlyCustomLevelsVal = this[useOnlyCustomLevelsSym];
      const hook = this[hooksSym].logMethod;
      for (const key in values) {
        if (levelVal > values[key]) {
          this[key] = noop;
          continue;
        }
        this[key] = isStandardLevel(key, useOnlyCustomLevelsVal) ? levelMethods[key](hook) : genLog(values[key], hook);
      }
      this.emit(
        "level-change",
        level,
        levelVal,
        labels[preLevelVal],
        preLevelVal,
        this
      );
    }
    function getLevel(level) {
      const { levels: levels2, levelVal } = this;
      return levels2 && levels2.labels ? levels2.labels[levelVal] : "";
    }
    function isLevelEnabled(logLevel) {
      const { values } = this.levels;
      const logLevelVal = values[logLevel];
      return logLevelVal !== void 0 && logLevelVal >= this[levelValSym];
    }
    function mappings(customLevels = null, useOnlyCustomLevels = false) {
      const customNums = customLevels ? Object.keys(customLevels).reduce((o, k) => {
        o[customLevels[k]] = k;
        return o;
      }, {}) : null;
      const labels = Object.assign(
        Object.create(Object.prototype, { Infinity: { value: "silent" } }),
        useOnlyCustomLevels ? null : nums,
        customNums
      );
      const values = Object.assign(
        Object.create(Object.prototype, { silent: { value: Infinity } }),
        useOnlyCustomLevels ? null : levels,
        customLevels
      );
      return { labels, values };
    }
    function assertDefaultLevelFound(defaultLevel, customLevels, useOnlyCustomLevels) {
      if (typeof defaultLevel === "number") {
        const values = [].concat(
          Object.keys(customLevels || {}).map((key) => customLevels[key]),
          useOnlyCustomLevels ? [] : Object.keys(nums).map((level) => +level),
          Infinity
        );
        if (!values.includes(defaultLevel)) {
          throw Error(`default level:${defaultLevel} must be included in custom levels`);
        }
        return;
      }
      const labels = Object.assign(
        Object.create(Object.prototype, { silent: { value: Infinity } }),
        useOnlyCustomLevels ? null : levels,
        customLevels
      );
      if (!(defaultLevel in labels)) {
        throw Error(`default level:${defaultLevel} must be included in custom levels`);
      }
    }
    function assertNoLevelCollisions(levels2, customLevels) {
      const { labels, values } = levels2;
      for (const k in customLevels) {
        if (k in values) {
          throw Error("levels cannot be overridden");
        }
        if (customLevels[k] in labels) {
          throw Error("pre-existing level values cannot be used for new levels");
        }
      }
    }
    module2.exports = {
      initialLsCache,
      genLsCache,
      levelMethods,
      getLevel,
      setLevel,
      isLevelEnabled,
      mappings,
      levels,
      assertNoLevelCollisions,
      assertDefaultLevelFound
    };
  }
});

// node_modules/pino/lib/meta.js
var require_meta = __commonJS({
  "node_modules/pino/lib/meta.js"(exports, module2) {
    "use strict";
    module2.exports = { version: "8.17.2" };
  }
});

// node_modules/pino/lib/proto.js
var require_proto = __commonJS({
  "node_modules/pino/lib/proto.js"(exports, module2) {
    "use strict";
    var { EventEmitter } = require("events");
    var {
      lsCacheSym,
      levelValSym,
      setLevelSym,
      getLevelSym,
      chindingsSym,
      parsedChindingsSym,
      mixinSym,
      asJsonSym,
      writeSym,
      mixinMergeStrategySym,
      timeSym,
      timeSliceIndexSym,
      streamSym,
      serializersSym,
      formattersSym,
      errorKeySym,
      messageKeySym,
      useOnlyCustomLevelsSym,
      needsMetadataGsym,
      redactFmtSym,
      stringifySym,
      formatOptsSym,
      stringifiersSym,
      msgPrefixSym
    } = require_symbols();
    var {
      getLevel,
      setLevel,
      isLevelEnabled,
      mappings,
      initialLsCache,
      genLsCache,
      assertNoLevelCollisions
    } = require_levels();
    var {
      asChindings,
      asJson,
      buildFormatters,
      stringify
    } = require_tools();
    var {
      version
    } = require_meta();
    var redaction = require_redaction();
    var constructor = class Pino {
    };
    var prototype = {
      constructor,
      child,
      bindings,
      setBindings,
      flush,
      isLevelEnabled,
      version,
      get level() {
        return this[getLevelSym]();
      },
      set level(lvl) {
        this[setLevelSym](lvl);
      },
      get levelVal() {
        return this[levelValSym];
      },
      set levelVal(n) {
        throw Error("levelVal is read-only");
      },
      [lsCacheSym]: initialLsCache,
      [writeSym]: write,
      [asJsonSym]: asJson,
      [getLevelSym]: getLevel,
      [setLevelSym]: setLevel
    };
    Object.setPrototypeOf(prototype, EventEmitter.prototype);
    module2.exports = function() {
      return Object.create(prototype);
    };
    var resetChildingsFormatter = (bindings2) => bindings2;
    function child(bindings2, options) {
      if (!bindings2) {
        throw Error("missing bindings for child Pino");
      }
      options = options || {};
      const serializers = this[serializersSym];
      const formatters = this[formattersSym];
      const instance = Object.create(this);
      if (options.hasOwnProperty("serializers") === true) {
        instance[serializersSym] = /* @__PURE__ */ Object.create(null);
        for (const k in serializers) {
          instance[serializersSym][k] = serializers[k];
        }
        const parentSymbols = Object.getOwnPropertySymbols(serializers);
        for (var i = 0; i < parentSymbols.length; i++) {
          const ks = parentSymbols[i];
          instance[serializersSym][ks] = serializers[ks];
        }
        for (const bk in options.serializers) {
          instance[serializersSym][bk] = options.serializers[bk];
        }
        const bindingsSymbols = Object.getOwnPropertySymbols(options.serializers);
        for (var bi = 0; bi < bindingsSymbols.length; bi++) {
          const bks = bindingsSymbols[bi];
          instance[serializersSym][bks] = options.serializers[bks];
        }
      } else
        instance[serializersSym] = serializers;
      if (options.hasOwnProperty("formatters")) {
        const { level, bindings: chindings, log } = options.formatters;
        instance[formattersSym] = buildFormatters(
          level || formatters.level,
          chindings || resetChildingsFormatter,
          log || formatters.log
        );
      } else {
        instance[formattersSym] = buildFormatters(
          formatters.level,
          resetChildingsFormatter,
          formatters.log
        );
      }
      if (options.hasOwnProperty("customLevels") === true) {
        assertNoLevelCollisions(this.levels, options.customLevels);
        instance.levels = mappings(options.customLevels, instance[useOnlyCustomLevelsSym]);
        genLsCache(instance);
      }
      if (typeof options.redact === "object" && options.redact !== null || Array.isArray(options.redact)) {
        instance.redact = options.redact;
        const stringifiers = redaction(instance.redact, stringify);
        const formatOpts = { stringify: stringifiers[redactFmtSym] };
        instance[stringifySym] = stringify;
        instance[stringifiersSym] = stringifiers;
        instance[formatOptsSym] = formatOpts;
      }
      if (typeof options.msgPrefix === "string") {
        instance[msgPrefixSym] = (this[msgPrefixSym] || "") + options.msgPrefix;
      }
      instance[chindingsSym] = asChindings(instance, bindings2);
      const childLevel = options.level || this.level;
      instance[setLevelSym](childLevel);
      this.onChild(instance);
      return instance;
    }
    function bindings() {
      const chindings = this[chindingsSym];
      const chindingsJson = `{${chindings.substr(1)}}`;
      const bindingsFromJson = JSON.parse(chindingsJson);
      delete bindingsFromJson.pid;
      delete bindingsFromJson.hostname;
      return bindingsFromJson;
    }
    function setBindings(newBindings) {
      const chindings = asChindings(this, newBindings);
      this[chindingsSym] = chindings;
      delete this[parsedChindingsSym];
    }
    function defaultMixinMergeStrategy(mergeObject, mixinObject) {
      return Object.assign(mixinObject, mergeObject);
    }
    function write(_obj, msg, num) {
      const t = this[timeSym]();
      const mixin = this[mixinSym];
      const errorKey = this[errorKeySym];
      const messageKey = this[messageKeySym];
      const mixinMergeStrategy = this[mixinMergeStrategySym] || defaultMixinMergeStrategy;
      let obj;
      if (_obj === void 0 || _obj === null) {
        obj = {};
      } else if (_obj instanceof Error) {
        obj = { [errorKey]: _obj };
        if (msg === void 0) {
          msg = _obj.message;
        }
      } else {
        obj = _obj;
        if (msg === void 0 && _obj[messageKey] === void 0 && _obj[errorKey]) {
          msg = _obj[errorKey].message;
        }
      }
      if (mixin) {
        obj = mixinMergeStrategy(obj, mixin(obj, num, this));
      }
      const s = this[asJsonSym](obj, msg, num, t);
      const stream = this[streamSym];
      if (stream[needsMetadataGsym] === true) {
        stream.lastLevel = num;
        stream.lastObj = obj;
        stream.lastMsg = msg;
        stream.lastTime = t.slice(this[timeSliceIndexSym]);
        stream.lastLogger = this;
      }
      stream.write(s);
    }
    function noop() {
    }
    function flush(cb) {
      if (cb != null && typeof cb !== "function") {
        throw Error("callback must be a function");
      }
      const stream = this[streamSym];
      if (typeof stream.flush === "function") {
        stream.flush(cb || noop);
      } else if (cb)
        cb();
    }
  }
});

// node_modules/safe-stable-stringify/index.js
var require_safe_stable_stringify = __commonJS({
  "node_modules/safe-stable-stringify/index.js"(exports, module2) {
    "use strict";
    var { hasOwnProperty } = Object.prototype;
    var stringify = configure();
    stringify.configure = configure;
    stringify.stringify = stringify;
    stringify.default = stringify;
    exports.stringify = stringify;
    exports.configure = configure;
    module2.exports = stringify;
    var strEscapeSequencesRegExp = /[\u0000-\u001f\u0022\u005c\ud800-\udfff]|[\ud800-\udbff](?![\udc00-\udfff])|(?:[^\ud800-\udbff]|^)[\udc00-\udfff]/;
    function strEscape(str) {
      if (str.length < 5e3 && !strEscapeSequencesRegExp.test(str)) {
        return `"${str}"`;
      }
      return JSON.stringify(str);
    }
    function insertSort(array) {
      if (array.length > 200) {
        return array.sort();
      }
      for (let i = 1; i < array.length; i++) {
        const currentValue = array[i];
        let position = i;
        while (position !== 0 && array[position - 1] > currentValue) {
          array[position] = array[position - 1];
          position--;
        }
        array[position] = currentValue;
      }
      return array;
    }
    var typedArrayPrototypeGetSymbolToStringTag = Object.getOwnPropertyDescriptor(
      Object.getPrototypeOf(
        Object.getPrototypeOf(
          new Int8Array()
        )
      ),
      Symbol.toStringTag
    ).get;
    function isTypedArrayWithEntries(value) {
      return typedArrayPrototypeGetSymbolToStringTag.call(value) !== void 0 && value.length !== 0;
    }
    function stringifyTypedArray(array, separator, maximumBreadth) {
      if (array.length < maximumBreadth) {
        maximumBreadth = array.length;
      }
      const whitespace = separator === "," ? "" : " ";
      let res = `"0":${whitespace}${array[0]}`;
      for (let i = 1; i < maximumBreadth; i++) {
        res += `${separator}"${i}":${whitespace}${array[i]}`;
      }
      return res;
    }
    function getCircularValueOption(options) {
      if (hasOwnProperty.call(options, "circularValue")) {
        const circularValue = options.circularValue;
        if (typeof circularValue === "string") {
          return `"${circularValue}"`;
        }
        if (circularValue == null) {
          return circularValue;
        }
        if (circularValue === Error || circularValue === TypeError) {
          return {
            toString() {
              throw new TypeError("Converting circular structure to JSON");
            }
          };
        }
        throw new TypeError('The "circularValue" argument must be of type string or the value null or undefined');
      }
      return '"[Circular]"';
    }
    function getBooleanOption(options, key) {
      let value;
      if (hasOwnProperty.call(options, key)) {
        value = options[key];
        if (typeof value !== "boolean") {
          throw new TypeError(`The "${key}" argument must be of type boolean`);
        }
      }
      return value === void 0 ? true : value;
    }
    function getPositiveIntegerOption(options, key) {
      let value;
      if (hasOwnProperty.call(options, key)) {
        value = options[key];
        if (typeof value !== "number") {
          throw new TypeError(`The "${key}" argument must be of type number`);
        }
        if (!Number.isInteger(value)) {
          throw new TypeError(`The "${key}" argument must be an integer`);
        }
        if (value < 1) {
          throw new RangeError(`The "${key}" argument must be >= 1`);
        }
      }
      return value === void 0 ? Infinity : value;
    }
    function getItemCount(number) {
      if (number === 1) {
        return "1 item";
      }
      return `${number} items`;
    }
    function getUniqueReplacerSet(replacerArray) {
      const replacerSet = /* @__PURE__ */ new Set();
      for (const value of replacerArray) {
        if (typeof value === "string" || typeof value === "number") {
          replacerSet.add(String(value));
        }
      }
      return replacerSet;
    }
    function getStrictOption(options) {
      if (hasOwnProperty.call(options, "strict")) {
        const value = options.strict;
        if (typeof value !== "boolean") {
          throw new TypeError('The "strict" argument must be of type boolean');
        }
        if (value) {
          return (value2) => {
            let message = `Object can not safely be stringified. Received type ${typeof value2}`;
            if (typeof value2 !== "function")
              message += ` (${value2.toString()})`;
            throw new Error(message);
          };
        }
      }
    }
    function configure(options) {
      options = { ...options };
      const fail = getStrictOption(options);
      if (fail) {
        if (options.bigint === void 0) {
          options.bigint = false;
        }
        if (!("circularValue" in options)) {
          options.circularValue = Error;
        }
      }
      const circularValue = getCircularValueOption(options);
      const bigint = getBooleanOption(options, "bigint");
      const deterministic = getBooleanOption(options, "deterministic");
      const maximumDepth = getPositiveIntegerOption(options, "maximumDepth");
      const maximumBreadth = getPositiveIntegerOption(options, "maximumBreadth");
      function stringifyFnReplacer(key, parent, stack, replacer, spacer, indentation) {
        let value = parent[key];
        if (typeof value === "object" && value !== null && typeof value.toJSON === "function") {
          value = value.toJSON(key);
        }
        value = replacer.call(parent, key, value);
        switch (typeof value) {
          case "string":
            return strEscape(value);
          case "object": {
            if (value === null) {
              return "null";
            }
            if (stack.indexOf(value) !== -1) {
              return circularValue;
            }
            let res = "";
            let join = ",";
            const originalIndentation = indentation;
            if (Array.isArray(value)) {
              if (value.length === 0) {
                return "[]";
              }
              if (maximumDepth < stack.length + 1) {
                return '"[Array]"';
              }
              stack.push(value);
              if (spacer !== "") {
                indentation += spacer;
                res += `
${indentation}`;
                join = `,
${indentation}`;
              }
              const maximumValuesToStringify = Math.min(value.length, maximumBreadth);
              let i = 0;
              for (; i < maximumValuesToStringify - 1; i++) {
                const tmp2 = stringifyFnReplacer(String(i), value, stack, replacer, spacer, indentation);
                res += tmp2 !== void 0 ? tmp2 : "null";
                res += join;
              }
              const tmp = stringifyFnReplacer(String(i), value, stack, replacer, spacer, indentation);
              res += tmp !== void 0 ? tmp : "null";
              if (value.length - 1 > maximumBreadth) {
                const removedKeys = value.length - maximumBreadth - 1;
                res += `${join}"... ${getItemCount(removedKeys)} not stringified"`;
              }
              if (spacer !== "") {
                res += `
${originalIndentation}`;
              }
              stack.pop();
              return `[${res}]`;
            }
            let keys = Object.keys(value);
            const keyLength = keys.length;
            if (keyLength === 0) {
              return "{}";
            }
            if (maximumDepth < stack.length + 1) {
              return '"[Object]"';
            }
            let whitespace = "";
            let separator = "";
            if (spacer !== "") {
              indentation += spacer;
              join = `,
${indentation}`;
              whitespace = " ";
            }
            const maximumPropertiesToStringify = Math.min(keyLength, maximumBreadth);
            if (deterministic && !isTypedArrayWithEntries(value)) {
              keys = insertSort(keys);
            }
            stack.push(value);
            for (let i = 0; i < maximumPropertiesToStringify; i++) {
              const key2 = keys[i];
              const tmp = stringifyFnReplacer(key2, value, stack, replacer, spacer, indentation);
              if (tmp !== void 0) {
                res += `${separator}${strEscape(key2)}:${whitespace}${tmp}`;
                separator = join;
              }
            }
            if (keyLength > maximumBreadth) {
              const removedKeys = keyLength - maximumBreadth;
              res += `${separator}"...":${whitespace}"${getItemCount(removedKeys)} not stringified"`;
              separator = join;
            }
            if (spacer !== "" && separator.length > 1) {
              res = `
${indentation}${res}
${originalIndentation}`;
            }
            stack.pop();
            return `{${res}}`;
          }
          case "number":
            return isFinite(value) ? String(value) : fail ? fail(value) : "null";
          case "boolean":
            return value === true ? "true" : "false";
          case "undefined":
            return void 0;
          case "bigint":
            if (bigint) {
              return String(value);
            }
          default:
            return fail ? fail(value) : void 0;
        }
      }
      function stringifyArrayReplacer(key, value, stack, replacer, spacer, indentation) {
        if (typeof value === "object" && value !== null && typeof value.toJSON === "function") {
          value = value.toJSON(key);
        }
        switch (typeof value) {
          case "string":
            return strEscape(value);
          case "object": {
            if (value === null) {
              return "null";
            }
            if (stack.indexOf(value) !== -1) {
              return circularValue;
            }
            const originalIndentation = indentation;
            let res = "";
            let join = ",";
            if (Array.isArray(value)) {
              if (value.length === 0) {
                return "[]";
              }
              if (maximumDepth < stack.length + 1) {
                return '"[Array]"';
              }
              stack.push(value);
              if (spacer !== "") {
                indentation += spacer;
                res += `
${indentation}`;
                join = `,
${indentation}`;
              }
              const maximumValuesToStringify = Math.min(value.length, maximumBreadth);
              let i = 0;
              for (; i < maximumValuesToStringify - 1; i++) {
                const tmp2 = stringifyArrayReplacer(String(i), value[i], stack, replacer, spacer, indentation);
                res += tmp2 !== void 0 ? tmp2 : "null";
                res += join;
              }
              const tmp = stringifyArrayReplacer(String(i), value[i], stack, replacer, spacer, indentation);
              res += tmp !== void 0 ? tmp : "null";
              if (value.length - 1 > maximumBreadth) {
                const removedKeys = value.length - maximumBreadth - 1;
                res += `${join}"... ${getItemCount(removedKeys)} not stringified"`;
              }
              if (spacer !== "") {
                res += `
${originalIndentation}`;
              }
              stack.pop();
              return `[${res}]`;
            }
            stack.push(value);
            let whitespace = "";
            if (spacer !== "") {
              indentation += spacer;
              join = `,
${indentation}`;
              whitespace = " ";
            }
            let separator = "";
            for (const key2 of replacer) {
              const tmp = stringifyArrayReplacer(key2, value[key2], stack, replacer, spacer, indentation);
              if (tmp !== void 0) {
                res += `${separator}${strEscape(key2)}:${whitespace}${tmp}`;
                separator = join;
              }
            }
            if (spacer !== "" && separator.length > 1) {
              res = `
${indentation}${res}
${originalIndentation}`;
            }
            stack.pop();
            return `{${res}}`;
          }
          case "number":
            return isFinite(value) ? String(value) : fail ? fail(value) : "null";
          case "boolean":
            return value === true ? "true" : "false";
          case "undefined":
            return void 0;
          case "bigint":
            if (bigint) {
              return String(value);
            }
          default:
            return fail ? fail(value) : void 0;
        }
      }
      function stringifyIndent(key, value, stack, spacer, indentation) {
        switch (typeof value) {
          case "string":
            return strEscape(value);
          case "object": {
            if (value === null) {
              return "null";
            }
            if (typeof value.toJSON === "function") {
              value = value.toJSON(key);
              if (typeof value !== "object") {
                return stringifyIndent(key, value, stack, spacer, indentation);
              }
              if (value === null) {
                return "null";
              }
            }
            if (stack.indexOf(value) !== -1) {
              return circularValue;
            }
            const originalIndentation = indentation;
            if (Array.isArray(value)) {
              if (value.length === 0) {
                return "[]";
              }
              if (maximumDepth < stack.length + 1) {
                return '"[Array]"';
              }
              stack.push(value);
              indentation += spacer;
              let res2 = `
${indentation}`;
              const join2 = `,
${indentation}`;
              const maximumValuesToStringify = Math.min(value.length, maximumBreadth);
              let i = 0;
              for (; i < maximumValuesToStringify - 1; i++) {
                const tmp2 = stringifyIndent(String(i), value[i], stack, spacer, indentation);
                res2 += tmp2 !== void 0 ? tmp2 : "null";
                res2 += join2;
              }
              const tmp = stringifyIndent(String(i), value[i], stack, spacer, indentation);
              res2 += tmp !== void 0 ? tmp : "null";
              if (value.length - 1 > maximumBreadth) {
                const removedKeys = value.length - maximumBreadth - 1;
                res2 += `${join2}"... ${getItemCount(removedKeys)} not stringified"`;
              }
              res2 += `
${originalIndentation}`;
              stack.pop();
              return `[${res2}]`;
            }
            let keys = Object.keys(value);
            const keyLength = keys.length;
            if (keyLength === 0) {
              return "{}";
            }
            if (maximumDepth < stack.length + 1) {
              return '"[Object]"';
            }
            indentation += spacer;
            const join = `,
${indentation}`;
            let res = "";
            let separator = "";
            let maximumPropertiesToStringify = Math.min(keyLength, maximumBreadth);
            if (isTypedArrayWithEntries(value)) {
              res += stringifyTypedArray(value, join, maximumBreadth);
              keys = keys.slice(value.length);
              maximumPropertiesToStringify -= value.length;
              separator = join;
            }
            if (deterministic) {
              keys = insertSort(keys);
            }
            stack.push(value);
            for (let i = 0; i < maximumPropertiesToStringify; i++) {
              const key2 = keys[i];
              const tmp = stringifyIndent(key2, value[key2], stack, spacer, indentation);
              if (tmp !== void 0) {
                res += `${separator}${strEscape(key2)}: ${tmp}`;
                separator = join;
              }
            }
            if (keyLength > maximumBreadth) {
              const removedKeys = keyLength - maximumBreadth;
              res += `${separator}"...": "${getItemCount(removedKeys)} not stringified"`;
              separator = join;
            }
            if (separator !== "") {
              res = `
${indentation}${res}
${originalIndentation}`;
            }
            stack.pop();
            return `{${res}}`;
          }
          case "number":
            return isFinite(value) ? String(value) : fail ? fail(value) : "null";
          case "boolean":
            return value === true ? "true" : "false";
          case "undefined":
            return void 0;
          case "bigint":
            if (bigint) {
              return String(value);
            }
          default:
            return fail ? fail(value) : void 0;
        }
      }
      function stringifySimple(key, value, stack) {
        switch (typeof value) {
          case "string":
            return strEscape(value);
          case "object": {
            if (value === null) {
              return "null";
            }
            if (typeof value.toJSON === "function") {
              value = value.toJSON(key);
              if (typeof value !== "object") {
                return stringifySimple(key, value, stack);
              }
              if (value === null) {
                return "null";
              }
            }
            if (stack.indexOf(value) !== -1) {
              return circularValue;
            }
            let res = "";
            if (Array.isArray(value)) {
              if (value.length === 0) {
                return "[]";
              }
              if (maximumDepth < stack.length + 1) {
                return '"[Array]"';
              }
              stack.push(value);
              const maximumValuesToStringify = Math.min(value.length, maximumBreadth);
              let i = 0;
              for (; i < maximumValuesToStringify - 1; i++) {
                const tmp2 = stringifySimple(String(i), value[i], stack);
                res += tmp2 !== void 0 ? tmp2 : "null";
                res += ",";
              }
              const tmp = stringifySimple(String(i), value[i], stack);
              res += tmp !== void 0 ? tmp : "null";
              if (value.length - 1 > maximumBreadth) {
                const removedKeys = value.length - maximumBreadth - 1;
                res += `,"... ${getItemCount(removedKeys)} not stringified"`;
              }
              stack.pop();
              return `[${res}]`;
            }
            let keys = Object.keys(value);
            const keyLength = keys.length;
            if (keyLength === 0) {
              return "{}";
            }
            if (maximumDepth < stack.length + 1) {
              return '"[Object]"';
            }
            let separator = "";
            let maximumPropertiesToStringify = Math.min(keyLength, maximumBreadth);
            if (isTypedArrayWithEntries(value)) {
              res += stringifyTypedArray(value, ",", maximumBreadth);
              keys = keys.slice(value.length);
              maximumPropertiesToStringify -= value.length;
              separator = ",";
            }
            if (deterministic) {
              keys = insertSort(keys);
            }
            stack.push(value);
            for (let i = 0; i < maximumPropertiesToStringify; i++) {
              const key2 = keys[i];
              const tmp = stringifySimple(key2, value[key2], stack);
              if (tmp !== void 0) {
                res += `${separator}${strEscape(key2)}:${tmp}`;
                separator = ",";
              }
            }
            if (keyLength > maximumBreadth) {
              const removedKeys = keyLength - maximumBreadth;
              res += `${separator}"...":"${getItemCount(removedKeys)} not stringified"`;
            }
            stack.pop();
            return `{${res}}`;
          }
          case "number":
            return isFinite(value) ? String(value) : fail ? fail(value) : "null";
          case "boolean":
            return value === true ? "true" : "false";
          case "undefined":
            return void 0;
          case "bigint":
            if (bigint) {
              return String(value);
            }
          default:
            return fail ? fail(value) : void 0;
        }
      }
      function stringify2(value, replacer, space) {
        if (arguments.length > 1) {
          let spacer = "";
          if (typeof space === "number") {
            spacer = " ".repeat(Math.min(space, 10));
          } else if (typeof space === "string") {
            spacer = space.slice(0, 10);
          }
          if (replacer != null) {
            if (typeof replacer === "function") {
              return stringifyFnReplacer("", { "": value }, [], replacer, spacer, "");
            }
            if (Array.isArray(replacer)) {
              return stringifyArrayReplacer("", value, [], getUniqueReplacerSet(replacer), spacer, "");
            }
          }
          if (spacer.length !== 0) {
            return stringifyIndent("", value, [], spacer, "");
          }
        }
        return stringifySimple("", value, []);
      }
      return stringify2;
    }
  }
});

// node_modules/pino/lib/multistream.js
var require_multistream = __commonJS({
  "node_modules/pino/lib/multistream.js"(exports, module2) {
    "use strict";
    var metadata = Symbol.for("pino.metadata");
    var { levels } = require_levels();
    var DEFAULT_INFO_LEVEL = levels.info;
    function multistream(streamsArray, opts) {
      let counter = 0;
      streamsArray = streamsArray || [];
      opts = opts || { dedupe: false };
      const streamLevels = Object.create(levels);
      streamLevels.silent = Infinity;
      if (opts.levels && typeof opts.levels === "object") {
        Object.keys(opts.levels).forEach((i) => {
          streamLevels[i] = opts.levels[i];
        });
      }
      const res = {
        write,
        add,
        flushSync,
        end,
        minLevel: 0,
        streams: [],
        clone,
        [metadata]: true,
        streamLevels
      };
      if (Array.isArray(streamsArray)) {
        streamsArray.forEach(add, res);
      } else {
        add.call(res, streamsArray);
      }
      streamsArray = null;
      return res;
      function write(data) {
        let dest;
        const level = this.lastLevel;
        const { streams } = this;
        let recordedLevel = 0;
        let stream;
        for (let i = initLoopVar(streams.length, opts.dedupe); checkLoopVar(i, streams.length, opts.dedupe); i = adjustLoopVar(i, opts.dedupe)) {
          dest = streams[i];
          if (dest.level <= level) {
            if (recordedLevel !== 0 && recordedLevel !== dest.level) {
              break;
            }
            stream = dest.stream;
            if (stream[metadata]) {
              const { lastTime, lastMsg, lastObj, lastLogger } = this;
              stream.lastLevel = level;
              stream.lastTime = lastTime;
              stream.lastMsg = lastMsg;
              stream.lastObj = lastObj;
              stream.lastLogger = lastLogger;
            }
            stream.write(data);
            if (opts.dedupe) {
              recordedLevel = dest.level;
            }
          } else if (!opts.dedupe) {
            break;
          }
        }
      }
      function flushSync() {
        for (const { stream } of this.streams) {
          if (typeof stream.flushSync === "function") {
            stream.flushSync();
          }
        }
      }
      function add(dest) {
        if (!dest) {
          return res;
        }
        const isStream = typeof dest.write === "function" || dest.stream;
        const stream_ = dest.write ? dest : dest.stream;
        if (!isStream) {
          throw Error("stream object needs to implement either StreamEntry or DestinationStream interface");
        }
        const { streams, streamLevels: streamLevels2 } = this;
        let level;
        if (typeof dest.levelVal === "number") {
          level = dest.levelVal;
        } else if (typeof dest.level === "string") {
          level = streamLevels2[dest.level];
        } else if (typeof dest.level === "number") {
          level = dest.level;
        } else {
          level = DEFAULT_INFO_LEVEL;
        }
        const dest_ = {
          stream: stream_,
          level,
          levelVal: void 0,
          id: counter++
        };
        streams.unshift(dest_);
        streams.sort(compareByLevel);
        this.minLevel = streams[0].level;
        return res;
      }
      function end() {
        for (const { stream } of this.streams) {
          if (typeof stream.flushSync === "function") {
            stream.flushSync();
          }
          stream.end();
        }
      }
      function clone(level) {
        const streams = new Array(this.streams.length);
        for (let i = 0; i < streams.length; i++) {
          streams[i] = {
            level,
            stream: this.streams[i].stream
          };
        }
        return {
          write,
          add,
          minLevel: level,
          streams,
          clone,
          flushSync,
          [metadata]: true
        };
      }
    }
    function compareByLevel(a, b) {
      return a.level - b.level;
    }
    function initLoopVar(length, dedupe) {
      return dedupe ? length - 1 : 0;
    }
    function adjustLoopVar(i, dedupe) {
      return dedupe ? i - 1 : i + 1;
    }
    function checkLoopVar(i, length, dedupe) {
      return dedupe ? i >= 0 : i < length;
    }
    module2.exports = multistream;
  }
});

// node_modules/pino/pino.js
var require_pino = __commonJS({
  "node_modules/pino/pino.js"(exports, module2) {
    "use strict";
    var os = require("os");
    var stdSerializers = require_pino_std_serializers();
    var caller = require_caller();
    var redaction = require_redaction();
    var time = require_time();
    var proto = require_proto();
    var symbols = require_symbols();
    var { configure } = require_safe_stable_stringify();
    var { assertDefaultLevelFound, mappings, genLsCache, levels } = require_levels();
    var {
      createArgsNormalizer,
      asChindings,
      buildSafeSonicBoom,
      buildFormatters,
      stringify,
      normalizeDestFileDescriptor,
      noop
    } = require_tools();
    var { version } = require_meta();
    var {
      chindingsSym,
      redactFmtSym,
      serializersSym,
      timeSym,
      timeSliceIndexSym,
      streamSym,
      stringifySym,
      stringifySafeSym,
      stringifiersSym,
      setLevelSym,
      endSym,
      formatOptsSym,
      messageKeySym,
      errorKeySym,
      nestedKeySym,
      mixinSym,
      useOnlyCustomLevelsSym,
      formattersSym,
      hooksSym,
      nestedKeyStrSym,
      mixinMergeStrategySym,
      msgPrefixSym
    } = symbols;
    var { epochTime, nullTime } = time;
    var { pid } = process;
    var hostname = os.hostname();
    var defaultErrorSerializer = stdSerializers.err;
    var defaultOptions = {
      level: "info",
      levels,
      messageKey: "msg",
      errorKey: "err",
      nestedKey: null,
      enabled: true,
      base: { pid, hostname },
      serializers: Object.assign(/* @__PURE__ */ Object.create(null), {
        err: defaultErrorSerializer
      }),
      formatters: Object.assign(/* @__PURE__ */ Object.create(null), {
        bindings(bindings) {
          return bindings;
        },
        level(label, number) {
          return { level: number };
        }
      }),
      hooks: {
        logMethod: void 0
      },
      timestamp: epochTime,
      name: void 0,
      redact: null,
      customLevels: null,
      useOnlyCustomLevels: false,
      depthLimit: 5,
      edgeLimit: 100
    };
    var normalize = createArgsNormalizer(defaultOptions);
    var serializers = Object.assign(/* @__PURE__ */ Object.create(null), stdSerializers);
    function pino3(...args) {
      const instance = {};
      const { opts, stream } = normalize(instance, caller(), ...args);
      const {
        redact,
        crlf,
        serializers: serializers2,
        timestamp,
        messageKey,
        errorKey,
        nestedKey,
        base,
        name,
        level,
        customLevels,
        mixin,
        mixinMergeStrategy,
        useOnlyCustomLevels,
        formatters,
        hooks,
        depthLimit,
        edgeLimit,
        onChild,
        msgPrefix
      } = opts;
      const stringifySafe = configure({
        maximumDepth: depthLimit,
        maximumBreadth: edgeLimit
      });
      const allFormatters = buildFormatters(
        formatters.level,
        formatters.bindings,
        formatters.log
      );
      const stringifyFn = stringify.bind({
        [stringifySafeSym]: stringifySafe
      });
      const stringifiers = redact ? redaction(redact, stringifyFn) : {};
      const formatOpts = redact ? { stringify: stringifiers[redactFmtSym] } : { stringify: stringifyFn };
      const end = "}" + (crlf ? "\r\n" : "\n");
      const coreChindings = asChindings.bind(null, {
        [chindingsSym]: "",
        [serializersSym]: serializers2,
        [stringifiersSym]: stringifiers,
        [stringifySym]: stringify,
        [stringifySafeSym]: stringifySafe,
        [formattersSym]: allFormatters
      });
      let chindings = "";
      if (base !== null) {
        if (name === void 0) {
          chindings = coreChindings(base);
        } else {
          chindings = coreChindings(Object.assign({}, base, { name }));
        }
      }
      const time2 = timestamp instanceof Function ? timestamp : timestamp ? epochTime : nullTime;
      const timeSliceIndex = time2().indexOf(":") + 1;
      if (useOnlyCustomLevels && !customLevels)
        throw Error("customLevels is required if useOnlyCustomLevels is set true");
      if (mixin && typeof mixin !== "function")
        throw Error(`Unknown mixin type "${typeof mixin}" - expected "function"`);
      if (msgPrefix && typeof msgPrefix !== "string")
        throw Error(`Unknown msgPrefix type "${typeof msgPrefix}" - expected "string"`);
      assertDefaultLevelFound(level, customLevels, useOnlyCustomLevels);
      const levels2 = mappings(customLevels, useOnlyCustomLevels);
      Object.assign(instance, {
        levels: levels2,
        [useOnlyCustomLevelsSym]: useOnlyCustomLevels,
        [streamSym]: stream,
        [timeSym]: time2,
        [timeSliceIndexSym]: timeSliceIndex,
        [stringifySym]: stringify,
        [stringifySafeSym]: stringifySafe,
        [stringifiersSym]: stringifiers,
        [endSym]: end,
        [formatOptsSym]: formatOpts,
        [messageKeySym]: messageKey,
        [errorKeySym]: errorKey,
        [nestedKeySym]: nestedKey,
        // protect against injection
        [nestedKeyStrSym]: nestedKey ? `,${JSON.stringify(nestedKey)}:{` : "",
        [serializersSym]: serializers2,
        [mixinSym]: mixin,
        [mixinMergeStrategySym]: mixinMergeStrategy,
        [chindingsSym]: chindings,
        [formattersSym]: allFormatters,
        [hooksSym]: hooks,
        silent: noop,
        onChild,
        [msgPrefixSym]: msgPrefix
      });
      Object.setPrototypeOf(instance, proto());
      genLsCache(instance);
      instance[setLevelSym](level);
      return instance;
    }
    module2.exports = pino3;
    module2.exports.destination = (dest = process.stdout.fd) => {
      if (typeof dest === "object") {
        dest.dest = normalizeDestFileDescriptor(dest.dest || process.stdout.fd);
        return buildSafeSonicBoom(dest);
      } else {
        return buildSafeSonicBoom({ dest: normalizeDestFileDescriptor(dest), minLength: 0 });
      }
    };
    module2.exports.transport = require_transport();
    module2.exports.multistream = require_multistream();
    module2.exports.levels = mappings();
    module2.exports.stdSerializers = serializers;
    module2.exports.stdTimeFunctions = Object.assign({}, time);
    module2.exports.symbols = symbols;
    module2.exports.version = version;
    module2.exports.default = pino3;
    module2.exports.pino = pino3;
  }
});

// node_modules/@js-joda/core/dist/js-joda.js
var require_js_joda = __commonJS({
  "node_modules/@js-joda/core/dist/js-joda.js"(exports, module2) {
    (function(global2, factory) {
      typeof exports === "object" && typeof module2 !== "undefined" ? factory(exports) : typeof define === "function" && define.amd ? define(["exports"], factory) : (global2 = typeof globalThis !== "undefined" ? globalThis : global2 || self, factory(global2.JSJoda = {}));
    })(exports, function(exports2) {
      "use strict";
      function createErrorType(name, init2, superErrorClass) {
        if (superErrorClass === void 0) {
          superErrorClass = Error;
        }
        function JsJodaException(message) {
          if (!Error.captureStackTrace) {
            this.stack = new Error().stack;
          } else {
            Error.captureStackTrace(this, this.constructor);
          }
          this.message = message;
          init2 && init2.apply(this, arguments);
          this.toString = function() {
            return this.name + ": " + this.message;
          };
        }
        JsJodaException.prototype = Object.create(superErrorClass.prototype);
        JsJodaException.prototype.name = name;
        JsJodaException.prototype.constructor = JsJodaException;
        return JsJodaException;
      }
      var DateTimeException = createErrorType("DateTimeException", messageWithCause);
      var DateTimeParseException = createErrorType("DateTimeParseException", messageForDateTimeParseException);
      var UnsupportedTemporalTypeException = createErrorType("UnsupportedTemporalTypeException", null, DateTimeException);
      var ArithmeticException = createErrorType("ArithmeticException");
      var IllegalArgumentException = createErrorType("IllegalArgumentException");
      var IllegalStateException = createErrorType("IllegalStateException");
      var NullPointerException = createErrorType("NullPointerException");
      function messageWithCause(message, cause) {
        if (cause === void 0) {
          cause = null;
        }
        var msg = message || this.name;
        if (cause !== null && cause instanceof Error) {
          msg += "\n-------\nCaused by: " + cause.stack + "\n-------\n";
        }
        this.message = msg;
      }
      function messageForDateTimeParseException(message, text, index, cause) {
        if (text === void 0) {
          text = "";
        }
        if (index === void 0) {
          index = 0;
        }
        if (cause === void 0) {
          cause = null;
        }
        var msg = message || this.name;
        msg += ": " + text + ", at index: " + index;
        if (cause !== null && cause instanceof Error) {
          msg += "\n-------\nCaused by: " + cause.stack + "\n-------\n";
        }
        this.message = msg;
        this.parsedString = function() {
          return text;
        };
        this.errorIndex = function() {
          return index;
        };
      }
      function _inheritsLoose(subClass, superClass) {
        subClass.prototype = Object.create(superClass.prototype);
        subClass.prototype.constructor = subClass;
        _setPrototypeOf(subClass, superClass);
      }
      function _setPrototypeOf(o, p) {
        _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p2) {
          o2.__proto__ = p2;
          return o2;
        };
        return _setPrototypeOf(o, p);
      }
      function _assertThisInitialized(self2) {
        if (self2 === void 0) {
          throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        }
        return self2;
      }
      function assert3(assertion, msg, error) {
        if (!assertion) {
          if (error) {
            throw new error(msg);
          } else {
            throw new Error(msg);
          }
        }
      }
      function requireNonNull(value, parameterName) {
        if (value == null) {
          throw new NullPointerException(parameterName + " must not be null");
        }
        return value;
      }
      function requireInstance(value, _class, parameterName) {
        if (!(value instanceof _class)) {
          throw new IllegalArgumentException(parameterName + " must be an instance of " + (_class.name ? _class.name : _class) + (value && value.constructor && value.constructor.name ? ", but is " + value.constructor.name : ""));
        }
        return value;
      }
      function abstractMethodFail(methodName) {
        throw new TypeError('abstract method "' + methodName + '" is not implemented');
      }
      var assert$1 = /* @__PURE__ */ Object.freeze({
        __proto__: null,
        abstractMethodFail,
        assert: assert3,
        requireInstance,
        requireNonNull
      });
      var MAX_SAFE_INTEGER = 9007199254740991;
      var MIN_SAFE_INTEGER = -9007199254740991;
      var MathUtil = function() {
        function MathUtil2() {
        }
        MathUtil2.intDiv = function intDiv(x, y) {
          var r = x / y;
          r = MathUtil2.roundDown(r);
          return MathUtil2.safeZero(r);
        };
        MathUtil2.intMod = function intMod(x, y) {
          var r = x - MathUtil2.intDiv(x, y) * y;
          r = MathUtil2.roundDown(r);
          return MathUtil2.safeZero(r);
        };
        MathUtil2.roundDown = function roundDown(r) {
          if (r < 0) {
            return Math.ceil(r);
          } else {
            return Math.floor(r);
          }
        };
        MathUtil2.floorDiv = function floorDiv(x, y) {
          var r = Math.floor(x / y);
          return MathUtil2.safeZero(r);
        };
        MathUtil2.floorMod = function floorMod(x, y) {
          var r = x - MathUtil2.floorDiv(x, y) * y;
          return MathUtil2.safeZero(r);
        };
        MathUtil2.safeAdd = function safeAdd(x, y) {
          MathUtil2.verifyInt(x);
          MathUtil2.verifyInt(y);
          if (x === 0) {
            return MathUtil2.safeZero(y);
          }
          if (y === 0) {
            return MathUtil2.safeZero(x);
          }
          var r = MathUtil2.safeToInt(x + y);
          if (r === x || r === y) {
            throw new ArithmeticException("Invalid addition beyond MAX_SAFE_INTEGER!");
          }
          return r;
        };
        MathUtil2.safeSubtract = function safeSubtract(x, y) {
          MathUtil2.verifyInt(x);
          MathUtil2.verifyInt(y);
          if (x === 0 && y === 0) {
            return 0;
          } else if (x === 0) {
            return MathUtil2.safeZero(-1 * y);
          } else if (y === 0) {
            return MathUtil2.safeZero(x);
          }
          return MathUtil2.safeToInt(x - y);
        };
        MathUtil2.safeMultiply = function safeMultiply(x, y) {
          MathUtil2.verifyInt(x);
          MathUtil2.verifyInt(y);
          if (x === 1) {
            return MathUtil2.safeZero(y);
          }
          if (y === 1) {
            return MathUtil2.safeZero(x);
          }
          if (x === 0 || y === 0) {
            return 0;
          }
          var r = MathUtil2.safeToInt(x * y);
          if (r / y !== x || x === MIN_SAFE_INTEGER && y === -1 || y === MIN_SAFE_INTEGER && x === -1) {
            throw new ArithmeticException("Multiplication overflows: " + x + " * " + y);
          }
          return r;
        };
        MathUtil2.parseInt = function(_parseInt) {
          function parseInt2(_x) {
            return _parseInt.apply(this, arguments);
          }
          parseInt2.toString = function() {
            return _parseInt.toString();
          };
          return parseInt2;
        }(function(value) {
          var r = parseInt(value);
          return MathUtil2.safeToInt(r);
        });
        MathUtil2.safeToInt = function safeToInt(value) {
          MathUtil2.verifyInt(value);
          return MathUtil2.safeZero(value);
        };
        MathUtil2.verifyInt = function verifyInt(value) {
          if (value == null) {
            throw new ArithmeticException("Invalid value: '" + value + "', using null or undefined as argument");
          }
          if (isNaN(value)) {
            throw new ArithmeticException("Invalid int value, using NaN as argument");
          }
          if (Number.isInteger) {
            if (!Number.isInteger(Number(value))) {
              throw new ArithmeticException("Invalid value: '" + value + "' is a float");
            }
          } else if (value % 1 !== 0) {
            throw new ArithmeticException("Invalid value: '" + value + "' is a float");
          }
          if (value > MAX_SAFE_INTEGER || value < MIN_SAFE_INTEGER) {
            throw new ArithmeticException("Calculation overflows an int: " + value);
          }
        };
        MathUtil2.safeZero = function safeZero(value) {
          return value === 0 ? 0 : +value;
        };
        MathUtil2.compareNumbers = function compareNumbers(a, b) {
          if (a < b) {
            return -1;
          }
          if (a > b) {
            return 1;
          }
          return 0;
        };
        MathUtil2.smi = function smi(int) {
          return int >>> 1 & 1073741824 | int & 3221225471;
        };
        MathUtil2.hash = function hash(number) {
          if (number !== number || number === Infinity) {
            return 0;
          }
          var result = number;
          while (number > 4294967295) {
            number /= 4294967295;
            result ^= number;
          }
          return MathUtil2.smi(result);
        };
        MathUtil2.hashCode = function hashCode() {
          var result = 17;
          for (var _len = arguments.length, numbers = new Array(_len), _key = 0; _key < _len; _key++) {
            numbers[_key] = arguments[_key];
          }
          for (var _i = 0, _numbers = numbers; _i < _numbers.length; _i++) {
            var n = _numbers[_i];
            result = (result << 5) - result + MathUtil2.hash(n);
          }
          return MathUtil2.hash(result);
        };
        return MathUtil2;
      }();
      MathUtil.MAX_SAFE_INTEGER = MAX_SAFE_INTEGER;
      MathUtil.MIN_SAFE_INTEGER = MIN_SAFE_INTEGER;
      var Enum = function() {
        function Enum2(name) {
          this._name = name;
        }
        var _proto = Enum2.prototype;
        _proto.equals = function equals(other) {
          return this === other;
        };
        _proto.toString = function toString() {
          return this._name;
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        return Enum2;
      }();
      var TemporalAmount = function() {
        function TemporalAmount2() {
        }
        var _proto = TemporalAmount2.prototype;
        _proto.get = function get(unit) {
          abstractMethodFail("get");
        };
        _proto.units = function units() {
          abstractMethodFail("units");
        };
        _proto.addTo = function addTo(temporal) {
          abstractMethodFail("addTo");
        };
        _proto.subtractFrom = function subtractFrom(temporal) {
          abstractMethodFail("subtractFrom");
        };
        return TemporalAmount2;
      }();
      if (typeof Symbol !== "undefined" && Symbol.toPrimitive) {
        TemporalAmount.prototype[Symbol.toPrimitive] = function(hint) {
          if (hint !== "number") {
            return this.toString();
          }
          throw new TypeError("A conversion from TemporalAmount to a number is not allowed. To compare use the methods .equals(), .compareTo(), .isBefore() or one that is more suitable to your use case.");
        };
      }
      var TemporalUnit = function() {
        function TemporalUnit2() {
        }
        var _proto = TemporalUnit2.prototype;
        _proto.duration = function duration() {
          abstractMethodFail("duration");
        };
        _proto.isDurationEstimated = function isDurationEstimated() {
          abstractMethodFail("isDurationEstimated");
        };
        _proto.isDateBased = function isDateBased() {
          abstractMethodFail("isDateBased");
        };
        _proto.isTimeBased = function isTimeBased() {
          abstractMethodFail("isTimeBased");
        };
        _proto.isSupportedBy = function isSupportedBy(temporal) {
          abstractMethodFail("isSupportedBy");
        };
        _proto.addTo = function addTo(dateTime, periodToAdd) {
          abstractMethodFail("addTo");
        };
        _proto.between = function between(temporal1, temporal2) {
          abstractMethodFail("between");
        };
        return TemporalUnit2;
      }();
      var Duration = function(_TemporalAmount) {
        _inheritsLoose(Duration2, _TemporalAmount);
        function Duration2(seconds, nanos) {
          var _this;
          _this = _TemporalAmount.call(this) || this;
          _this._seconds = MathUtil.safeToInt(seconds);
          _this._nanos = MathUtil.safeToInt(nanos);
          return _this;
        }
        Duration2.ofDays = function ofDays(days) {
          return Duration2._create(MathUtil.safeMultiply(days, LocalTime.SECONDS_PER_DAY), 0);
        };
        Duration2.ofHours = function ofHours(hours) {
          return Duration2._create(MathUtil.safeMultiply(hours, LocalTime.SECONDS_PER_HOUR), 0);
        };
        Duration2.ofMinutes = function ofMinutes(minutes) {
          return Duration2._create(MathUtil.safeMultiply(minutes, LocalTime.SECONDS_PER_MINUTE), 0);
        };
        Duration2.ofSeconds = function ofSeconds(seconds, nanoAdjustment) {
          if (nanoAdjustment === void 0) {
            nanoAdjustment = 0;
          }
          var secs = MathUtil.safeAdd(seconds, MathUtil.floorDiv(nanoAdjustment, LocalTime.NANOS_PER_SECOND));
          var nos = MathUtil.floorMod(nanoAdjustment, LocalTime.NANOS_PER_SECOND);
          return Duration2._create(secs, nos);
        };
        Duration2.ofMillis = function ofMillis(millis) {
          var secs = MathUtil.intDiv(millis, 1e3);
          var mos = MathUtil.intMod(millis, 1e3);
          if (mos < 0) {
            mos += 1e3;
            secs--;
          }
          return Duration2._create(secs, mos * 1e6);
        };
        Duration2.ofNanos = function ofNanos(nanos) {
          var secs = MathUtil.intDiv(nanos, LocalTime.NANOS_PER_SECOND);
          var nos = MathUtil.intMod(nanos, LocalTime.NANOS_PER_SECOND);
          if (nos < 0) {
            nos += LocalTime.NANOS_PER_SECOND;
            secs--;
          }
          return this._create(secs, nos);
        };
        Duration2.of = function of(amount, unit) {
          return Duration2.ZERO.plus(amount, unit);
        };
        Duration2.from = function from(amount) {
          requireNonNull(amount, "amount");
          requireInstance(amount, TemporalAmount);
          var duration = Duration2.ZERO;
          amount.units().forEach(function(unit) {
            duration = duration.plus(amount.get(unit), unit);
          });
          return duration;
        };
        Duration2.between = function between(startInclusive, endExclusive) {
          requireNonNull(startInclusive, "startInclusive");
          requireNonNull(endExclusive, "endExclusive");
          var secs = startInclusive.until(endExclusive, ChronoUnit.SECONDS);
          var nanos = 0;
          if (startInclusive.isSupported(ChronoField.NANO_OF_SECOND) && endExclusive.isSupported(ChronoField.NANO_OF_SECOND)) {
            try {
              var startNos = startInclusive.getLong(ChronoField.NANO_OF_SECOND);
              nanos = endExclusive.getLong(ChronoField.NANO_OF_SECOND) - startNos;
              if (secs > 0 && nanos < 0) {
                nanos += LocalTime.NANOS_PER_SECOND;
              } else if (secs < 0 && nanos > 0) {
                nanos -= LocalTime.NANOS_PER_SECOND;
              } else if (secs === 0 && nanos !== 0) {
                var adjustedEnd = endExclusive.with(ChronoField.NANO_OF_SECOND, startNos);
                secs = startInclusive.until(adjustedEnd, ChronoUnit.SECONDS);
              }
            } catch (e) {
            }
          }
          return this.ofSeconds(secs, nanos);
        };
        Duration2.parse = function parse(text) {
          requireNonNull(text, "text");
          var PATTERN2 = new RegExp("([-+]?)P(?:([-+]?[0-9]+)D)?(T(?:([-+]?[0-9]+)H)?(?:([-+]?[0-9]+)M)?(?:([-+]?[0-9]+)(?:[.,]([0-9]{0,9}))?S)?)?", "i");
          var matches = PATTERN2.exec(text);
          if (matches !== null) {
            if ("T" === matches[3] === false) {
              var negate = "-" === matches[1];
              var dayMatch = matches[2];
              var hourMatch = matches[4];
              var minuteMatch = matches[5];
              var secondMatch = matches[6];
              var fractionMatch = matches[7];
              if (dayMatch != null || hourMatch != null || minuteMatch != null || secondMatch != null) {
                var daysAsSecs = Duration2._parseNumber(text, dayMatch, LocalTime.SECONDS_PER_DAY, "days");
                var hoursAsSecs = Duration2._parseNumber(text, hourMatch, LocalTime.SECONDS_PER_HOUR, "hours");
                var minsAsSecs = Duration2._parseNumber(text, minuteMatch, LocalTime.SECONDS_PER_MINUTE, "minutes");
                var seconds = Duration2._parseNumber(text, secondMatch, 1, "seconds");
                var negativeSecs = secondMatch != null && secondMatch.charAt(0) === "-";
                var nanos = Duration2._parseFraction(text, fractionMatch, negativeSecs ? -1 : 1);
                try {
                  return Duration2._create(negate, daysAsSecs, hoursAsSecs, minsAsSecs, seconds, nanos);
                } catch (ex) {
                  throw new DateTimeParseException("Text cannot be parsed to a Duration: overflow", text, 0, ex);
                }
              }
            }
          }
          throw new DateTimeParseException("Text cannot be parsed to a Duration", text, 0);
        };
        Duration2._parseNumber = function _parseNumber(text, parsed, multiplier, errorText) {
          if (parsed == null) {
            return 0;
          }
          try {
            if (parsed[0] === "+") {
              parsed = parsed.substring(1);
            }
            return MathUtil.safeMultiply(parseFloat(parsed), multiplier);
          } catch (ex) {
            throw new DateTimeParseException("Text cannot be parsed to a Duration: " + errorText, text, 0, ex);
          }
        };
        Duration2._parseFraction = function _parseFraction(text, parsed, negate) {
          if (parsed == null || parsed.length === 0) {
            return 0;
          }
          parsed = (parsed + "000000000").substring(0, 9);
          return parseFloat(parsed) * negate;
        };
        Duration2._create = function _create() {
          if (arguments.length <= 2) {
            return Duration2._createSecondsNanos(arguments[0], arguments[1]);
          } else {
            return Duration2._createNegateDaysHoursMinutesSecondsNanos(arguments[0], arguments[1], arguments[2], arguments[3], arguments[4], arguments[5]);
          }
        };
        Duration2._createNegateDaysHoursMinutesSecondsNanos = function _createNegateDaysHoursMinutesSecondsNanos(negate, daysAsSecs, hoursAsSecs, minsAsSecs, secs, nanos) {
          var seconds = MathUtil.safeAdd(daysAsSecs, MathUtil.safeAdd(hoursAsSecs, MathUtil.safeAdd(minsAsSecs, secs)));
          if (negate) {
            return Duration2.ofSeconds(seconds, nanos).negated();
          }
          return Duration2.ofSeconds(seconds, nanos);
        };
        Duration2._createSecondsNanos = function _createSecondsNanos(seconds, nanoAdjustment) {
          if (seconds === void 0) {
            seconds = 0;
          }
          if (nanoAdjustment === void 0) {
            nanoAdjustment = 0;
          }
          if (seconds === 0 && nanoAdjustment === 0) {
            return Duration2.ZERO;
          }
          return new Duration2(seconds, nanoAdjustment);
        };
        var _proto = Duration2.prototype;
        _proto.get = function get(unit) {
          if (unit === ChronoUnit.SECONDS) {
            return this._seconds;
          } else if (unit === ChronoUnit.NANOS) {
            return this._nanos;
          } else {
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
        };
        _proto.units = function units() {
          return [ChronoUnit.SECONDS, ChronoUnit.NANOS];
        };
        _proto.isZero = function isZero() {
          return this._seconds === 0 && this._nanos === 0;
        };
        _proto.isNegative = function isNegative() {
          return this._seconds < 0;
        };
        _proto.seconds = function seconds() {
          return this._seconds;
        };
        _proto.nano = function nano() {
          return this._nanos;
        };
        _proto.withSeconds = function withSeconds(seconds) {
          return Duration2._create(seconds, this._nanos);
        };
        _proto.withNanos = function withNanos(nanoOfSecond) {
          ChronoField.NANO_OF_SECOND.checkValidIntValue(nanoOfSecond);
          return Duration2._create(this._seconds, nanoOfSecond);
        };
        _proto.plusDuration = function plusDuration(duration) {
          requireNonNull(duration, "duration");
          return this.plus(duration.seconds(), duration.nano());
        };
        _proto.plus = function plus(durationOrNumber, unitOrNumber) {
          if (arguments.length === 1) {
            return this.plusDuration(durationOrNumber);
          } else if (arguments.length === 2 && unitOrNumber instanceof TemporalUnit) {
            return this.plusAmountUnit(durationOrNumber, unitOrNumber);
          } else {
            return this.plusSecondsNanos(durationOrNumber, unitOrNumber);
          }
        };
        _proto.plusAmountUnit = function plusAmountUnit(amountToAdd, unit) {
          requireNonNull(amountToAdd, "amountToAdd");
          requireNonNull(unit, "unit");
          if (unit === ChronoUnit.DAYS) {
            return this.plusSecondsNanos(MathUtil.safeMultiply(amountToAdd, LocalTime.SECONDS_PER_DAY), 0);
          }
          if (unit.isDurationEstimated()) {
            throw new UnsupportedTemporalTypeException("Unit must not have an estimated duration");
          }
          if (amountToAdd === 0) {
            return this;
          }
          if (unit instanceof ChronoUnit) {
            switch (unit) {
              case ChronoUnit.NANOS:
                return this.plusNanos(amountToAdd);
              case ChronoUnit.MICROS:
                return this.plusSecondsNanos(MathUtil.intDiv(amountToAdd, 1e6 * 1e3) * 1e3, MathUtil.intMod(amountToAdd, 1e6 * 1e3) * 1e3);
              case ChronoUnit.MILLIS:
                return this.plusMillis(amountToAdd);
              case ChronoUnit.SECONDS:
                return this.plusSeconds(amountToAdd);
            }
            return this.plusSecondsNanos(MathUtil.safeMultiply(unit.duration().seconds(), amountToAdd), 0);
          }
          var duration = unit.duration().multipliedBy(amountToAdd);
          return this.plusSecondsNanos(duration.seconds(), duration.nano());
        };
        _proto.plusDays = function plusDays(daysToAdd) {
          return this.plusSecondsNanos(MathUtil.safeMultiply(daysToAdd, LocalTime.SECONDS_PER_DAY), 0);
        };
        _proto.plusHours = function plusHours(hoursToAdd) {
          return this.plusSecondsNanos(MathUtil.safeMultiply(hoursToAdd, LocalTime.SECONDS_PER_HOUR), 0);
        };
        _proto.plusMinutes = function plusMinutes(minutesToAdd) {
          return this.plusSecondsNanos(MathUtil.safeMultiply(minutesToAdd, LocalTime.SECONDS_PER_MINUTE), 0);
        };
        _proto.plusSeconds = function plusSeconds(secondsToAdd) {
          return this.plusSecondsNanos(secondsToAdd, 0);
        };
        _proto.plusMillis = function plusMillis(millisToAdd) {
          return this.plusSecondsNanos(MathUtil.intDiv(millisToAdd, 1e3), MathUtil.intMod(millisToAdd, 1e3) * 1e6);
        };
        _proto.plusNanos = function plusNanos(nanosToAdd) {
          return this.plusSecondsNanos(0, nanosToAdd);
        };
        _proto.plusSecondsNanos = function plusSecondsNanos(secondsToAdd, nanosToAdd) {
          requireNonNull(secondsToAdd, "secondsToAdd");
          requireNonNull(nanosToAdd, "nanosToAdd");
          if (secondsToAdd === 0 && nanosToAdd === 0) {
            return this;
          }
          var epochSec = MathUtil.safeAdd(this._seconds, secondsToAdd);
          epochSec = MathUtil.safeAdd(epochSec, MathUtil.intDiv(nanosToAdd, LocalTime.NANOS_PER_SECOND));
          nanosToAdd = MathUtil.intMod(nanosToAdd, LocalTime.NANOS_PER_SECOND);
          var nanoAdjustment = MathUtil.safeAdd(this._nanos, nanosToAdd);
          return Duration2.ofSeconds(epochSec, nanoAdjustment);
        };
        _proto.minus = function minus(durationOrNumber, unit) {
          if (arguments.length === 1) {
            return this.minusDuration(durationOrNumber);
          } else {
            return this.minusAmountUnit(durationOrNumber, unit);
          }
        };
        _proto.minusDuration = function minusDuration(duration) {
          requireNonNull(duration, "duration");
          var secsToSubtract = duration.seconds();
          var nanosToSubtract = duration.nano();
          if (secsToSubtract === MIN_SAFE_INTEGER) {
            return this.plus(MAX_SAFE_INTEGER, -nanosToSubtract);
          }
          return this.plus(-secsToSubtract, -nanosToSubtract);
        };
        _proto.minusAmountUnit = function minusAmountUnit(amountToSubtract, unit) {
          requireNonNull(amountToSubtract, "amountToSubtract");
          requireNonNull(unit, "unit");
          return amountToSubtract === MIN_SAFE_INTEGER ? this.plusAmountUnit(MAX_SAFE_INTEGER, unit) : this.plusAmountUnit(-amountToSubtract, unit);
        };
        _proto.minusDays = function minusDays(daysToSubtract) {
          return daysToSubtract === MIN_SAFE_INTEGER ? this.plusDays(MAX_SAFE_INTEGER) : this.plusDays(-daysToSubtract);
        };
        _proto.minusHours = function minusHours(hoursToSubtract) {
          return hoursToSubtract === MIN_SAFE_INTEGER ? this.plusHours(MAX_SAFE_INTEGER) : this.plusHours(-hoursToSubtract);
        };
        _proto.minusMinutes = function minusMinutes(minutesToSubtract) {
          return minutesToSubtract === MIN_SAFE_INTEGER ? this.plusMinutes(MAX_SAFE_INTEGER) : this.plusMinutes(-minutesToSubtract);
        };
        _proto.minusSeconds = function minusSeconds(secondsToSubtract) {
          return secondsToSubtract === MIN_SAFE_INTEGER ? this.plusSeconds(MAX_SAFE_INTEGER) : this.plusSeconds(-secondsToSubtract);
        };
        _proto.minusMillis = function minusMillis(millisToSubtract) {
          return millisToSubtract === MIN_SAFE_INTEGER ? this.plusMillis(MAX_SAFE_INTEGER) : this.plusMillis(-millisToSubtract);
        };
        _proto.minusNanos = function minusNanos(nanosToSubtract) {
          return nanosToSubtract === MIN_SAFE_INTEGER ? this.plusNanos(MAX_SAFE_INTEGER) : this.plusNanos(-nanosToSubtract);
        };
        _proto.multipliedBy = function multipliedBy(multiplicand) {
          if (multiplicand === 0) {
            return Duration2.ZERO;
          }
          if (multiplicand === 1) {
            return this;
          }
          var secs = MathUtil.safeMultiply(this._seconds, multiplicand);
          var nos = MathUtil.safeMultiply(this._nanos, multiplicand);
          secs = secs + MathUtil.intDiv(nos, LocalTime.NANOS_PER_SECOND);
          nos = MathUtil.intMod(nos, LocalTime.NANOS_PER_SECOND);
          return Duration2.ofSeconds(secs, nos);
        };
        _proto.dividedBy = function dividedBy(divisor) {
          if (divisor === 0) {
            throw new ArithmeticException("Cannot divide by zero");
          }
          if (divisor === 1) {
            return this;
          }
          var secs = MathUtil.intDiv(this._seconds, divisor);
          var secsMod = MathUtil.roundDown((this._seconds / divisor - secs) * LocalTime.NANOS_PER_SECOND);
          var nos = MathUtil.intDiv(this._nanos, divisor);
          nos = secsMod + nos;
          return Duration2.ofSeconds(secs, nos);
        };
        _proto.negated = function negated() {
          return this.multipliedBy(-1);
        };
        _proto.abs = function abs() {
          return this.isNegative() ? this.negated() : this;
        };
        _proto.addTo = function addTo(temporal) {
          requireNonNull(temporal, "temporal");
          if (this._seconds !== 0) {
            temporal = temporal.plus(this._seconds, ChronoUnit.SECONDS);
          }
          if (this._nanos !== 0) {
            temporal = temporal.plus(this._nanos, ChronoUnit.NANOS);
          }
          return temporal;
        };
        _proto.subtractFrom = function subtractFrom(temporal) {
          requireNonNull(temporal, "temporal");
          if (this._seconds !== 0) {
            temporal = temporal.minus(this._seconds, ChronoUnit.SECONDS);
          }
          if (this._nanos !== 0) {
            temporal = temporal.minus(this._nanos, ChronoUnit.NANOS);
          }
          return temporal;
        };
        _proto.toDays = function toDays() {
          return MathUtil.intDiv(this._seconds, LocalTime.SECONDS_PER_DAY);
        };
        _proto.toHours = function toHours() {
          return MathUtil.intDiv(this._seconds, LocalTime.SECONDS_PER_HOUR);
        };
        _proto.toMinutes = function toMinutes() {
          return MathUtil.intDiv(this._seconds, LocalTime.SECONDS_PER_MINUTE);
        };
        _proto.toMillis = function toMillis() {
          var millis = Math.round(MathUtil.safeMultiply(this._seconds, 1e3));
          millis = MathUtil.safeAdd(millis, MathUtil.intDiv(this._nanos, 1e6));
          return millis;
        };
        _proto.toNanos = function toNanos() {
          var totalNanos = MathUtil.safeMultiply(this._seconds, LocalTime.NANOS_PER_SECOND);
          totalNanos = MathUtil.safeAdd(totalNanos, this._nanos);
          return totalNanos;
        };
        _proto.compareTo = function compareTo(otherDuration) {
          requireNonNull(otherDuration, "otherDuration");
          requireInstance(otherDuration, Duration2, "otherDuration");
          var cmp = MathUtil.compareNumbers(this._seconds, otherDuration.seconds());
          if (cmp !== 0) {
            return cmp;
          }
          return this._nanos - otherDuration.nano();
        };
        _proto.equals = function equals(otherDuration) {
          if (this === otherDuration) {
            return true;
          }
          if (otherDuration instanceof Duration2) {
            return this.seconds() === otherDuration.seconds() && this.nano() === otherDuration.nano();
          }
          return false;
        };
        _proto.toString = function toString() {
          if (this === Duration2.ZERO) {
            return "PT0S";
          }
          var hours = MathUtil.intDiv(this._seconds, LocalTime.SECONDS_PER_HOUR);
          var minutes = MathUtil.intDiv(MathUtil.intMod(this._seconds, LocalTime.SECONDS_PER_HOUR), LocalTime.SECONDS_PER_MINUTE);
          var secs = MathUtil.intMod(this._seconds, LocalTime.SECONDS_PER_MINUTE);
          var rval = "PT";
          if (hours !== 0) {
            rval += hours + "H";
          }
          if (minutes !== 0) {
            rval += minutes + "M";
          }
          if (secs === 0 && this._nanos === 0 && rval.length > 2) {
            return rval;
          }
          if (secs < 0 && this._nanos > 0) {
            if (secs === -1) {
              rval += "-0";
            } else {
              rval += secs + 1;
            }
          } else {
            rval += secs;
          }
          if (this._nanos > 0) {
            rval += ".";
            var nanoString;
            if (secs < 0) {
              nanoString = "" + (2 * LocalTime.NANOS_PER_SECOND - this._nanos);
            } else {
              nanoString = "" + (LocalTime.NANOS_PER_SECOND + this._nanos);
            }
            nanoString = nanoString.slice(1, nanoString.length);
            rval += nanoString;
            while (rval.charAt(rval.length - 1) === "0") {
              rval = rval.slice(0, rval.length - 1);
            }
          }
          rval += "S";
          return rval;
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        return Duration2;
      }(TemporalAmount);
      function _init$n() {
        Duration.ZERO = new Duration(0, 0);
      }
      var YearConstants = function YearConstants2() {
      };
      function _init$m() {
        YearConstants.MIN_VALUE = -999999;
        YearConstants.MAX_VALUE = 999999;
      }
      var ChronoUnit = function(_TemporalUnit) {
        _inheritsLoose(ChronoUnit2, _TemporalUnit);
        function ChronoUnit2(name, estimatedDuration) {
          var _this;
          _this = _TemporalUnit.call(this) || this;
          _this._name = name;
          _this._duration = estimatedDuration;
          return _this;
        }
        var _proto = ChronoUnit2.prototype;
        _proto.duration = function duration() {
          return this._duration;
        };
        _proto.isDurationEstimated = function isDurationEstimated() {
          return this.isDateBased() || this === ChronoUnit2.FOREVER;
        };
        _proto.isDateBased = function isDateBased() {
          return this.compareTo(ChronoUnit2.DAYS) >= 0 && this !== ChronoUnit2.FOREVER;
        };
        _proto.isTimeBased = function isTimeBased() {
          return this.compareTo(ChronoUnit2.DAYS) < 0;
        };
        _proto.isSupportedBy = function isSupportedBy(temporal) {
          if (this === ChronoUnit2.FOREVER) {
            return false;
          }
          try {
            temporal.plus(1, this);
            return true;
          } catch (e) {
            try {
              temporal.plus(-1, this);
              return true;
            } catch (e2) {
              return false;
            }
          }
        };
        _proto.addTo = function addTo(temporal, amount) {
          return temporal.plus(amount, this);
        };
        _proto.between = function between(temporal1, temporal2) {
          return temporal1.until(temporal2, this);
        };
        _proto.toString = function toString() {
          return this._name;
        };
        _proto.compareTo = function compareTo(other) {
          return this.duration().compareTo(other.duration());
        };
        return ChronoUnit2;
      }(TemporalUnit);
      function _init$l() {
        ChronoUnit.NANOS = new ChronoUnit("Nanos", Duration.ofNanos(1));
        ChronoUnit.MICROS = new ChronoUnit("Micros", Duration.ofNanos(1e3));
        ChronoUnit.MILLIS = new ChronoUnit("Millis", Duration.ofNanos(1e6));
        ChronoUnit.SECONDS = new ChronoUnit("Seconds", Duration.ofSeconds(1));
        ChronoUnit.MINUTES = new ChronoUnit("Minutes", Duration.ofSeconds(60));
        ChronoUnit.HOURS = new ChronoUnit("Hours", Duration.ofSeconds(3600));
        ChronoUnit.HALF_DAYS = new ChronoUnit("HalfDays", Duration.ofSeconds(43200));
        ChronoUnit.DAYS = new ChronoUnit("Days", Duration.ofSeconds(86400));
        ChronoUnit.WEEKS = new ChronoUnit("Weeks", Duration.ofSeconds(7 * 86400));
        ChronoUnit.MONTHS = new ChronoUnit("Months", Duration.ofSeconds(31556952 / 12));
        ChronoUnit.YEARS = new ChronoUnit("Years", Duration.ofSeconds(31556952));
        ChronoUnit.DECADES = new ChronoUnit("Decades", Duration.ofSeconds(31556952 * 10));
        ChronoUnit.CENTURIES = new ChronoUnit("Centuries", Duration.ofSeconds(31556952 * 100));
        ChronoUnit.MILLENNIA = new ChronoUnit("Millennia", Duration.ofSeconds(31556952 * 1e3));
        ChronoUnit.ERAS = new ChronoUnit("Eras", Duration.ofSeconds(31556952 * (YearConstants.MAX_VALUE + 1)));
        ChronoUnit.FOREVER = new ChronoUnit("Forever", Duration.ofSeconds(MathUtil.MAX_SAFE_INTEGER, 999999999));
      }
      var TemporalField = function() {
        function TemporalField2() {
        }
        var _proto = TemporalField2.prototype;
        _proto.isDateBased = function isDateBased() {
          abstractMethodFail("isDateBased");
        };
        _proto.isTimeBased = function isTimeBased() {
          abstractMethodFail("isTimeBased");
        };
        _proto.baseUnit = function baseUnit() {
          abstractMethodFail("baseUnit");
        };
        _proto.rangeUnit = function rangeUnit() {
          abstractMethodFail("rangeUnit");
        };
        _proto.range = function range() {
          abstractMethodFail("range");
        };
        _proto.rangeRefinedBy = function rangeRefinedBy(temporal) {
          abstractMethodFail("rangeRefinedBy");
        };
        _proto.getFrom = function getFrom(temporal) {
          abstractMethodFail("getFrom");
        };
        _proto.adjustInto = function adjustInto(temporal, newValue) {
          abstractMethodFail("adjustInto");
        };
        _proto.isSupportedBy = function isSupportedBy(temporal) {
          abstractMethodFail("isSupportedBy");
        };
        _proto.displayName = function displayName() {
          abstractMethodFail("displayName");
        };
        _proto.equals = function equals(other) {
          abstractMethodFail("equals");
        };
        _proto.name = function name() {
          abstractMethodFail("name");
        };
        return TemporalField2;
      }();
      var ValueRange = function() {
        function ValueRange2(minSmallest, minLargest, maxSmallest, maxLargest) {
          assert3(!(minSmallest > minLargest), "Smallest minimum value '" + minSmallest + "' must be less than largest minimum value '" + minLargest + "'", IllegalArgumentException);
          assert3(!(maxSmallest > maxLargest), "Smallest maximum value '" + maxSmallest + "' must be less than largest maximum value '" + maxLargest + "'", IllegalArgumentException);
          assert3(!(minLargest > maxLargest), "Minimum value '" + minLargest + "' must be less than maximum value '" + maxLargest + "'", IllegalArgumentException);
          this._minSmallest = minSmallest;
          this._minLargest = minLargest;
          this._maxLargest = maxLargest;
          this._maxSmallest = maxSmallest;
        }
        var _proto = ValueRange2.prototype;
        _proto.isFixed = function isFixed() {
          return this._minSmallest === this._minLargest && this._maxSmallest === this._maxLargest;
        };
        _proto.minimum = function minimum() {
          return this._minSmallest;
        };
        _proto.largestMinimum = function largestMinimum() {
          return this._minLargest;
        };
        _proto.maximum = function maximum() {
          return this._maxLargest;
        };
        _proto.smallestMaximum = function smallestMaximum() {
          return this._maxSmallest;
        };
        _proto.isValidValue = function isValidValue(value) {
          return this.minimum() <= value && value <= this.maximum();
        };
        _proto.checkValidValue = function checkValidValue(value, field) {
          var msg;
          if (!this.isValidValue(value)) {
            if (field != null) {
              msg = "Invalid value for " + field + " (valid values " + this.toString() + "): " + value;
            } else {
              msg = "Invalid value (valid values " + this.toString() + "): " + value;
            }
            return assert3(false, msg, DateTimeException);
          }
          return value;
        };
        _proto.checkValidIntValue = function checkValidIntValue(value, field) {
          if (this.isValidIntValue(value) === false) {
            throw new DateTimeException("Invalid int value for " + field + ": " + value);
          }
          return value;
        };
        _proto.isValidIntValue = function isValidIntValue(value) {
          return this.isIntValue() && this.isValidValue(value);
        };
        _proto.isIntValue = function isIntValue() {
          return this.minimum() >= MathUtil.MIN_SAFE_INTEGER && this.maximum() <= MathUtil.MAX_SAFE_INTEGER;
        };
        _proto.equals = function equals(other) {
          if (other === this) {
            return true;
          }
          if (other instanceof ValueRange2) {
            return this._minSmallest === other._minSmallest && this._minLargest === other._minLargest && this._maxSmallest === other._maxSmallest && this._maxLargest === other._maxLargest;
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          return MathUtil.hashCode(this._minSmallest, this._minLargest, this._maxSmallest, this._maxLargest);
        };
        _proto.toString = function toString() {
          var str = this.minimum() + (this.minimum() !== this.largestMinimum() ? "/" + this.largestMinimum() : "");
          str += " - ";
          str += this.smallestMaximum() + (this.smallestMaximum() !== this.maximum() ? "/" + this.maximum() : "");
          return str;
        };
        ValueRange2.of = function of() {
          if (arguments.length === 2) {
            return new ValueRange2(arguments[0], arguments[0], arguments[1], arguments[1]);
          } else if (arguments.length === 3) {
            return new ValueRange2(arguments[0], arguments[0], arguments[1], arguments[2]);
          } else if (arguments.length === 4) {
            return new ValueRange2(arguments[0], arguments[1], arguments[2], arguments[3]);
          } else {
            return assert3(false, "Invalid number of arguments " + arguments.length, IllegalArgumentException);
          }
        };
        return ValueRange2;
      }();
      var ChronoField = function(_TemporalField) {
        _inheritsLoose(ChronoField2, _TemporalField);
        ChronoField2.byName = function byName(fieldName) {
          for (var prop in ChronoField2) {
            if (ChronoField2[prop]) {
              if (ChronoField2[prop] instanceof ChronoField2 && ChronoField2[prop].name() === fieldName) {
                return ChronoField2[prop];
              }
            }
          }
        };
        function ChronoField2(name, baseUnit, rangeUnit, range) {
          var _this;
          _this = _TemporalField.call(this) || this;
          _this._name = name;
          _this._baseUnit = baseUnit;
          _this._rangeUnit = rangeUnit;
          _this._range = range;
          return _this;
        }
        var _proto = ChronoField2.prototype;
        _proto.name = function name() {
          return this._name;
        };
        _proto.baseUnit = function baseUnit() {
          return this._baseUnit;
        };
        _proto.rangeUnit = function rangeUnit() {
          return this._rangeUnit;
        };
        _proto.range = function range() {
          return this._range;
        };
        _proto.displayName = function displayName() {
          return this.toString();
        };
        _proto.checkValidValue = function checkValidValue(value) {
          return this.range().checkValidValue(value, this);
        };
        _proto.checkValidIntValue = function checkValidIntValue(value) {
          return this.range().checkValidIntValue(value, this);
        };
        _proto.isDateBased = function isDateBased() {
          var dateBased = this === ChronoField2.DAY_OF_WEEK || this === ChronoField2.ALIGNED_DAY_OF_WEEK_IN_MONTH || this === ChronoField2.ALIGNED_DAY_OF_WEEK_IN_YEAR || this === ChronoField2.DAY_OF_MONTH || this === ChronoField2.DAY_OF_YEAR || this === ChronoField2.EPOCH_DAY || this === ChronoField2.ALIGNED_WEEK_OF_MONTH || this === ChronoField2.ALIGNED_WEEK_OF_YEAR || this === ChronoField2.MONTH_OF_YEAR || this === ChronoField2.PROLEPTIC_MONTH || this === ChronoField2.YEAR_OF_ERA || this === ChronoField2.YEAR || this === ChronoField2.ERA;
          return dateBased;
        };
        _proto.isTimeBased = function isTimeBased() {
          var timeBased = this === ChronoField2.NANO_OF_SECOND || this === ChronoField2.NANO_OF_DAY || this === ChronoField2.MICRO_OF_SECOND || this === ChronoField2.MICRO_OF_DAY || this === ChronoField2.MILLI_OF_SECOND || this === ChronoField2.MILLI_OF_DAY || this === ChronoField2.SECOND_OF_MINUTE || this === ChronoField2.SECOND_OF_DAY || this === ChronoField2.MINUTE_OF_HOUR || this === ChronoField2.MINUTE_OF_DAY || this === ChronoField2.HOUR_OF_AMPM || this === ChronoField2.CLOCK_HOUR_OF_AMPM || this === ChronoField2.HOUR_OF_DAY || this === ChronoField2.CLOCK_HOUR_OF_DAY || this === ChronoField2.AMPM_OF_DAY;
          return timeBased;
        };
        _proto.rangeRefinedBy = function rangeRefinedBy(temporal) {
          return temporal.range(this);
        };
        _proto.getFrom = function getFrom(temporal) {
          return temporal.getLong(this);
        };
        _proto.toString = function toString() {
          return this.name();
        };
        _proto.equals = function equals(other) {
          return this === other;
        };
        _proto.adjustInto = function adjustInto(temporal, newValue) {
          return temporal.with(this, newValue);
        };
        _proto.isSupportedBy = function isSupportedBy(temporal) {
          return temporal.isSupported(this);
        };
        return ChronoField2;
      }(TemporalField);
      function _init$k() {
        ChronoField.NANO_OF_SECOND = new ChronoField("NanoOfSecond", ChronoUnit.NANOS, ChronoUnit.SECONDS, ValueRange.of(0, 999999999));
        ChronoField.NANO_OF_DAY = new ChronoField("NanoOfDay", ChronoUnit.NANOS, ChronoUnit.DAYS, ValueRange.of(0, 86400 * 1e9 - 1));
        ChronoField.MICRO_OF_SECOND = new ChronoField("MicroOfSecond", ChronoUnit.MICROS, ChronoUnit.SECONDS, ValueRange.of(0, 999999));
        ChronoField.MICRO_OF_DAY = new ChronoField("MicroOfDay", ChronoUnit.MICROS, ChronoUnit.DAYS, ValueRange.of(0, 86400 * 1e6 - 1));
        ChronoField.MILLI_OF_SECOND = new ChronoField("MilliOfSecond", ChronoUnit.MILLIS, ChronoUnit.SECONDS, ValueRange.of(0, 999));
        ChronoField.MILLI_OF_DAY = new ChronoField("MilliOfDay", ChronoUnit.MILLIS, ChronoUnit.DAYS, ValueRange.of(0, 86400 * 1e3 - 1));
        ChronoField.SECOND_OF_MINUTE = new ChronoField("SecondOfMinute", ChronoUnit.SECONDS, ChronoUnit.MINUTES, ValueRange.of(0, 59));
        ChronoField.SECOND_OF_DAY = new ChronoField("SecondOfDay", ChronoUnit.SECONDS, ChronoUnit.DAYS, ValueRange.of(0, 86400 - 1));
        ChronoField.MINUTE_OF_HOUR = new ChronoField("MinuteOfHour", ChronoUnit.MINUTES, ChronoUnit.HOURS, ValueRange.of(0, 59));
        ChronoField.MINUTE_OF_DAY = new ChronoField("MinuteOfDay", ChronoUnit.MINUTES, ChronoUnit.DAYS, ValueRange.of(0, 24 * 60 - 1));
        ChronoField.HOUR_OF_AMPM = new ChronoField("HourOfAmPm", ChronoUnit.HOURS, ChronoUnit.HALF_DAYS, ValueRange.of(0, 11));
        ChronoField.CLOCK_HOUR_OF_AMPM = new ChronoField("ClockHourOfAmPm", ChronoUnit.HOURS, ChronoUnit.HALF_DAYS, ValueRange.of(1, 12));
        ChronoField.HOUR_OF_DAY = new ChronoField("HourOfDay", ChronoUnit.HOURS, ChronoUnit.DAYS, ValueRange.of(0, 23));
        ChronoField.CLOCK_HOUR_OF_DAY = new ChronoField("ClockHourOfDay", ChronoUnit.HOURS, ChronoUnit.DAYS, ValueRange.of(1, 24));
        ChronoField.AMPM_OF_DAY = new ChronoField("AmPmOfDay", ChronoUnit.HALF_DAYS, ChronoUnit.DAYS, ValueRange.of(0, 1));
        ChronoField.DAY_OF_WEEK = new ChronoField("DayOfWeek", ChronoUnit.DAYS, ChronoUnit.WEEKS, ValueRange.of(1, 7));
        ChronoField.ALIGNED_DAY_OF_WEEK_IN_MONTH = new ChronoField("AlignedDayOfWeekInMonth", ChronoUnit.DAYS, ChronoUnit.WEEKS, ValueRange.of(1, 7));
        ChronoField.ALIGNED_DAY_OF_WEEK_IN_YEAR = new ChronoField("AlignedDayOfWeekInYear", ChronoUnit.DAYS, ChronoUnit.WEEKS, ValueRange.of(1, 7));
        ChronoField.DAY_OF_MONTH = new ChronoField("DayOfMonth", ChronoUnit.DAYS, ChronoUnit.MONTHS, ValueRange.of(1, 28, 31), "day");
        ChronoField.DAY_OF_YEAR = new ChronoField("DayOfYear", ChronoUnit.DAYS, ChronoUnit.YEARS, ValueRange.of(1, 365, 366));
        ChronoField.EPOCH_DAY = new ChronoField("EpochDay", ChronoUnit.DAYS, ChronoUnit.FOREVER, ValueRange.of(-365961662, 364522971));
        ChronoField.ALIGNED_WEEK_OF_MONTH = new ChronoField("AlignedWeekOfMonth", ChronoUnit.WEEKS, ChronoUnit.MONTHS, ValueRange.of(1, 4, 5));
        ChronoField.ALIGNED_WEEK_OF_YEAR = new ChronoField("AlignedWeekOfYear", ChronoUnit.WEEKS, ChronoUnit.YEARS, ValueRange.of(1, 53));
        ChronoField.MONTH_OF_YEAR = new ChronoField("MonthOfYear", ChronoUnit.MONTHS, ChronoUnit.YEARS, ValueRange.of(1, 12), "month");
        ChronoField.PROLEPTIC_MONTH = new ChronoField("ProlepticMonth", ChronoUnit.MONTHS, ChronoUnit.FOREVER, ValueRange.of(YearConstants.MIN_VALUE * 12, YearConstants.MAX_VALUE * 12 + 11));
        ChronoField.YEAR_OF_ERA = new ChronoField("YearOfEra", ChronoUnit.YEARS, ChronoUnit.FOREVER, ValueRange.of(1, YearConstants.MAX_VALUE, YearConstants.MAX_VALUE + 1));
        ChronoField.YEAR = new ChronoField("Year", ChronoUnit.YEARS, ChronoUnit.FOREVER, ValueRange.of(YearConstants.MIN_VALUE, YearConstants.MAX_VALUE), "year");
        ChronoField.ERA = new ChronoField("Era", ChronoUnit.ERAS, ChronoUnit.FOREVER, ValueRange.of(0, 1));
        ChronoField.INSTANT_SECONDS = new ChronoField("InstantSeconds", ChronoUnit.SECONDS, ChronoUnit.FOREVER, ValueRange.of(MIN_SAFE_INTEGER, MAX_SAFE_INTEGER));
        ChronoField.OFFSET_SECONDS = new ChronoField("OffsetSeconds", ChronoUnit.SECONDS, ChronoUnit.FOREVER, ValueRange.of(-18 * 3600, 18 * 3600));
      }
      var TemporalQueries = function() {
        function TemporalQueries2() {
        }
        TemporalQueries2.zoneId = function zoneId() {
          return TemporalQueries2.ZONE_ID;
        };
        TemporalQueries2.chronology = function chronology() {
          return TemporalQueries2.CHRONO;
        };
        TemporalQueries2.precision = function precision() {
          return TemporalQueries2.PRECISION;
        };
        TemporalQueries2.zone = function zone() {
          return TemporalQueries2.ZONE;
        };
        TemporalQueries2.offset = function offset() {
          return TemporalQueries2.OFFSET;
        };
        TemporalQueries2.localDate = function localDate() {
          return TemporalQueries2.LOCAL_DATE;
        };
        TemporalQueries2.localTime = function localTime() {
          return TemporalQueries2.LOCAL_TIME;
        };
        return TemporalQueries2;
      }();
      var TemporalAccessor = function() {
        function TemporalAccessor2() {
        }
        var _proto = TemporalAccessor2.prototype;
        _proto.query = function query(_query) {
          if (_query === TemporalQueries.zoneId() || _query === TemporalQueries.chronology() || _query === TemporalQueries.precision()) {
            return null;
          }
          return _query.queryFrom(this);
        };
        _proto.get = function get(field) {
          return this.range(field).checkValidIntValue(this.getLong(field), field);
        };
        _proto.getLong = function getLong(field) {
          abstractMethodFail("getLong");
        };
        _proto.range = function range(field) {
          if (field instanceof ChronoField) {
            if (this.isSupported(field)) {
              return field.range();
            }
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.rangeRefinedBy(this);
        };
        _proto.isSupported = function isSupported(field) {
          abstractMethodFail("isSupported");
        };
        return TemporalAccessor2;
      }();
      var TemporalQuery = function(_Enum) {
        _inheritsLoose(TemporalQuery2, _Enum);
        function TemporalQuery2() {
          return _Enum.apply(this, arguments) || this;
        }
        var _proto = TemporalQuery2.prototype;
        _proto.queryFrom = function queryFrom(temporal) {
          abstractMethodFail("queryFrom");
        };
        return TemporalQuery2;
      }(Enum);
      function createTemporalQuery(name, queryFromFunction) {
        var ExtendedTemporalQuery = function(_TemporalQuery) {
          _inheritsLoose(ExtendedTemporalQuery2, _TemporalQuery);
          function ExtendedTemporalQuery2() {
            return _TemporalQuery.apply(this, arguments) || this;
          }
          return ExtendedTemporalQuery2;
        }(TemporalQuery);
        ExtendedTemporalQuery.prototype.queryFrom = queryFromFunction;
        return new ExtendedTemporalQuery(name);
      }
      var DayOfWeek = function(_TemporalAccessor) {
        _inheritsLoose(DayOfWeek2, _TemporalAccessor);
        function DayOfWeek2(ordinal, name) {
          var _this;
          _this = _TemporalAccessor.call(this) || this;
          _this._ordinal = ordinal;
          _this._name = name;
          return _this;
        }
        var _proto = DayOfWeek2.prototype;
        _proto.ordinal = function ordinal() {
          return this._ordinal;
        };
        _proto.name = function name() {
          return this._name;
        };
        DayOfWeek2.values = function values() {
          return ENUMS.slice();
        };
        DayOfWeek2.valueOf = function valueOf(name) {
          var ordinal = 0;
          for (ordinal; ordinal < ENUMS.length; ordinal++) {
            if (ENUMS[ordinal].name() === name) {
              break;
            }
          }
          return DayOfWeek2.of(ordinal + 1);
        };
        DayOfWeek2.of = function of(dayOfWeek) {
          if (dayOfWeek < 1 || dayOfWeek > 7) {
            throw new DateTimeException("Invalid value for DayOfWeek: " + dayOfWeek);
          }
          return ENUMS[dayOfWeek - 1];
        };
        DayOfWeek2.from = function from(temporal) {
          assert3(temporal != null, "temporal", NullPointerException);
          if (temporal instanceof DayOfWeek2) {
            return temporal;
          }
          try {
            return DayOfWeek2.of(temporal.get(ChronoField.DAY_OF_WEEK));
          } catch (ex) {
            if (ex instanceof DateTimeException) {
              throw new DateTimeException("Unable to obtain DayOfWeek from TemporalAccessor: " + temporal + ", type " + (temporal.constructor != null ? temporal.constructor.name : ""), ex);
            } else {
              throw ex;
            }
          }
        };
        _proto.value = function value() {
          return this._ordinal + 1;
        };
        _proto.displayName = function displayName(style, locale) {
          throw new IllegalArgumentException("Pattern using (localized) text not implemented yet!");
        };
        _proto.isSupported = function isSupported(field) {
          if (field instanceof ChronoField) {
            return field === ChronoField.DAY_OF_WEEK;
          }
          return field != null && field.isSupportedBy(this);
        };
        _proto.range = function range(field) {
          if (field === ChronoField.DAY_OF_WEEK) {
            return field.range();
          } else if (field instanceof ChronoField) {
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.rangeRefinedBy(this);
        };
        _proto.get = function get(field) {
          if (field === ChronoField.DAY_OF_WEEK) {
            return this.value();
          }
          return this.range(field).checkValidIntValue(this.getLong(field), field);
        };
        _proto.getLong = function getLong(field) {
          if (field === ChronoField.DAY_OF_WEEK) {
            return this.value();
          } else if (field instanceof ChronoField) {
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.getFrom(this);
        };
        _proto.plus = function plus(days) {
          var amount = MathUtil.floorMod(days, 7);
          return ENUMS[MathUtil.floorMod(this._ordinal + (amount + 7), 7)];
        };
        _proto.minus = function minus(days) {
          return this.plus(-1 * MathUtil.floorMod(days, 7));
        };
        _proto.query = function query(_query) {
          if (_query === TemporalQueries.precision()) {
            return ChronoUnit.DAYS;
          } else if (_query === TemporalQueries.localDate() || _query === TemporalQueries.localTime() || _query === TemporalQueries.chronology() || _query === TemporalQueries.zone() || _query === TemporalQueries.zoneId() || _query === TemporalQueries.offset()) {
            return null;
          }
          assert3(_query != null, "query", NullPointerException);
          return _query.queryFrom(this);
        };
        _proto.adjustInto = function adjustInto(temporal) {
          requireNonNull(temporal, "temporal");
          return temporal.with(ChronoField.DAY_OF_WEEK, this.value());
        };
        _proto.equals = function equals(other) {
          return this === other;
        };
        _proto.toString = function toString() {
          return this._name;
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          requireInstance(other, DayOfWeek2, "other");
          return this._ordinal - other._ordinal;
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        return DayOfWeek2;
      }(TemporalAccessor);
      var ENUMS;
      function _init$j() {
        DayOfWeek.MONDAY = new DayOfWeek(0, "MONDAY");
        DayOfWeek.TUESDAY = new DayOfWeek(1, "TUESDAY");
        DayOfWeek.WEDNESDAY = new DayOfWeek(2, "WEDNESDAY");
        DayOfWeek.THURSDAY = new DayOfWeek(3, "THURSDAY");
        DayOfWeek.FRIDAY = new DayOfWeek(4, "FRIDAY");
        DayOfWeek.SATURDAY = new DayOfWeek(5, "SATURDAY");
        DayOfWeek.SUNDAY = new DayOfWeek(6, "SUNDAY");
        DayOfWeek.FROM = createTemporalQuery("DayOfWeek.FROM", function(temporal) {
          return DayOfWeek.from(temporal);
        });
        ENUMS = [DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY];
      }
      var Month = function(_TemporalAccessor) {
        _inheritsLoose(Month2, _TemporalAccessor);
        function Month2(value, name) {
          var _this;
          _this = _TemporalAccessor.call(this) || this;
          _this._value = MathUtil.safeToInt(value);
          _this._name = name;
          return _this;
        }
        var _proto = Month2.prototype;
        _proto.value = function value() {
          return this._value;
        };
        _proto.ordinal = function ordinal() {
          return this._value - 1;
        };
        _proto.name = function name() {
          return this._name;
        };
        _proto.displayName = function displayName(style, locale) {
          throw new IllegalArgumentException("Pattern using (localized) text not implemented yet!");
        };
        _proto.isSupported = function isSupported(field) {
          if (null === field) {
            return false;
          }
          if (field instanceof ChronoField) {
            return field === ChronoField.MONTH_OF_YEAR;
          }
          return field != null && field.isSupportedBy(this);
        };
        _proto.get = function get(field) {
          if (field === ChronoField.MONTH_OF_YEAR) {
            return this.value();
          }
          return this.range(field).checkValidIntValue(this.getLong(field), field);
        };
        _proto.getLong = function getLong(field) {
          if (field === ChronoField.MONTH_OF_YEAR) {
            return this.value();
          } else if (field instanceof ChronoField) {
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.getFrom(this);
        };
        _proto.plus = function plus(months) {
          var amount = MathUtil.intMod(months, 12) + 12;
          var newMonthVal = MathUtil.intMod(this.value() + amount, 12);
          newMonthVal = newMonthVal === 0 ? 12 : newMonthVal;
          return Month2.of(newMonthVal);
        };
        _proto.minus = function minus(months) {
          return this.plus(-1 * MathUtil.intMod(months, 12));
        };
        _proto.length = function length(leapYear) {
          switch (this) {
            case Month2.FEBRUARY:
              return leapYear ? 29 : 28;
            case Month2.APRIL:
            case Month2.JUNE:
            case Month2.SEPTEMBER:
            case Month2.NOVEMBER:
              return 30;
            default:
              return 31;
          }
        };
        _proto.minLength = function minLength() {
          switch (this) {
            case Month2.FEBRUARY:
              return 28;
            case Month2.APRIL:
            case Month2.JUNE:
            case Month2.SEPTEMBER:
            case Month2.NOVEMBER:
              return 30;
            default:
              return 31;
          }
        };
        _proto.maxLength = function maxLength() {
          switch (this) {
            case Month2.FEBRUARY:
              return 29;
            case Month2.APRIL:
            case Month2.JUNE:
            case Month2.SEPTEMBER:
            case Month2.NOVEMBER:
              return 30;
            default:
              return 31;
          }
        };
        _proto.firstDayOfYear = function firstDayOfYear(leapYear) {
          var leap = leapYear ? 1 : 0;
          switch (this) {
            case Month2.JANUARY:
              return 1;
            case Month2.FEBRUARY:
              return 32;
            case Month2.MARCH:
              return 60 + leap;
            case Month2.APRIL:
              return 91 + leap;
            case Month2.MAY:
              return 121 + leap;
            case Month2.JUNE:
              return 152 + leap;
            case Month2.JULY:
              return 182 + leap;
            case Month2.AUGUST:
              return 213 + leap;
            case Month2.SEPTEMBER:
              return 244 + leap;
            case Month2.OCTOBER:
              return 274 + leap;
            case Month2.NOVEMBER:
              return 305 + leap;
            case Month2.DECEMBER:
            default:
              return 335 + leap;
          }
        };
        _proto.firstMonthOfQuarter = function firstMonthOfQuarter() {
          switch (this) {
            case Month2.JANUARY:
            case Month2.FEBRUARY:
            case Month2.MARCH:
              return Month2.JANUARY;
            case Month2.APRIL:
            case Month2.MAY:
            case Month2.JUNE:
              return Month2.APRIL;
            case Month2.JULY:
            case Month2.AUGUST:
            case Month2.SEPTEMBER:
              return Month2.JULY;
            case Month2.OCTOBER:
            case Month2.NOVEMBER:
            case Month2.DECEMBER:
            default:
              return Month2.OCTOBER;
          }
        };
        _proto.query = function query(_query) {
          assert3(_query != null, "query() parameter must not be null", DateTimeException);
          if (_query === TemporalQueries.chronology()) {
            return IsoChronology.INSTANCE;
          } else if (_query === TemporalQueries.precision()) {
            return ChronoUnit.MONTHS;
          }
          return _TemporalAccessor.prototype.query.call(this, _query);
        };
        _proto.toString = function toString() {
          switch (this) {
            case Month2.JANUARY:
              return "JANUARY";
            case Month2.FEBRUARY:
              return "FEBRUARY";
            case Month2.MARCH:
              return "MARCH";
            case Month2.APRIL:
              return "APRIL";
            case Month2.MAY:
              return "MAY";
            case Month2.JUNE:
              return "JUNE";
            case Month2.JULY:
              return "JULY";
            case Month2.AUGUST:
              return "AUGUST";
            case Month2.SEPTEMBER:
              return "SEPTEMBER";
            case Month2.OCTOBER:
              return "OCTOBER";
            case Month2.NOVEMBER:
              return "NOVEMBER";
            case Month2.DECEMBER:
              return "DECEMBER";
            default:
              return "unknown Month, value: " + this.value();
          }
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        _proto.adjustInto = function adjustInto(temporal) {
          return temporal.with(ChronoField.MONTH_OF_YEAR, this.value());
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          requireInstance(other, Month2, "other");
          return this._value - other._value;
        };
        _proto.equals = function equals(other) {
          return this === other;
        };
        Month2.valueOf = function valueOf(name) {
          var ordinal = 0;
          for (ordinal; ordinal < MONTHS.length; ordinal++) {
            if (MONTHS[ordinal].name() === name) {
              break;
            }
          }
          return Month2.of(ordinal + 1);
        };
        Month2.values = function values() {
          return MONTHS.slice();
        };
        Month2.of = function of(month) {
          if (month < 1 || month > 12) {
            assert3(false, "Invalid value for MonthOfYear: " + month, DateTimeException);
          }
          return MONTHS[month - 1];
        };
        Month2.from = function from(temporal) {
          if (temporal instanceof Month2) {
            return temporal;
          }
          try {
            return Month2.of(temporal.get(ChronoField.MONTH_OF_YEAR));
          } catch (ex) {
            throw new DateTimeException("Unable to obtain Month from TemporalAccessor: " + temporal + " of type " + (temporal && temporal.constructor != null ? temporal.constructor.name : ""), ex);
          }
        };
        return Month2;
      }(TemporalAccessor);
      var MONTHS;
      function _init$i() {
        Month.JANUARY = new Month(1, "JANUARY");
        Month.FEBRUARY = new Month(2, "FEBRUARY");
        Month.MARCH = new Month(3, "MARCH");
        Month.APRIL = new Month(4, "APRIL");
        Month.MAY = new Month(5, "MAY");
        Month.JUNE = new Month(6, "JUNE");
        Month.JULY = new Month(7, "JULY");
        Month.AUGUST = new Month(8, "AUGUST");
        Month.SEPTEMBER = new Month(9, "SEPTEMBER");
        Month.OCTOBER = new Month(10, "OCTOBER");
        Month.NOVEMBER = new Month(11, "NOVEMBER");
        Month.DECEMBER = new Month(12, "DECEMBER");
        MONTHS = [Month.JANUARY, Month.FEBRUARY, Month.MARCH, Month.APRIL, Month.MAY, Month.JUNE, Month.JULY, Month.AUGUST, Month.SEPTEMBER, Month.OCTOBER, Month.NOVEMBER, Month.DECEMBER];
      }
      var PATTERN = /([-+]?)P(?:([-+]?[0-9]+)Y)?(?:([-+]?[0-9]+)M)?(?:([-+]?[0-9]+)W)?(?:([-+]?[0-9]+)D)?/;
      var Period = function(_TemporalAmount) {
        _inheritsLoose(Period2, _TemporalAmount);
        function Period2(years, months, days) {
          var _this;
          _this = _TemporalAmount.call(this) || this;
          var _years = MathUtil.safeToInt(years);
          var _months = MathUtil.safeToInt(months);
          var _days = MathUtil.safeToInt(days);
          if (_years === 0 && _months === 0 && _days === 0) {
            if (!Period2.ZERO) {
              _this._years = _years;
              _this._months = _months;
              _this._days = _days;
              Period2.ZERO = _assertThisInitialized(_this);
            }
            return Period2.ZERO || _assertThisInitialized(_this);
          }
          _this._years = _years;
          _this._months = _months;
          _this._days = _days;
          return _this;
        }
        Period2.ofYears = function ofYears(years) {
          return Period2.create(years, 0, 0);
        };
        Period2.ofMonths = function ofMonths(months) {
          return Period2.create(0, months, 0);
        };
        Period2.ofWeeks = function ofWeeks(weeks) {
          return Period2.create(0, 0, MathUtil.safeMultiply(weeks, 7));
        };
        Period2.ofDays = function ofDays(days) {
          return Period2.create(0, 0, days);
        };
        Period2.of = function of(years, months, days) {
          return Period2.create(years, months, days);
        };
        Period2.from = function from(amount) {
          if (amount instanceof Period2) {
            return amount;
          }
          requireNonNull(amount, "amount");
          var years = 0;
          var months = 0;
          var days = 0;
          var units = amount.units();
          for (var i = 0; i < units.length; i++) {
            var unit = units[i];
            var unitAmount = amount.get(unit);
            if (unit === ChronoUnit.YEARS) {
              years = MathUtil.safeToInt(unitAmount);
            } else if (unit === ChronoUnit.MONTHS) {
              months = MathUtil.safeToInt(unitAmount);
            } else if (unit === ChronoUnit.DAYS) {
              days = MathUtil.safeToInt(unitAmount);
            } else {
              throw new DateTimeException("Unit must be Years, Months or Days, but was " + unit);
            }
          }
          return Period2.create(years, months, days);
        };
        Period2.between = function between(startDate, endDate) {
          requireNonNull(startDate, "startDate");
          requireNonNull(endDate, "endDate");
          requireInstance(startDate, LocalDate2, "startDate");
          requireInstance(endDate, LocalDate2, "endDate");
          return startDate.until(endDate);
        };
        Period2.parse = function parse(text) {
          requireNonNull(text, "text");
          try {
            return Period2._parse(text);
          } catch (ex) {
            if (ex instanceof ArithmeticException) {
              throw new DateTimeParseException("Text cannot be parsed to a Period", text, 0, ex);
            } else {
              throw ex;
            }
          }
        };
        Period2._parse = function _parse(text) {
          var matches = PATTERN.exec(text);
          if (matches != null) {
            var negate = "-" === matches[1] ? -1 : 1;
            var yearMatch = matches[2];
            var monthMatch = matches[3];
            var weekMatch = matches[4];
            var dayMatch = matches[5];
            if (yearMatch != null || monthMatch != null || weekMatch != null || dayMatch != null) {
              var years = Period2._parseNumber(text, yearMatch, negate);
              var months = Period2._parseNumber(text, monthMatch, negate);
              var weeks = Period2._parseNumber(text, weekMatch, negate);
              var days = Period2._parseNumber(text, dayMatch, negate);
              days = MathUtil.safeAdd(days, MathUtil.safeMultiply(weeks, 7));
              return Period2.create(years, months, days);
            }
          }
          throw new DateTimeParseException("Text cannot be parsed to a Period", text, 0);
        };
        Period2._parseNumber = function _parseNumber(text, str, negate) {
          if (str == null) {
            return 0;
          }
          var val = MathUtil.parseInt(str);
          return MathUtil.safeMultiply(val, negate);
        };
        Period2.create = function create(years, months, days) {
          return new Period2(years, months, days);
        };
        var _proto = Period2.prototype;
        _proto.units = function units() {
          return [ChronoUnit.YEARS, ChronoUnit.MONTHS, ChronoUnit.DAYS];
        };
        _proto.chronology = function chronology() {
          return IsoChronology.INSTANCE;
        };
        _proto.get = function get(unit) {
          if (unit === ChronoUnit.YEARS) {
            return this._years;
          }
          if (unit === ChronoUnit.MONTHS) {
            return this._months;
          }
          if (unit === ChronoUnit.DAYS) {
            return this._days;
          }
          throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
        };
        _proto.isZero = function isZero() {
          return this === Period2.ZERO;
        };
        _proto.isNegative = function isNegative() {
          return this._years < 0 || this._months < 0 || this._days < 0;
        };
        _proto.years = function years() {
          return this._years;
        };
        _proto.months = function months() {
          return this._months;
        };
        _proto.days = function days() {
          return this._days;
        };
        _proto.withYears = function withYears(years) {
          if (years === this._years) {
            return this;
          }
          return Period2.create(years, this._months, this._days);
        };
        _proto.withMonths = function withMonths(months) {
          if (months === this._months) {
            return this;
          }
          return Period2.create(this._years, months, this._days);
        };
        _proto.withDays = function withDays(days) {
          if (days === this._days) {
            return this;
          }
          return Period2.create(this._years, this._months, days);
        };
        _proto.plus = function plus(amountToAdd) {
          var amount = Period2.from(amountToAdd);
          return Period2.create(MathUtil.safeAdd(this._years, amount._years), MathUtil.safeAdd(this._months, amount._months), MathUtil.safeAdd(this._days, amount._days));
        };
        _proto.plusYears = function plusYears(yearsToAdd) {
          if (yearsToAdd === 0) {
            return this;
          }
          return Period2.create(MathUtil.safeToInt(MathUtil.safeAdd(this._years, yearsToAdd)), this._months, this._days);
        };
        _proto.plusMonths = function plusMonths(monthsToAdd) {
          if (monthsToAdd === 0) {
            return this;
          }
          return Period2.create(this._years, MathUtil.safeToInt(MathUtil.safeAdd(this._months, monthsToAdd)), this._days);
        };
        _proto.plusDays = function plusDays(daysToAdd) {
          if (daysToAdd === 0) {
            return this;
          }
          return Period2.create(this._years, this._months, MathUtil.safeToInt(MathUtil.safeAdd(this._days, daysToAdd)));
        };
        _proto.minus = function minus(amountToSubtract) {
          var amount = Period2.from(amountToSubtract);
          return Period2.create(MathUtil.safeSubtract(this._years, amount._years), MathUtil.safeSubtract(this._months, amount._months), MathUtil.safeSubtract(this._days, amount._days));
        };
        _proto.minusYears = function minusYears(yearsToSubtract) {
          return this.plusYears(-1 * yearsToSubtract);
        };
        _proto.minusMonths = function minusMonths(monthsToSubtract) {
          return this.plusMonths(-1 * monthsToSubtract);
        };
        _proto.minusDays = function minusDays(daysToSubtract) {
          return this.plusDays(-1 * daysToSubtract);
        };
        _proto.multipliedBy = function multipliedBy(scalar) {
          if (this === Period2.ZERO || scalar === 1) {
            return this;
          }
          return Period2.create(MathUtil.safeMultiply(this._years, scalar), MathUtil.safeMultiply(this._months, scalar), MathUtil.safeMultiply(this._days, scalar));
        };
        _proto.negated = function negated() {
          return this.multipliedBy(-1);
        };
        _proto.normalized = function normalized() {
          var totalMonths = this.toTotalMonths();
          var splitYears = MathUtil.intDiv(totalMonths, 12);
          var splitMonths = MathUtil.intMod(totalMonths, 12);
          if (splitYears === this._years && splitMonths === this._months) {
            return this;
          }
          return Period2.create(MathUtil.safeToInt(splitYears), splitMonths, this._days);
        };
        _proto.toTotalMonths = function toTotalMonths() {
          return this._years * 12 + this._months;
        };
        _proto.addTo = function addTo(temporal) {
          requireNonNull(temporal, "temporal");
          if (this._years !== 0) {
            if (this._months !== 0) {
              temporal = temporal.plus(this.toTotalMonths(), ChronoUnit.MONTHS);
            } else {
              temporal = temporal.plus(this._years, ChronoUnit.YEARS);
            }
          } else if (this._months !== 0) {
            temporal = temporal.plus(this._months, ChronoUnit.MONTHS);
          }
          if (this._days !== 0) {
            temporal = temporal.plus(this._days, ChronoUnit.DAYS);
          }
          return temporal;
        };
        _proto.subtractFrom = function subtractFrom(temporal) {
          requireNonNull(temporal, "temporal");
          if (this._years !== 0) {
            if (this._months !== 0) {
              temporal = temporal.minus(this.toTotalMonths(), ChronoUnit.MONTHS);
            } else {
              temporal = temporal.minus(this._years, ChronoUnit.YEARS);
            }
          } else if (this._months !== 0) {
            temporal = temporal.minus(this._months, ChronoUnit.MONTHS);
          }
          if (this._days !== 0) {
            temporal = temporal.minus(this._days, ChronoUnit.DAYS);
          }
          return temporal;
        };
        _proto.equals = function equals(obj) {
          if (this === obj) {
            return true;
          }
          if (obj instanceof Period2) {
            var other = obj;
            return this._years === other._years && this._months === other._months && this._days === other._days;
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          return MathUtil.hashCode(this._years, this._months, this._days);
        };
        _proto.toString = function toString() {
          if (this === Period2.ZERO) {
            return "P0D";
          } else {
            var buf = "P";
            if (this._years !== 0) {
              buf += this._years + "Y";
            }
            if (this._months !== 0) {
              buf += this._months + "M";
            }
            if (this._days !== 0) {
              buf += this._days + "D";
            }
            return buf;
          }
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        return Period2;
      }(TemporalAmount);
      function _init$h() {
        Period.ofDays(0);
      }
      var ParsePosition = function() {
        function ParsePosition2(index) {
          this._index = index;
          this._errorIndex = -1;
        }
        var _proto = ParsePosition2.prototype;
        _proto.getIndex = function getIndex() {
          return this._index;
        };
        _proto.setIndex = function setIndex(index) {
          this._index = index;
        };
        _proto.getErrorIndex = function getErrorIndex() {
          return this._errorIndex;
        };
        _proto.setErrorIndex = function setErrorIndex(errorIndex) {
          this._errorIndex = errorIndex;
        };
        return ParsePosition2;
      }();
      var EnumMap = function() {
        function EnumMap2() {
          this._map = {};
        }
        var _proto = EnumMap2.prototype;
        _proto.putAll = function putAll(otherMap) {
          for (var key in otherMap._map) {
            this._map[key] = otherMap._map[key];
          }
          return this;
        };
        _proto.containsKey = function containsKey(key) {
          return this._map.hasOwnProperty(key.name()) && this.get(key) !== void 0;
        };
        _proto.get = function get(key) {
          return this._map[key.name()];
        };
        _proto.put = function put(key, val) {
          return this.set(key, val);
        };
        _proto.set = function set(key, val) {
          this._map[key.name()] = val;
          return this;
        };
        _proto.retainAll = function retainAll(keyList) {
          var map = {};
          for (var i = 0; i < keyList.length; i++) {
            var key = keyList[i].name();
            map[key] = this._map[key];
          }
          this._map = map;
          return this;
        };
        _proto.remove = function remove(key) {
          var keyName = key.name();
          var val = this._map[keyName];
          this._map[keyName] = void 0;
          return val;
        };
        _proto.keySet = function keySet() {
          return this._map;
        };
        _proto.clear = function clear() {
          this._map = {};
        };
        return EnumMap2;
      }();
      var ResolverStyle = function(_Enum) {
        _inheritsLoose(ResolverStyle2, _Enum);
        function ResolverStyle2() {
          return _Enum.apply(this, arguments) || this;
        }
        return ResolverStyle2;
      }(Enum);
      ResolverStyle.STRICT = new ResolverStyle("STRICT");
      ResolverStyle.SMART = new ResolverStyle("SMART");
      ResolverStyle.LENIENT = new ResolverStyle("LENIENT");
      var Temporal = function(_TemporalAccessor) {
        _inheritsLoose(Temporal2, _TemporalAccessor);
        function Temporal2() {
          return _TemporalAccessor.apply(this, arguments) || this;
        }
        var _proto = Temporal2.prototype;
        _proto.isSupported = function isSupported(fieldOrUnit) {
          abstractMethodFail("isSupported");
        };
        _proto.minus = function minus(amount, unit) {
          if (arguments.length < 2) {
            return this._minusAmount(amount);
          } else {
            return this._minusUnit(amount, unit);
          }
        };
        _proto._minusAmount = function _minusAmount(amount) {
          requireNonNull(amount, "amount");
          requireInstance(amount, TemporalAmount, "amount");
          return amount.subtractFrom(this);
        };
        _proto._minusUnit = function _minusUnit(amountToSubtract, unit) {
          requireNonNull(amountToSubtract, "amountToSubtract");
          requireNonNull(unit, "unit");
          requireInstance(unit, TemporalUnit, "unit");
          return this._plusUnit(-amountToSubtract, unit);
        };
        _proto.plus = function plus(amount, unit) {
          if (arguments.length < 2) {
            return this._plusAmount(amount);
          } else {
            return this._plusUnit(amount, unit);
          }
        };
        _proto._plusAmount = function _plusAmount(amount) {
          requireNonNull(amount, "amount");
          requireInstance(amount, TemporalAmount, "amount");
          return amount.addTo(this);
        };
        _proto._plusUnit = function _plusUnit(amountToAdd, unit) {
          abstractMethodFail("_plusUnit");
        };
        _proto.until = function until(endTemporal, unit) {
          abstractMethodFail("until");
        };
        _proto.with = function _with(adjusterOrField, newValue) {
          if (arguments.length < 2) {
            return this._withAdjuster(adjusterOrField);
          } else {
            return this._withField(adjusterOrField, newValue);
          }
        };
        _proto._withAdjuster = function _withAdjuster(adjuster) {
          requireNonNull(adjuster, "adjuster");
          assert3(typeof adjuster.adjustInto === "function", "adjuster must be a TemporalAdjuster", IllegalArgumentException);
          return adjuster.adjustInto(this);
        };
        _proto._withField = function _withField(field, newValue) {
          abstractMethodFail("_withField");
        };
        return Temporal2;
      }(TemporalAccessor);
      if (typeof Symbol !== "undefined" && Symbol.toPrimitive) {
        Temporal.prototype[Symbol.toPrimitive] = function(hint) {
          if (hint !== "number") {
            return this.toString();
          }
          throw new TypeError("A conversion from Temporal to a number is not allowed. To compare use the methods .equals(), .compareTo(), .isBefore() or one that is more suitable to your use case.");
        };
      }
      var ChronoLocalDate = function(_Temporal) {
        _inheritsLoose(ChronoLocalDate2, _Temporal);
        function ChronoLocalDate2() {
          return _Temporal.apply(this, arguments) || this;
        }
        var _proto = ChronoLocalDate2.prototype;
        _proto.isSupported = function isSupported(fieldOrUnit) {
          if (fieldOrUnit instanceof ChronoField) {
            return fieldOrUnit.isDateBased();
          } else if (fieldOrUnit instanceof ChronoUnit) {
            return fieldOrUnit.isDateBased();
          }
          return fieldOrUnit != null && fieldOrUnit.isSupportedBy(this);
        };
        _proto.query = function query(_query) {
          if (_query === TemporalQueries.chronology()) {
            return this.chronology();
          } else if (_query === TemporalQueries.precision()) {
            return ChronoUnit.DAYS;
          } else if (_query === TemporalQueries.localDate()) {
            return LocalDate2.ofEpochDay(this.toEpochDay());
          } else if (_query === TemporalQueries.localTime() || _query === TemporalQueries.zone() || _query === TemporalQueries.zoneId() || _query === TemporalQueries.offset()) {
            return null;
          }
          return _Temporal.prototype.query.call(this, _query);
        };
        _proto.adjustInto = function adjustInto(temporal) {
          return temporal.with(ChronoField.EPOCH_DAY, this.toEpochDay());
        };
        _proto.format = function format(formatter) {
          requireNonNull(formatter, "formatter");
          requireInstance(formatter, DateTimeFormatter, "formatter");
          return formatter.format(this);
        };
        return ChronoLocalDate2;
      }(Temporal);
      var StringUtil = function() {
        function StringUtil2() {
        }
        StringUtil2.startsWith = function startsWith(text, pattern) {
          return text.indexOf(pattern) === 0;
        };
        StringUtil2.hashCode = function hashCode(text) {
          var len = text.length;
          if (len === 0) {
            return 0;
          }
          var hash = 0;
          for (var i = 0; i < len; i++) {
            var chr = text.charCodeAt(i);
            hash = (hash << 5) - hash + chr;
            hash |= 0;
          }
          return MathUtil.smi(hash);
        };
        return StringUtil2;
      }();
      var ZoneId2 = function() {
        function ZoneId3() {
        }
        ZoneId3.systemDefault = function systemDefault() {
          throw new DateTimeException("not supported operation");
        };
        ZoneId3.getAvailableZoneIds = function getAvailableZoneIds() {
          throw new DateTimeException("not supported operation");
        };
        ZoneId3.of = function of(zoneId) {
          throw new DateTimeException("not supported operation" + zoneId);
        };
        ZoneId3.ofOffset = function ofOffset(prefix, offset) {
          throw new DateTimeException("not supported operation" + prefix + offset);
        };
        ZoneId3.from = function from(temporal) {
          throw new DateTimeException("not supported operation" + temporal);
        };
        var _proto = ZoneId3.prototype;
        _proto.id = function id() {
          abstractMethodFail("ZoneId.id");
        };
        _proto.rules = function rules() {
          abstractMethodFail("ZoneId.rules");
        };
        _proto.normalized = function normalized() {
          var rules = this.rules();
          if (rules.isFixedOffset()) {
            return rules.offset(Instant.EPOCH);
          }
          return this;
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof ZoneId3) {
            return this.id() === other.id();
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          return StringUtil.hashCode(this.id());
        };
        _proto.toString = function toString() {
          return this.id();
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        return ZoneId3;
      }();
      var ZoneRules = function() {
        function ZoneRules2() {
        }
        ZoneRules2.of = function of(offset) {
          requireNonNull(offset, "offset");
          return new Fixed(offset);
        };
        var _proto = ZoneRules2.prototype;
        _proto.isFixedOffset = function isFixedOffset() {
          abstractMethodFail("ZoneRules.isFixedOffset");
        };
        _proto.offset = function offset(instantOrLocalDateTime) {
          if (instantOrLocalDateTime instanceof Instant) {
            return this.offsetOfInstant(instantOrLocalDateTime);
          } else {
            return this.offsetOfLocalDateTime(instantOrLocalDateTime);
          }
        };
        _proto.offsetOfInstant = function offsetOfInstant(instant) {
          abstractMethodFail("ZoneRules.offsetInstant");
        };
        _proto.offsetOfEpochMilli = function offsetOfEpochMilli(epochMilli) {
          abstractMethodFail("ZoneRules.offsetOfEpochMilli");
        };
        _proto.offsetOfLocalDateTime = function offsetOfLocalDateTime(localDateTime) {
          abstractMethodFail("ZoneRules.offsetLocalDateTime");
        };
        _proto.validOffsets = function validOffsets(localDateTime) {
          abstractMethodFail("ZoneRules.validOffsets");
        };
        _proto.transition = function transition(localDateTime) {
          abstractMethodFail("ZoneRules.transition");
        };
        _proto.standardOffset = function standardOffset(instant) {
          abstractMethodFail("ZoneRules.standardOffset");
        };
        _proto.daylightSavings = function daylightSavings(instant) {
          abstractMethodFail("ZoneRules.daylightSavings");
        };
        _proto.isDaylightSavings = function isDaylightSavings(instant) {
          abstractMethodFail("ZoneRules.isDaylightSavings");
        };
        _proto.isValidOffset = function isValidOffset(localDateTime, offset) {
          abstractMethodFail("ZoneRules.isValidOffset");
        };
        _proto.nextTransition = function nextTransition(instant) {
          abstractMethodFail("ZoneRules.nextTransition");
        };
        _proto.previousTransition = function previousTransition(instant) {
          abstractMethodFail("ZoneRules.previousTransition");
        };
        _proto.transitions = function transitions() {
          abstractMethodFail("ZoneRules.transitions");
        };
        _proto.transitionRules = function transitionRules() {
          abstractMethodFail("ZoneRules.transitionRules");
        };
        _proto.toString = function toString() {
          abstractMethodFail("ZoneRules.toString");
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        return ZoneRules2;
      }();
      var Fixed = function(_ZoneRules) {
        _inheritsLoose(Fixed2, _ZoneRules);
        function Fixed2(offset) {
          var _this;
          _this = _ZoneRules.call(this) || this;
          _this._offset = offset;
          return _this;
        }
        var _proto2 = Fixed2.prototype;
        _proto2.isFixedOffset = function isFixedOffset() {
          return true;
        };
        _proto2.offsetOfInstant = function offsetOfInstant() {
          return this._offset;
        };
        _proto2.offsetOfEpochMilli = function offsetOfEpochMilli() {
          return this._offset;
        };
        _proto2.offsetOfLocalDateTime = function offsetOfLocalDateTime() {
          return this._offset;
        };
        _proto2.validOffsets = function validOffsets() {
          return [this._offset];
        };
        _proto2.transition = function transition() {
          return null;
        };
        _proto2.standardOffset = function standardOffset() {
          return this._offset;
        };
        _proto2.daylightSavings = function daylightSavings() {
          return Duration.ZERO;
        };
        _proto2.isDaylightSavings = function isDaylightSavings() {
          return false;
        };
        _proto2.isValidOffset = function isValidOffset(localDateTime, offset) {
          return this._offset.equals(offset);
        };
        _proto2.nextTransition = function nextTransition() {
          return null;
        };
        _proto2.previousTransition = function previousTransition() {
          return null;
        };
        _proto2.transitions = function transitions() {
          return [];
        };
        _proto2.transitionRules = function transitionRules() {
          return [];
        };
        _proto2.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof Fixed2) {
            return this._offset.equals(other._offset);
          }
          return false;
        };
        _proto2.toString = function toString() {
          return "FixedRules:" + this._offset.toString();
        };
        return Fixed2;
      }(ZoneRules);
      var SECONDS_CACHE = {};
      var ID_CACHE = {};
      var ZoneOffset = function(_ZoneId) {
        _inheritsLoose(ZoneOffset2, _ZoneId);
        function ZoneOffset2(totalSeconds) {
          var _this;
          _this = _ZoneId.call(this) || this;
          ZoneOffset2._validateTotalSeconds(totalSeconds);
          _this._totalSeconds = MathUtil.safeToInt(totalSeconds);
          _this._rules = ZoneRules.of(_assertThisInitialized(_this));
          _this._id = ZoneOffset2._buildId(totalSeconds);
          return _this;
        }
        var _proto = ZoneOffset2.prototype;
        _proto.totalSeconds = function totalSeconds() {
          return this._totalSeconds;
        };
        _proto.id = function id() {
          return this._id;
        };
        ZoneOffset2._buildId = function _buildId(totalSeconds) {
          if (totalSeconds === 0) {
            return "Z";
          } else {
            var absTotalSeconds = Math.abs(totalSeconds);
            var absHours = MathUtil.intDiv(absTotalSeconds, LocalTime.SECONDS_PER_HOUR);
            var absMinutes = MathUtil.intMod(MathUtil.intDiv(absTotalSeconds, LocalTime.SECONDS_PER_MINUTE), LocalTime.MINUTES_PER_HOUR);
            var buf = (totalSeconds < 0 ? "-" : "+") + (absHours < 10 ? "0" : "") + absHours + (absMinutes < 10 ? ":0" : ":") + absMinutes;
            var absSeconds = MathUtil.intMod(absTotalSeconds, LocalTime.SECONDS_PER_MINUTE);
            if (absSeconds !== 0) {
              buf += (absSeconds < 10 ? ":0" : ":") + absSeconds;
            }
            return buf;
          }
        };
        ZoneOffset2._validateTotalSeconds = function _validateTotalSeconds(totalSeconds) {
          if (Math.abs(totalSeconds) > ZoneOffset2.MAX_SECONDS) {
            throw new DateTimeException("Zone offset not in valid range: -18:00 to +18:00");
          }
        };
        ZoneOffset2._validate = function _validate(hours, minutes, seconds) {
          if (hours < -18 || hours > 18) {
            throw new DateTimeException("Zone offset hours not in valid range: value " + hours + " is not in the range -18 to 18");
          }
          if (hours > 0) {
            if (minutes < 0 || seconds < 0) {
              throw new DateTimeException("Zone offset minutes and seconds must be positive because hours is positive");
            }
          } else if (hours < 0) {
            if (minutes > 0 || seconds > 0) {
              throw new DateTimeException("Zone offset minutes and seconds must be negative because hours is negative");
            }
          } else if (minutes > 0 && seconds < 0 || minutes < 0 && seconds > 0) {
            throw new DateTimeException("Zone offset minutes and seconds must have the same sign");
          }
          if (Math.abs(minutes) > 59) {
            throw new DateTimeException("Zone offset minutes not in valid range: abs(value) " + Math.abs(minutes) + " is not in the range 0 to 59");
          }
          if (Math.abs(seconds) > 59) {
            throw new DateTimeException("Zone offset seconds not in valid range: abs(value) " + Math.abs(seconds) + " is not in the range 0 to 59");
          }
          if (Math.abs(hours) === 18 && (Math.abs(minutes) > 0 || Math.abs(seconds) > 0)) {
            throw new DateTimeException("Zone offset not in valid range: -18:00 to +18:00");
          }
        };
        ZoneOffset2.of = function of(offsetId) {
          requireNonNull(offsetId, "offsetId");
          var offset = ID_CACHE[offsetId];
          if (offset != null) {
            return offset;
          }
          var hours, minutes, seconds;
          switch (offsetId.length) {
            case 2:
              offsetId = offsetId[0] + "0" + offsetId[1];
            case 3:
              hours = ZoneOffset2._parseNumber(offsetId, 1, false);
              minutes = 0;
              seconds = 0;
              break;
            case 5:
              hours = ZoneOffset2._parseNumber(offsetId, 1, false);
              minutes = ZoneOffset2._parseNumber(offsetId, 3, false);
              seconds = 0;
              break;
            case 6:
              hours = ZoneOffset2._parseNumber(offsetId, 1, false);
              minutes = ZoneOffset2._parseNumber(offsetId, 4, true);
              seconds = 0;
              break;
            case 7:
              hours = ZoneOffset2._parseNumber(offsetId, 1, false);
              minutes = ZoneOffset2._parseNumber(offsetId, 3, false);
              seconds = ZoneOffset2._parseNumber(offsetId, 5, false);
              break;
            case 9:
              hours = ZoneOffset2._parseNumber(offsetId, 1, false);
              minutes = ZoneOffset2._parseNumber(offsetId, 4, true);
              seconds = ZoneOffset2._parseNumber(offsetId, 7, true);
              break;
            default:
              throw new DateTimeException("Invalid ID for ZoneOffset, invalid format: " + offsetId);
          }
          var first = offsetId[0];
          if (first !== "+" && first !== "-") {
            throw new DateTimeException("Invalid ID for ZoneOffset, plus/minus not found when expected: " + offsetId);
          }
          if (first === "-") {
            return ZoneOffset2.ofHoursMinutesSeconds(-hours, -minutes, -seconds);
          } else {
            return ZoneOffset2.ofHoursMinutesSeconds(hours, minutes, seconds);
          }
        };
        ZoneOffset2._parseNumber = function _parseNumber(offsetId, pos, precededByColon) {
          if (precededByColon && offsetId[pos - 1] !== ":") {
            throw new DateTimeException("Invalid ID for ZoneOffset, colon not found when expected: " + offsetId);
          }
          var ch1 = offsetId[pos];
          var ch2 = offsetId[pos + 1];
          if (ch1 < "0" || ch1 > "9" || ch2 < "0" || ch2 > "9") {
            throw new DateTimeException("Invalid ID for ZoneOffset, non numeric characters found: " + offsetId);
          }
          return (ch1.charCodeAt(0) - 48) * 10 + (ch2.charCodeAt(0) - 48);
        };
        ZoneOffset2.ofHours = function ofHours(hours) {
          return ZoneOffset2.ofHoursMinutesSeconds(hours, 0, 0);
        };
        ZoneOffset2.ofHoursMinutes = function ofHoursMinutes(hours, minutes) {
          return ZoneOffset2.ofHoursMinutesSeconds(hours, minutes, 0);
        };
        ZoneOffset2.ofHoursMinutesSeconds = function ofHoursMinutesSeconds(hours, minutes, seconds) {
          ZoneOffset2._validate(hours, minutes, seconds);
          var totalSeconds = hours * LocalTime.SECONDS_PER_HOUR + minutes * LocalTime.SECONDS_PER_MINUTE + seconds;
          return ZoneOffset2.ofTotalSeconds(totalSeconds);
        };
        ZoneOffset2.ofTotalMinutes = function ofTotalMinutes(totalMinutes) {
          var totalSeconds = totalMinutes * LocalTime.SECONDS_PER_MINUTE;
          return ZoneOffset2.ofTotalSeconds(totalSeconds);
        };
        ZoneOffset2.ofTotalSeconds = function ofTotalSeconds(totalSeconds) {
          if (totalSeconds % (15 * LocalTime.SECONDS_PER_MINUTE) === 0) {
            var totalSecs = totalSeconds;
            var result = SECONDS_CACHE[totalSecs];
            if (result == null) {
              result = new ZoneOffset2(totalSeconds);
              SECONDS_CACHE[totalSecs] = result;
              ID_CACHE[result.id()] = result;
            }
            return result;
          } else {
            return new ZoneOffset2(totalSeconds);
          }
        };
        _proto.rules = function rules() {
          return this._rules;
        };
        _proto.get = function get(field) {
          return this.getLong(field);
        };
        _proto.getLong = function getLong(field) {
          if (field === ChronoField.OFFSET_SECONDS) {
            return this._totalSeconds;
          } else if (field instanceof ChronoField) {
            throw new DateTimeException("Unsupported field: " + field);
          }
          return field.getFrom(this);
        };
        _proto.query = function query(_query) {
          requireNonNull(_query, "query");
          if (_query === TemporalQueries.offset() || _query === TemporalQueries.zone()) {
            return this;
          } else if (_query === TemporalQueries.localDate() || _query === TemporalQueries.localTime() || _query === TemporalQueries.precision() || _query === TemporalQueries.chronology() || _query === TemporalQueries.zoneId()) {
            return null;
          }
          return _query.queryFrom(this);
        };
        _proto.adjustInto = function adjustInto(temporal) {
          return temporal.with(ChronoField.OFFSET_SECONDS, this._totalSeconds);
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          return other._totalSeconds - this._totalSeconds;
        };
        _proto.equals = function equals(obj) {
          if (this === obj) {
            return true;
          }
          if (obj instanceof ZoneOffset2) {
            return this._totalSeconds === obj._totalSeconds;
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          return this._totalSeconds;
        };
        _proto.toString = function toString() {
          return this._id;
        };
        return ZoneOffset2;
      }(ZoneId2);
      function _init$g() {
        ZoneOffset.MAX_SECONDS = 18 * LocalTime.SECONDS_PER_HOUR;
        ZoneOffset.UTC = ZoneOffset.ofTotalSeconds(0);
        ZoneOffset.MIN = ZoneOffset.ofTotalSeconds(-ZoneOffset.MAX_SECONDS);
        ZoneOffset.MAX = ZoneOffset.ofTotalSeconds(ZoneOffset.MAX_SECONDS);
      }
      var DateTimeBuilder = function(_TemporalAccessor) {
        _inheritsLoose(DateTimeBuilder2, _TemporalAccessor);
        DateTimeBuilder2.create = function create(field, value) {
          var dtb = new DateTimeBuilder2();
          dtb._addFieldValue(field, value);
          return dtb;
        };
        function DateTimeBuilder2() {
          var _this;
          _this = _TemporalAccessor.call(this) || this;
          _this.fieldValues = new EnumMap();
          _this.chrono = null;
          _this.zone = null;
          _this.date = null;
          _this.time = null;
          _this.leapSecond = false;
          _this.excessDays = null;
          return _this;
        }
        var _proto = DateTimeBuilder2.prototype;
        _proto.getFieldValue0 = function getFieldValue0(field) {
          return this.fieldValues.get(field);
        };
        _proto._addFieldValue = function _addFieldValue(field, value) {
          requireNonNull(field, "field");
          var old = this.getFieldValue0(field);
          if (old != null && old !== value) {
            throw new DateTimeException("Conflict found: " + field + " " + old + " differs from " + field + " " + value + ": " + this);
          }
          return this._putFieldValue0(field, value);
        };
        _proto._putFieldValue0 = function _putFieldValue0(field, value) {
          this.fieldValues.put(field, value);
          return this;
        };
        _proto.resolve = function resolve(resolverStyle, resolverFields) {
          if (resolverFields != null) {
            this.fieldValues.retainAll(resolverFields);
          }
          this._mergeDate(resolverStyle);
          this._mergeTime(resolverStyle);
          this._resolveTimeInferZeroes(resolverStyle);
          if (this.excessDays != null && this.excessDays.isZero() === false && this.date != null && this.time != null) {
            this.date = this.date.plus(this.excessDays);
            this.excessDays = Period.ZERO;
          }
          this._resolveInstant();
          return this;
        };
        _proto._mergeDate = function _mergeDate(resolverStyle) {
          this._checkDate(IsoChronology.INSTANCE.resolveDate(this.fieldValues, resolverStyle));
        };
        _proto._checkDate = function _checkDate(date) {
          if (date != null) {
            this._addObject(date);
            for (var fieldName in this.fieldValues.keySet()) {
              var field = ChronoField.byName(fieldName);
              if (field) {
                if (this.fieldValues.get(field) !== void 0) {
                  if (field.isDateBased()) {
                    var val1 = void 0;
                    try {
                      val1 = date.getLong(field);
                    } catch (ex) {
                      if (ex instanceof DateTimeException) {
                        continue;
                      } else {
                        throw ex;
                      }
                    }
                    var val2 = this.fieldValues.get(field);
                    if (val1 !== val2) {
                      throw new DateTimeException("Conflict found: Field " + field + " " + val1 + " differs from " + field + " " + val2 + " derived from " + date);
                    }
                  }
                }
              }
            }
          }
        };
        _proto._mergeTime = function _mergeTime(resolverStyle) {
          if (this.fieldValues.containsKey(ChronoField.CLOCK_HOUR_OF_DAY)) {
            var ch = this.fieldValues.remove(ChronoField.CLOCK_HOUR_OF_DAY);
            if (resolverStyle !== ResolverStyle.LENIENT) {
              if (resolverStyle === ResolverStyle.SMART && ch === 0)
                ;
              else {
                ChronoField.CLOCK_HOUR_OF_DAY.checkValidValue(ch);
              }
            }
            this._addFieldValue(ChronoField.HOUR_OF_DAY, ch === 24 ? 0 : ch);
          }
          if (this.fieldValues.containsKey(ChronoField.CLOCK_HOUR_OF_AMPM)) {
            var _ch = this.fieldValues.remove(ChronoField.CLOCK_HOUR_OF_AMPM);
            if (resolverStyle !== ResolverStyle.LENIENT) {
              if (resolverStyle === ResolverStyle.SMART && _ch === 0)
                ;
              else {
                ChronoField.CLOCK_HOUR_OF_AMPM.checkValidValue(_ch);
              }
            }
            this._addFieldValue(ChronoField.HOUR_OF_AMPM, _ch === 12 ? 0 : _ch);
          }
          if (resolverStyle !== ResolverStyle.LENIENT) {
            if (this.fieldValues.containsKey(ChronoField.AMPM_OF_DAY)) {
              ChronoField.AMPM_OF_DAY.checkValidValue(this.fieldValues.get(ChronoField.AMPM_OF_DAY));
            }
            if (this.fieldValues.containsKey(ChronoField.HOUR_OF_AMPM)) {
              ChronoField.HOUR_OF_AMPM.checkValidValue(this.fieldValues.get(ChronoField.HOUR_OF_AMPM));
            }
          }
          if (this.fieldValues.containsKey(ChronoField.AMPM_OF_DAY) && this.fieldValues.containsKey(ChronoField.HOUR_OF_AMPM)) {
            var ap = this.fieldValues.remove(ChronoField.AMPM_OF_DAY);
            var hap = this.fieldValues.remove(ChronoField.HOUR_OF_AMPM);
            this._addFieldValue(ChronoField.HOUR_OF_DAY, ap * 12 + hap);
          }
          if (this.fieldValues.containsKey(ChronoField.NANO_OF_DAY)) {
            var nod = this.fieldValues.remove(ChronoField.NANO_OF_DAY);
            if (resolverStyle !== ResolverStyle.LENIENT) {
              ChronoField.NANO_OF_DAY.checkValidValue(nod);
            }
            this._addFieldValue(ChronoField.SECOND_OF_DAY, MathUtil.intDiv(nod, 1e9));
            this._addFieldValue(ChronoField.NANO_OF_SECOND, MathUtil.intMod(nod, 1e9));
          }
          if (this.fieldValues.containsKey(ChronoField.MICRO_OF_DAY)) {
            var cod = this.fieldValues.remove(ChronoField.MICRO_OF_DAY);
            if (resolverStyle !== ResolverStyle.LENIENT) {
              ChronoField.MICRO_OF_DAY.checkValidValue(cod);
            }
            this._addFieldValue(ChronoField.SECOND_OF_DAY, MathUtil.intDiv(cod, 1e6));
            this._addFieldValue(ChronoField.MICRO_OF_SECOND, MathUtil.intMod(cod, 1e6));
          }
          if (this.fieldValues.containsKey(ChronoField.MILLI_OF_DAY)) {
            var lod = this.fieldValues.remove(ChronoField.MILLI_OF_DAY);
            if (resolverStyle !== ResolverStyle.LENIENT) {
              ChronoField.MILLI_OF_DAY.checkValidValue(lod);
            }
            this._addFieldValue(ChronoField.SECOND_OF_DAY, MathUtil.intDiv(lod, 1e3));
            this._addFieldValue(ChronoField.MILLI_OF_SECOND, MathUtil.intMod(lod, 1e3));
          }
          if (this.fieldValues.containsKey(ChronoField.SECOND_OF_DAY)) {
            var sod = this.fieldValues.remove(ChronoField.SECOND_OF_DAY);
            if (resolverStyle !== ResolverStyle.LENIENT) {
              ChronoField.SECOND_OF_DAY.checkValidValue(sod);
            }
            this._addFieldValue(ChronoField.HOUR_OF_DAY, MathUtil.intDiv(sod, 3600));
            this._addFieldValue(ChronoField.MINUTE_OF_HOUR, MathUtil.intMod(MathUtil.intDiv(sod, 60), 60));
            this._addFieldValue(ChronoField.SECOND_OF_MINUTE, MathUtil.intMod(sod, 60));
          }
          if (this.fieldValues.containsKey(ChronoField.MINUTE_OF_DAY)) {
            var mod = this.fieldValues.remove(ChronoField.MINUTE_OF_DAY);
            if (resolverStyle !== ResolverStyle.LENIENT) {
              ChronoField.MINUTE_OF_DAY.checkValidValue(mod);
            }
            this._addFieldValue(ChronoField.HOUR_OF_DAY, MathUtil.intDiv(mod, 60));
            this._addFieldValue(ChronoField.MINUTE_OF_HOUR, MathUtil.intMod(mod, 60));
          }
          if (resolverStyle !== ResolverStyle.LENIENT) {
            if (this.fieldValues.containsKey(ChronoField.MILLI_OF_SECOND)) {
              ChronoField.MILLI_OF_SECOND.checkValidValue(this.fieldValues.get(ChronoField.MILLI_OF_SECOND));
            }
            if (this.fieldValues.containsKey(ChronoField.MICRO_OF_SECOND)) {
              ChronoField.MICRO_OF_SECOND.checkValidValue(this.fieldValues.get(ChronoField.MICRO_OF_SECOND));
            }
          }
          if (this.fieldValues.containsKey(ChronoField.MILLI_OF_SECOND) && this.fieldValues.containsKey(ChronoField.MICRO_OF_SECOND)) {
            var los = this.fieldValues.remove(ChronoField.MILLI_OF_SECOND);
            var cos = this.fieldValues.get(ChronoField.MICRO_OF_SECOND);
            this._putFieldValue0(ChronoField.MICRO_OF_SECOND, los * 1e3 + MathUtil.intMod(cos, 1e3));
          }
          if (this.fieldValues.containsKey(ChronoField.MICRO_OF_SECOND) && this.fieldValues.containsKey(ChronoField.NANO_OF_SECOND)) {
            var nos = this.fieldValues.get(ChronoField.NANO_OF_SECOND);
            this._putFieldValue0(ChronoField.MICRO_OF_SECOND, MathUtil.intDiv(nos, 1e3));
            this.fieldValues.remove(ChronoField.MICRO_OF_SECOND);
          }
          if (this.fieldValues.containsKey(ChronoField.MILLI_OF_SECOND) && this.fieldValues.containsKey(ChronoField.NANO_OF_SECOND)) {
            var _nos = this.fieldValues.get(ChronoField.NANO_OF_SECOND);
            this._putFieldValue0(ChronoField.MILLI_OF_SECOND, MathUtil.intDiv(_nos, 1e6));
            this.fieldValues.remove(ChronoField.MILLI_OF_SECOND);
          }
          if (this.fieldValues.containsKey(ChronoField.MICRO_OF_SECOND)) {
            var _cos = this.fieldValues.remove(ChronoField.MICRO_OF_SECOND);
            this._putFieldValue0(ChronoField.NANO_OF_SECOND, _cos * 1e3);
          } else if (this.fieldValues.containsKey(ChronoField.MILLI_OF_SECOND)) {
            var _los = this.fieldValues.remove(ChronoField.MILLI_OF_SECOND);
            this._putFieldValue0(ChronoField.NANO_OF_SECOND, _los * 1e6);
          }
        };
        _proto._resolveTimeInferZeroes = function _resolveTimeInferZeroes(resolverStyle) {
          var hod = this.fieldValues.get(ChronoField.HOUR_OF_DAY);
          var moh = this.fieldValues.get(ChronoField.MINUTE_OF_HOUR);
          var som = this.fieldValues.get(ChronoField.SECOND_OF_MINUTE);
          var nos = this.fieldValues.get(ChronoField.NANO_OF_SECOND);
          if (hod == null) {
            return;
          }
          if (moh == null && (som != null || nos != null)) {
            return;
          }
          if (moh != null && som == null && nos != null) {
            return;
          }
          if (resolverStyle !== ResolverStyle.LENIENT) {
            if (hod != null) {
              if (resolverStyle === ResolverStyle.SMART && hod === 24 && (moh == null || moh === 0) && (som == null || som === 0) && (nos == null || nos === 0)) {
                hod = 0;
                this.excessDays = Period.ofDays(1);
              }
              var hodVal = ChronoField.HOUR_OF_DAY.checkValidIntValue(hod);
              if (moh != null) {
                var mohVal = ChronoField.MINUTE_OF_HOUR.checkValidIntValue(moh);
                if (som != null) {
                  var somVal = ChronoField.SECOND_OF_MINUTE.checkValidIntValue(som);
                  if (nos != null) {
                    var nosVal = ChronoField.NANO_OF_SECOND.checkValidIntValue(nos);
                    this._addObject(LocalTime.of(hodVal, mohVal, somVal, nosVal));
                  } else {
                    this._addObject(LocalTime.of(hodVal, mohVal, somVal));
                  }
                } else {
                  if (nos == null) {
                    this._addObject(LocalTime.of(hodVal, mohVal));
                  }
                }
              } else {
                if (som == null && nos == null) {
                  this._addObject(LocalTime.of(hodVal, 0));
                }
              }
            }
          } else {
            if (hod != null) {
              var _hodVal = hod;
              if (moh != null) {
                if (som != null) {
                  if (nos == null) {
                    nos = 0;
                  }
                  var totalNanos = MathUtil.safeMultiply(_hodVal, 36e11);
                  totalNanos = MathUtil.safeAdd(totalNanos, MathUtil.safeMultiply(moh, 6e10));
                  totalNanos = MathUtil.safeAdd(totalNanos, MathUtil.safeMultiply(som, 1e9));
                  totalNanos = MathUtil.safeAdd(totalNanos, nos);
                  var excessDays = MathUtil.floorDiv(totalNanos, 864e11);
                  var nod = MathUtil.floorMod(totalNanos, 864e11);
                  this._addObject(LocalTime.ofNanoOfDay(nod));
                  this.excessDays = Period.ofDays(excessDays);
                } else {
                  var totalSecs = MathUtil.safeMultiply(_hodVal, 3600);
                  totalSecs = MathUtil.safeAdd(totalSecs, MathUtil.safeMultiply(moh, 60));
                  var _excessDays = MathUtil.floorDiv(totalSecs, 86400);
                  var sod = MathUtil.floorMod(totalSecs, 86400);
                  this._addObject(LocalTime.ofSecondOfDay(sod));
                  this.excessDays = Period.ofDays(_excessDays);
                }
              } else {
                var _excessDays2 = MathUtil.safeToInt(MathUtil.floorDiv(_hodVal, 24));
                _hodVal = MathUtil.floorMod(_hodVal, 24);
                this._addObject(LocalTime.of(_hodVal, 0));
                this.excessDays = Period.ofDays(_excessDays2);
              }
            }
          }
          this.fieldValues.remove(ChronoField.HOUR_OF_DAY);
          this.fieldValues.remove(ChronoField.MINUTE_OF_HOUR);
          this.fieldValues.remove(ChronoField.SECOND_OF_MINUTE);
          this.fieldValues.remove(ChronoField.NANO_OF_SECOND);
        };
        _proto._addObject = function _addObject(dateOrTime) {
          if (dateOrTime instanceof ChronoLocalDate) {
            this.date = dateOrTime;
          } else if (dateOrTime instanceof LocalTime) {
            this.time = dateOrTime;
          }
        };
        _proto._resolveInstant = function _resolveInstant() {
          if (this.date != null && this.time != null) {
            var offsetSecs = this.fieldValues.get(ChronoField.OFFSET_SECONDS);
            if (offsetSecs != null) {
              var offset = ZoneOffset.ofTotalSeconds(offsetSecs);
              var instant = this.date.atTime(this.time).atZone(offset).getLong(ChronoField.INSTANT_SECONDS);
              this.fieldValues.put(ChronoField.INSTANT_SECONDS, instant);
            } else if (this.zone != null) {
              var _instant = this.date.atTime(this.time).atZone(this.zone).getLong(ChronoField.INSTANT_SECONDS);
              this.fieldValues.put(ChronoField.INSTANT_SECONDS, _instant);
            }
          }
        };
        _proto.build = function build(type) {
          return type.queryFrom(this);
        };
        _proto.isSupported = function isSupported(field) {
          if (field == null) {
            return false;
          }
          return this.fieldValues.containsKey(field) && this.fieldValues.get(field) !== void 0 || this.date != null && this.date.isSupported(field) || this.time != null && this.time.isSupported(field);
        };
        _proto.getLong = function getLong(field) {
          requireNonNull(field, "field");
          var value = this.getFieldValue0(field);
          if (value == null) {
            if (this.date != null && this.date.isSupported(field)) {
              return this.date.getLong(field);
            }
            if (this.time != null && this.time.isSupported(field)) {
              return this.time.getLong(field);
            }
            throw new DateTimeException("Field not found: " + field);
          }
          return value;
        };
        _proto.query = function query(_query) {
          if (_query === TemporalQueries.zoneId()) {
            return this.zone;
          } else if (_query === TemporalQueries.chronology()) {
            return this.chrono;
          } else if (_query === TemporalQueries.localDate()) {
            return this.date != null ? LocalDate2.from(this.date) : null;
          } else if (_query === TemporalQueries.localTime()) {
            return this.time;
          } else if (_query === TemporalQueries.zone() || _query === TemporalQueries.offset()) {
            return _query.queryFrom(this);
          } else if (_query === TemporalQueries.precision()) {
            return null;
          }
          return _query.queryFrom(this);
        };
        return DateTimeBuilder2;
      }(TemporalAccessor);
      var DateTimeParseContext = function() {
        function DateTimeParseContext2() {
          if (arguments.length === 1) {
            if (arguments[0] instanceof DateTimeParseContext2) {
              this._constructorSelf.apply(this, arguments);
              return;
            } else {
              this._constructorFormatter.apply(this, arguments);
            }
          } else {
            this._constructorParam.apply(this, arguments);
          }
          this._caseSensitive = true;
          this._strict = true;
          this._parsed = [new Parsed(this)];
        }
        var _proto = DateTimeParseContext2.prototype;
        _proto._constructorParam = function _constructorParam(locale, symbols, chronology) {
          this._locale = locale;
          this._symbols = symbols;
          this._overrideChronology = chronology;
        };
        _proto._constructorFormatter = function _constructorFormatter(formatter) {
          this._locale = formatter.locale();
          this._symbols = formatter.decimalStyle();
          this._overrideChronology = formatter.chronology();
        };
        _proto._constructorSelf = function _constructorSelf(other) {
          this._locale = other._locale;
          this._symbols = other._symbols;
          this._overrideChronology = other._overrideChronology;
          this._overrideZone = other._overrideZone;
          this._caseSensitive = other._caseSensitive;
          this._strict = other._strict;
          this._parsed = [new Parsed(this)];
        };
        _proto.copy = function copy() {
          return new DateTimeParseContext2(this);
        };
        _proto.symbols = function symbols() {
          return this._symbols;
        };
        _proto.isStrict = function isStrict() {
          return this._strict;
        };
        _proto.setStrict = function setStrict(strict) {
          this._strict = strict;
        };
        _proto.locale = function locale() {
          return this._locale;
        };
        _proto.setLocale = function setLocale(locale) {
          this._locale = locale;
        };
        _proto.startOptional = function startOptional() {
          this._parsed.push(this.currentParsed().copy());
        };
        _proto.endOptional = function endOptional(successful) {
          if (successful) {
            this._parsed.splice(this._parsed.length - 2, 1);
          } else {
            this._parsed.splice(this._parsed.length - 1, 1);
          }
        };
        _proto.isCaseSensitive = function isCaseSensitive() {
          return this._caseSensitive;
        };
        _proto.setCaseSensitive = function setCaseSensitive(caseSensitive) {
          this._caseSensitive = caseSensitive;
        };
        _proto.subSequenceEquals = function subSequenceEquals(cs1, offset1, cs2, offset2, length) {
          if (offset1 + length > cs1.length || offset2 + length > cs2.length) {
            return false;
          }
          if (!this.isCaseSensitive()) {
            cs1 = cs1.toLowerCase();
            cs2 = cs2.toLowerCase();
          }
          for (var i = 0; i < length; i++) {
            var ch1 = cs1[offset1 + i];
            var ch2 = cs2[offset2 + i];
            if (ch1 !== ch2) {
              return false;
            }
          }
          return true;
        };
        _proto.charEquals = function charEquals(ch1, ch2) {
          if (this.isCaseSensitive()) {
            return ch1 === ch2;
          }
          return this.charEqualsIgnoreCase(ch1, ch2);
        };
        _proto.charEqualsIgnoreCase = function charEqualsIgnoreCase(c1, c2) {
          return c1 === c2 || c1.toLowerCase() === c2.toLowerCase();
        };
        _proto.setParsedField = function setParsedField(field, value, errorPos, successPos) {
          var currentParsedFieldValues = this.currentParsed().fieldValues;
          var old = currentParsedFieldValues.get(field);
          currentParsedFieldValues.set(field, value);
          return old != null && old !== value ? ~errorPos : successPos;
        };
        _proto.setParsedZone = function setParsedZone(zone) {
          requireNonNull(zone, "zone");
          this.currentParsed().zone = zone;
        };
        _proto.getParsed = function getParsed(field) {
          return this.currentParsed().fieldValues.get(field);
        };
        _proto.toParsed = function toParsed() {
          return this.currentParsed();
        };
        _proto.currentParsed = function currentParsed() {
          return this._parsed[this._parsed.length - 1];
        };
        _proto.setParsedLeapSecond = function setParsedLeapSecond() {
          this.currentParsed().leapSecond = true;
        };
        _proto.getEffectiveChronology = function getEffectiveChronology() {
          var chrono = this.currentParsed().chrono;
          if (chrono == null) {
            chrono = this._overrideChronology;
            if (chrono == null) {
              chrono = IsoChronology.INSTANCE;
            }
          }
          return chrono;
        };
        return DateTimeParseContext2;
      }();
      var Parsed = function(_Temporal) {
        _inheritsLoose(Parsed2, _Temporal);
        function Parsed2(dateTimeParseContext) {
          var _this;
          _this = _Temporal.call(this) || this;
          _this.chrono = null;
          _this.zone = null;
          _this.fieldValues = new EnumMap();
          _this.leapSecond = false;
          _this.dateTimeParseContext = dateTimeParseContext;
          return _this;
        }
        var _proto2 = Parsed2.prototype;
        _proto2.copy = function copy() {
          var cloned = new Parsed2();
          cloned.chrono = this.chrono;
          cloned.zone = this.zone;
          cloned.fieldValues.putAll(this.fieldValues);
          cloned.leapSecond = this.leapSecond;
          cloned.dateTimeParseContext = this.dateTimeParseContext;
          return cloned;
        };
        _proto2.toString = function toString() {
          return this.fieldValues + ", " + this.chrono + ", " + this.zone;
        };
        _proto2.isSupported = function isSupported(field) {
          return this.fieldValues.containsKey(field);
        };
        _proto2.get = function get(field) {
          var val = this.fieldValues.get(field);
          assert3(val != null);
          return val;
        };
        _proto2.query = function query(_query) {
          if (_query === TemporalQueries.chronology()) {
            return this.chrono;
          }
          if (_query === TemporalQueries.zoneId() || _query === TemporalQueries.zone()) {
            return this.zone;
          }
          return _Temporal.prototype.query.call(this, _query);
        };
        _proto2.toBuilder = function toBuilder() {
          var builder = new DateTimeBuilder();
          builder.fieldValues.putAll(this.fieldValues);
          builder.chrono = this.dateTimeParseContext.getEffectiveChronology();
          if (this.zone != null) {
            builder.zone = this.zone;
          } else {
            builder.zone = this.overrideZone;
          }
          builder.leapSecond = this.leapSecond;
          builder.excessDays = this.excessDays;
          return builder;
        };
        return Parsed2;
      }(Temporal);
      var DateTimePrintContext = function() {
        function DateTimePrintContext2(temporal, localeOrFormatter, symbols) {
          if (arguments.length === 2 && arguments[1] instanceof DateTimeFormatter) {
            this._temporal = DateTimePrintContext2.adjust(temporal, localeOrFormatter);
            this._locale = localeOrFormatter.locale();
            this._symbols = localeOrFormatter.decimalStyle();
          } else {
            this._temporal = temporal;
            this._locale = localeOrFormatter;
            this._symbols = symbols;
          }
          this._optional = 0;
        }
        DateTimePrintContext2.adjust = function adjust(temporal, formatter) {
          return temporal;
        };
        var _proto = DateTimePrintContext2.prototype;
        _proto.symbols = function symbols() {
          return this._symbols;
        };
        _proto.startOptional = function startOptional() {
          this._optional++;
        };
        _proto.endOptional = function endOptional() {
          this._optional--;
        };
        _proto.getValueQuery = function getValueQuery(query) {
          var result = this._temporal.query(query);
          if (result == null && this._optional === 0) {
            throw new DateTimeException("Unable to extract value: " + this._temporal);
          }
          return result;
        };
        _proto.getValue = function getValue(field) {
          try {
            return this._temporal.getLong(field);
          } catch (ex) {
            if (ex instanceof DateTimeException && this._optional > 0) {
              return null;
            }
            throw ex;
          }
        };
        _proto.temporal = function temporal() {
          return this._temporal;
        };
        _proto.locale = function locale() {
          return this._locale;
        };
        _proto.setDateTime = function setDateTime(temporal) {
          this._temporal = temporal;
        };
        _proto.setLocale = function setLocale(locale) {
          this._locale = locale;
        };
        return DateTimePrintContext2;
      }();
      var IsoFields = {};
      var QUARTER_DAYS = [0, 90, 181, 273, 0, 91, 182, 274];
      var Field = function(_TemporalField) {
        _inheritsLoose(Field2, _TemporalField);
        function Field2() {
          return _TemporalField.apply(this, arguments) || this;
        }
        var _proto = Field2.prototype;
        _proto.isDateBased = function isDateBased() {
          return true;
        };
        _proto.isTimeBased = function isTimeBased() {
          return false;
        };
        _proto._isIso = function _isIso() {
          return true;
        };
        Field2._getWeekRangeByLocalDate = function _getWeekRangeByLocalDate(date) {
          var wby = Field2._getWeekBasedYear(date);
          return ValueRange.of(1, Field2._getWeekRangeByYear(wby));
        };
        Field2._getWeekRangeByYear = function _getWeekRangeByYear(wby) {
          var date = LocalDate2.of(wby, 1, 1);
          if (date.dayOfWeek() === DayOfWeek.THURSDAY || date.dayOfWeek() === DayOfWeek.WEDNESDAY && date.isLeapYear()) {
            return 53;
          }
          return 52;
        };
        Field2._getWeek = function _getWeek(date) {
          var dow0 = date.dayOfWeek().ordinal();
          var doy0 = date.dayOfYear() - 1;
          var doyThu0 = doy0 + (3 - dow0);
          var alignedWeek = MathUtil.intDiv(doyThu0, 7);
          var firstThuDoy0 = doyThu0 - alignedWeek * 7;
          var firstMonDoy0 = firstThuDoy0 - 3;
          if (firstMonDoy0 < -3) {
            firstMonDoy0 += 7;
          }
          if (doy0 < firstMonDoy0) {
            return Field2._getWeekRangeByLocalDate(date.withDayOfYear(180).minusYears(1)).maximum();
          }
          var week = MathUtil.intDiv(doy0 - firstMonDoy0, 7) + 1;
          if (week === 53) {
            if ((firstMonDoy0 === -3 || firstMonDoy0 === -2 && date.isLeapYear()) === false) {
              week = 1;
            }
          }
          return week;
        };
        Field2._getWeekBasedYear = function _getWeekBasedYear(date) {
          var year = date.year();
          var doy = date.dayOfYear();
          if (doy <= 3) {
            var dow = date.dayOfWeek().ordinal();
            if (doy - dow < -2) {
              year--;
            }
          } else if (doy >= 363) {
            var _dow = date.dayOfWeek().ordinal();
            doy = doy - 363 - (date.isLeapYear() ? 1 : 0);
            if (doy - _dow >= 0) {
              year++;
            }
          }
          return year;
        };
        _proto.displayName = function displayName() {
          return this.toString();
        };
        _proto.resolve = function resolve() {
          return null;
        };
        _proto.name = function name() {
          return this.toString();
        };
        return Field2;
      }(TemporalField);
      var DAY_OF_QUARTER_FIELD = function(_Field) {
        _inheritsLoose(DAY_OF_QUARTER_FIELD2, _Field);
        function DAY_OF_QUARTER_FIELD2() {
          return _Field.apply(this, arguments) || this;
        }
        var _proto2 = DAY_OF_QUARTER_FIELD2.prototype;
        _proto2.toString = function toString() {
          return "DayOfQuarter";
        };
        _proto2.baseUnit = function baseUnit() {
          return ChronoUnit.DAYS;
        };
        _proto2.rangeUnit = function rangeUnit() {
          return QUARTER_YEARS;
        };
        _proto2.range = function range() {
          return ValueRange.of(1, 90, 92);
        };
        _proto2.isSupportedBy = function isSupportedBy(temporal) {
          return temporal.isSupported(ChronoField.DAY_OF_YEAR) && temporal.isSupported(ChronoField.MONTH_OF_YEAR) && temporal.isSupported(ChronoField.YEAR) && this._isIso(temporal);
        };
        _proto2.rangeRefinedBy = function rangeRefinedBy(temporal) {
          if (temporal.isSupported(this) === false) {
            throw new UnsupportedTemporalTypeException("Unsupported field: DayOfQuarter");
          }
          var qoy = temporal.getLong(QUARTER_OF_YEAR);
          if (qoy === 1) {
            var year = temporal.getLong(ChronoField.YEAR);
            return IsoChronology.isLeapYear(year) ? ValueRange.of(1, 91) : ValueRange.of(1, 90);
          } else if (qoy === 2) {
            return ValueRange.of(1, 91);
          } else if (qoy === 3 || qoy === 4) {
            return ValueRange.of(1, 92);
          }
          return this.range();
        };
        _proto2.getFrom = function getFrom(temporal) {
          if (temporal.isSupported(this) === false) {
            throw new UnsupportedTemporalTypeException("Unsupported field: DayOfQuarter");
          }
          var doy = temporal.get(ChronoField.DAY_OF_YEAR);
          var moy = temporal.get(ChronoField.MONTH_OF_YEAR);
          var year = temporal.getLong(ChronoField.YEAR);
          return doy - QUARTER_DAYS[MathUtil.intDiv(moy - 1, 3) + (IsoChronology.isLeapYear(year) ? 4 : 0)];
        };
        _proto2.adjustInto = function adjustInto(temporal, newValue) {
          var curValue = this.getFrom(temporal);
          this.range().checkValidValue(newValue, this);
          return temporal.with(ChronoField.DAY_OF_YEAR, temporal.getLong(ChronoField.DAY_OF_YEAR) + (newValue - curValue));
        };
        _proto2.resolve = function resolve(fieldValues, partialTemporal, resolverStyle) {
          var yearLong = fieldValues.get(ChronoField.YEAR);
          var qoyLong = fieldValues.get(QUARTER_OF_YEAR);
          if (yearLong == null || qoyLong == null) {
            return null;
          }
          var y = ChronoField.YEAR.checkValidIntValue(yearLong);
          var doq = fieldValues.get(DAY_OF_QUARTER);
          var date;
          if (resolverStyle === ResolverStyle.LENIENT) {
            var qoy = qoyLong;
            date = LocalDate2.of(y, 1, 1);
            date = date.plusMonths(MathUtil.safeMultiply(MathUtil.safeSubtract(qoy, 1), 3));
            date = date.plusDays(MathUtil.safeSubtract(doq, 1));
          } else {
            var _qoy = QUARTER_OF_YEAR.range().checkValidIntValue(qoyLong, QUARTER_OF_YEAR);
            if (resolverStyle === ResolverStyle.STRICT) {
              var max = 92;
              if (_qoy === 1) {
                max = IsoChronology.isLeapYear(y) ? 91 : 90;
              } else if (_qoy === 2) {
                max = 91;
              }
              ValueRange.of(1, max).checkValidValue(doq, this);
            } else {
              this.range().checkValidValue(doq, this);
            }
            date = LocalDate2.of(y, (_qoy - 1) * 3 + 1, 1).plusDays(doq - 1);
          }
          fieldValues.remove(this);
          fieldValues.remove(ChronoField.YEAR);
          fieldValues.remove(QUARTER_OF_YEAR);
          return date;
        };
        return DAY_OF_QUARTER_FIELD2;
      }(Field);
      var QUARTER_OF_YEAR_FIELD = function(_Field2) {
        _inheritsLoose(QUARTER_OF_YEAR_FIELD2, _Field2);
        function QUARTER_OF_YEAR_FIELD2() {
          return _Field2.apply(this, arguments) || this;
        }
        var _proto3 = QUARTER_OF_YEAR_FIELD2.prototype;
        _proto3.toString = function toString() {
          return "QuarterOfYear";
        };
        _proto3.baseUnit = function baseUnit() {
          return QUARTER_YEARS;
        };
        _proto3.rangeUnit = function rangeUnit() {
          return ChronoUnit.YEARS;
        };
        _proto3.range = function range() {
          return ValueRange.of(1, 4);
        };
        _proto3.isSupportedBy = function isSupportedBy(temporal) {
          return temporal.isSupported(ChronoField.MONTH_OF_YEAR) && this._isIso(temporal);
        };
        _proto3.rangeRefinedBy = function rangeRefinedBy(temporal) {
          return this.range();
        };
        _proto3.getFrom = function getFrom(temporal) {
          if (temporal.isSupported(this) === false) {
            throw new UnsupportedTemporalTypeException("Unsupported field: QuarterOfYear");
          }
          var moy = temporal.getLong(ChronoField.MONTH_OF_YEAR);
          return MathUtil.intDiv(moy + 2, 3);
        };
        _proto3.adjustInto = function adjustInto(temporal, newValue) {
          var curValue = this.getFrom(temporal);
          this.range().checkValidValue(newValue, this);
          return temporal.with(ChronoField.MONTH_OF_YEAR, temporal.getLong(ChronoField.MONTH_OF_YEAR) + (newValue - curValue) * 3);
        };
        return QUARTER_OF_YEAR_FIELD2;
      }(Field);
      var WEEK_OF_WEEK_BASED_YEAR_FIELD = function(_Field3) {
        _inheritsLoose(WEEK_OF_WEEK_BASED_YEAR_FIELD2, _Field3);
        function WEEK_OF_WEEK_BASED_YEAR_FIELD2() {
          return _Field3.apply(this, arguments) || this;
        }
        var _proto4 = WEEK_OF_WEEK_BASED_YEAR_FIELD2.prototype;
        _proto4.toString = function toString() {
          return "WeekOfWeekBasedYear";
        };
        _proto4.baseUnit = function baseUnit() {
          return ChronoUnit.WEEKS;
        };
        _proto4.rangeUnit = function rangeUnit() {
          return WEEK_BASED_YEARS;
        };
        _proto4.range = function range() {
          return ValueRange.of(1, 52, 53);
        };
        _proto4.isSupportedBy = function isSupportedBy(temporal) {
          return temporal.isSupported(ChronoField.EPOCH_DAY) && this._isIso(temporal);
        };
        _proto4.rangeRefinedBy = function rangeRefinedBy(temporal) {
          if (temporal.isSupported(this) === false) {
            throw new UnsupportedTemporalTypeException("Unsupported field: WeekOfWeekBasedYear");
          }
          return Field._getWeekRangeByLocalDate(LocalDate2.from(temporal));
        };
        _proto4.getFrom = function getFrom(temporal) {
          if (temporal.isSupported(this) === false) {
            throw new UnsupportedTemporalTypeException("Unsupported field: WeekOfWeekBasedYear");
          }
          return Field._getWeek(LocalDate2.from(temporal));
        };
        _proto4.adjustInto = function adjustInto(temporal, newValue) {
          this.range().checkValidValue(newValue, this);
          return temporal.plus(MathUtil.safeSubtract(newValue, this.getFrom(temporal)), ChronoUnit.WEEKS);
        };
        _proto4.resolve = function resolve(fieldValues, partialTemporal, resolverStyle) {
          var wbyLong = fieldValues.get(WEEK_BASED_YEAR);
          var dowLong = fieldValues.get(ChronoField.DAY_OF_WEEK);
          if (wbyLong == null || dowLong == null) {
            return null;
          }
          var wby = WEEK_BASED_YEAR.range().checkValidIntValue(wbyLong, WEEK_BASED_YEAR);
          var wowby = fieldValues.get(WEEK_OF_WEEK_BASED_YEAR);
          var date;
          if (resolverStyle === ResolverStyle.LENIENT) {
            var dow = dowLong;
            var weeks = 0;
            if (dow > 7) {
              weeks = MathUtil.intDiv(dow - 1, 7);
              dow = MathUtil.intMod(dow - 1, 7) + 1;
            } else if (dow < 1) {
              weeks = MathUtil.intDiv(dow, 7) - 1;
              dow = MathUtil.intMod(dow, 7) + 7;
            }
            date = LocalDate2.of(wby, 1, 4).plusWeeks(wowby - 1).plusWeeks(weeks).with(ChronoField.DAY_OF_WEEK, dow);
          } else {
            var _dow2 = ChronoField.DAY_OF_WEEK.checkValidIntValue(dowLong);
            if (resolverStyle === ResolverStyle.STRICT) {
              var temp = LocalDate2.of(wby, 1, 4);
              var range = Field._getWeekRangeByLocalDate(temp);
              range.checkValidValue(wowby, this);
            } else {
              this.range().checkValidValue(wowby, this);
            }
            date = LocalDate2.of(wby, 1, 4).plusWeeks(wowby - 1).with(ChronoField.DAY_OF_WEEK, _dow2);
          }
          fieldValues.remove(this);
          fieldValues.remove(WEEK_BASED_YEAR);
          fieldValues.remove(ChronoField.DAY_OF_WEEK);
          return date;
        };
        _proto4.displayName = function displayName() {
          return "Week";
        };
        return WEEK_OF_WEEK_BASED_YEAR_FIELD2;
      }(Field);
      var WEEK_BASED_YEAR_FIELD = function(_Field4) {
        _inheritsLoose(WEEK_BASED_YEAR_FIELD2, _Field4);
        function WEEK_BASED_YEAR_FIELD2() {
          return _Field4.apply(this, arguments) || this;
        }
        var _proto5 = WEEK_BASED_YEAR_FIELD2.prototype;
        _proto5.toString = function toString() {
          return "WeekBasedYear";
        };
        _proto5.baseUnit = function baseUnit() {
          return WEEK_BASED_YEARS;
        };
        _proto5.rangeUnit = function rangeUnit() {
          return ChronoUnit.FOREVER;
        };
        _proto5.range = function range() {
          return ChronoField.YEAR.range();
        };
        _proto5.isSupportedBy = function isSupportedBy(temporal) {
          return temporal.isSupported(ChronoField.EPOCH_DAY) && this._isIso(temporal);
        };
        _proto5.rangeRefinedBy = function rangeRefinedBy(temporal) {
          return ChronoField.YEAR.range();
        };
        _proto5.getFrom = function getFrom(temporal) {
          if (temporal.isSupported(this) === false) {
            throw new UnsupportedTemporalTypeException("Unsupported field: WeekBasedYear");
          }
          return Field._getWeekBasedYear(LocalDate2.from(temporal));
        };
        _proto5.adjustInto = function adjustInto(temporal, newValue) {
          if (this.isSupportedBy(temporal) === false) {
            throw new UnsupportedTemporalTypeException("Unsupported field: WeekBasedYear");
          }
          var newWby = this.range().checkValidIntValue(newValue, WEEK_BASED_YEAR);
          var date = LocalDate2.from(temporal);
          var dow = date.get(ChronoField.DAY_OF_WEEK);
          var week = Field._getWeek(date);
          if (week === 53 && Field._getWeekRangeByYear(newWby) === 52) {
            week = 52;
          }
          var resolved = LocalDate2.of(newWby, 1, 4);
          var days = dow - resolved.get(ChronoField.DAY_OF_WEEK) + (week - 1) * 7;
          resolved = resolved.plusDays(days);
          return temporal.with(resolved);
        };
        return WEEK_BASED_YEAR_FIELD2;
      }(Field);
      var Unit = function(_TemporalUnit) {
        _inheritsLoose(Unit2, _TemporalUnit);
        function Unit2(name, estimatedDuration) {
          var _this;
          _this = _TemporalUnit.call(this) || this;
          _this._name = name;
          _this._duration = estimatedDuration;
          return _this;
        }
        var _proto6 = Unit2.prototype;
        _proto6.duration = function duration() {
          return this._duration;
        };
        _proto6.isDurationEstimated = function isDurationEstimated() {
          return true;
        };
        _proto6.isDateBased = function isDateBased() {
          return true;
        };
        _proto6.isTimeBased = function isTimeBased() {
          return false;
        };
        _proto6.isSupportedBy = function isSupportedBy(temporal) {
          return temporal.isSupported(ChronoField.EPOCH_DAY);
        };
        _proto6.addTo = function addTo(temporal, periodToAdd) {
          switch (this) {
            case WEEK_BASED_YEARS: {
              var added = MathUtil.safeAdd(temporal.get(WEEK_BASED_YEAR), periodToAdd);
              return temporal.with(WEEK_BASED_YEAR, added);
            }
            case QUARTER_YEARS:
              return temporal.plus(MathUtil.intDiv(periodToAdd, 256), ChronoUnit.YEARS).plus(MathUtil.intMod(periodToAdd, 256) * 3, ChronoUnit.MONTHS);
            default:
              throw new IllegalStateException("Unreachable");
          }
        };
        _proto6.between = function between(temporal1, temporal2) {
          switch (this) {
            case WEEK_BASED_YEARS:
              return MathUtil.safeSubtract(temporal2.getLong(WEEK_BASED_YEAR), temporal1.getLong(WEEK_BASED_YEAR));
            case QUARTER_YEARS:
              return MathUtil.intDiv(temporal1.until(temporal2, ChronoUnit.MONTHS), 3);
            default:
              throw new IllegalStateException("Unreachable");
          }
        };
        _proto6.toString = function toString() {
          return this._name;
        };
        return Unit2;
      }(TemporalUnit);
      var DAY_OF_QUARTER = null;
      var QUARTER_OF_YEAR = null;
      var WEEK_OF_WEEK_BASED_YEAR = null;
      var WEEK_BASED_YEAR = null;
      var WEEK_BASED_YEARS = null;
      var QUARTER_YEARS = null;
      function _init$f() {
        DAY_OF_QUARTER = new DAY_OF_QUARTER_FIELD();
        QUARTER_OF_YEAR = new QUARTER_OF_YEAR_FIELD();
        WEEK_OF_WEEK_BASED_YEAR = new WEEK_OF_WEEK_BASED_YEAR_FIELD();
        WEEK_BASED_YEAR = new WEEK_BASED_YEAR_FIELD();
        WEEK_BASED_YEARS = new Unit("WeekBasedYears", Duration.ofSeconds(31556952));
        QUARTER_YEARS = new Unit("QuarterYears", Duration.ofSeconds(31556952 / 4));
        IsoFields.DAY_OF_QUARTER = DAY_OF_QUARTER;
        IsoFields.QUARTER_OF_YEAR = QUARTER_OF_YEAR;
        IsoFields.WEEK_OF_WEEK_BASED_YEAR = WEEK_OF_WEEK_BASED_YEAR;
        IsoFields.WEEK_BASED_YEAR = WEEK_BASED_YEAR;
        IsoFields.WEEK_BASED_YEARS = WEEK_BASED_YEARS;
        IsoFields.QUARTER_YEARS = QUARTER_YEARS;
        LocalDate2.prototype.isoWeekOfWeekyear = function() {
          return this.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
        };
        LocalDate2.prototype.isoWeekyear = function() {
          return this.get(IsoFields.WEEK_BASED_YEAR);
        };
      }
      var DecimalStyle = function() {
        function DecimalStyle2(zeroChar, positiveSignChar, negativeSignChar, decimalPointChar) {
          this._zeroDigit = zeroChar;
          this._zeroDigitCharCode = zeroChar.charCodeAt(0);
          this._positiveSign = positiveSignChar;
          this._negativeSign = negativeSignChar;
          this._decimalSeparator = decimalPointChar;
        }
        var _proto = DecimalStyle2.prototype;
        _proto.positiveSign = function positiveSign() {
          return this._positiveSign;
        };
        _proto.withPositiveSign = function withPositiveSign(positiveSign) {
          if (positiveSign === this._positiveSign) {
            return this;
          }
          return new DecimalStyle2(this._zeroDigit, positiveSign, this._negativeSign, this._decimalSeparator);
        };
        _proto.negativeSign = function negativeSign() {
          return this._negativeSign;
        };
        _proto.withNegativeSign = function withNegativeSign(negativeSign) {
          if (negativeSign === this._negativeSign) {
            return this;
          }
          return new DecimalStyle2(this._zeroDigit, this._positiveSign, negativeSign, this._decimalSeparator);
        };
        _proto.zeroDigit = function zeroDigit() {
          return this._zeroDigit;
        };
        _proto.withZeroDigit = function withZeroDigit(zeroDigit) {
          if (zeroDigit === this._zeroDigit) {
            return this;
          }
          return new DecimalStyle2(zeroDigit, this._positiveSign, this._negativeSign, this._decimalSeparator);
        };
        _proto.decimalSeparator = function decimalSeparator() {
          return this._decimalSeparator;
        };
        _proto.withDecimalSeparator = function withDecimalSeparator(decimalSeparator) {
          if (decimalSeparator === this._decimalSeparator) {
            return this;
          }
          return new DecimalStyle2(this._zeroDigit, this._positiveSign, this._negativeSign, decimalSeparator);
        };
        _proto.convertToDigit = function convertToDigit(char) {
          var val = char.charCodeAt(0) - this._zeroDigitCharCode;
          return val >= 0 && val <= 9 ? val : -1;
        };
        _proto.convertNumberToI18N = function convertNumberToI18N(numericText) {
          if (this._zeroDigit === "0") {
            return numericText;
          }
          var diff = this._zeroDigitCharCode - "0".charCodeAt(0);
          var convertedText = "";
          for (var i = 0; i < numericText.length; i++) {
            convertedText += String.fromCharCode(numericText.charCodeAt(i) + diff);
          }
          return convertedText;
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof DecimalStyle2) {
            return this._zeroDigit === other._zeroDigit && this._positiveSign === other._positiveSign && this._negativeSign === other._negativeSign && this._decimalSeparator === other._decimalSeparator;
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          return this._zeroDigit + this._positiveSign + this._negativeSign + this._decimalSeparator;
        };
        _proto.toString = function toString() {
          return "DecimalStyle[" + this._zeroDigit + this._positiveSign + this._negativeSign + this._decimalSeparator + "]";
        };
        DecimalStyle2.of = function of() {
          throw new Error("not yet supported");
        };
        DecimalStyle2.availableLocales = function availableLocales() {
          throw new Error("not yet supported");
        };
        return DecimalStyle2;
      }();
      DecimalStyle.STANDARD = new DecimalStyle("0", "+", "-", ".");
      var SignStyle = function(_Enum) {
        _inheritsLoose(SignStyle2, _Enum);
        function SignStyle2() {
          return _Enum.apply(this, arguments) || this;
        }
        var _proto = SignStyle2.prototype;
        _proto.parse = function parse(positive, strict, fixedWidth) {
          switch (this) {
            case SignStyle2.NORMAL:
              return !positive || !strict;
            case SignStyle2.ALWAYS:
            case SignStyle2.EXCEEDS_PAD:
              return true;
            default:
              return !strict && !fixedWidth;
          }
        };
        return SignStyle2;
      }(Enum);
      SignStyle.NORMAL = new SignStyle("NORMAL");
      SignStyle.NEVER = new SignStyle("NEVER");
      SignStyle.ALWAYS = new SignStyle("ALWAYS");
      SignStyle.EXCEEDS_PAD = new SignStyle("EXCEEDS_PAD");
      SignStyle.NOT_NEGATIVE = new SignStyle("NOT_NEGATIVE");
      var TextStyle = function(_Enum) {
        _inheritsLoose(TextStyle2, _Enum);
        function TextStyle2() {
          return _Enum.apply(this, arguments) || this;
        }
        var _proto = TextStyle2.prototype;
        _proto.isStandalone = function isStandalone() {
          switch (this) {
            case TextStyle2.FULL_STANDALONE:
            case TextStyle2.SHORT_STANDALONE:
            case TextStyle2.NARROW_STANDALONE:
              return true;
            default:
              return false;
          }
        };
        _proto.asStandalone = function asStandalone() {
          switch (this) {
            case TextStyle2.FULL:
              return TextStyle2.FULL_STANDALONE;
            case TextStyle2.SHORT:
              return TextStyle2.SHORT_STANDALONE;
            case TextStyle2.NARROW:
              return TextStyle2.NARROW_STANDALONE;
            default:
              return this;
          }
        };
        _proto.asNormal = function asNormal() {
          switch (this) {
            case TextStyle2.FULL_STANDALONE:
              return TextStyle2.FULL;
            case TextStyle2.SHORT_STANDALONE:
              return TextStyle2.SHORT;
            case TextStyle2.NARROW_STANDALONE:
              return TextStyle2.NARROW;
            default:
              return this;
          }
        };
        return TextStyle2;
      }(Enum);
      TextStyle.FULL = new TextStyle("FULL");
      TextStyle.FULL_STANDALONE = new TextStyle("FULL_STANDALONE");
      TextStyle.SHORT = new TextStyle("SHORT");
      TextStyle.SHORT_STANDALONE = new TextStyle("SHORT_STANDALONE");
      TextStyle.NARROW = new TextStyle("NARROW");
      TextStyle.NARROW_STANDALONE = new TextStyle("NARROW_STANDALONE");
      var CharLiteralPrinterParser = function() {
        function CharLiteralPrinterParser2(literal) {
          if (literal.length > 1) {
            throw new IllegalArgumentException('invalid literal, too long: "' + literal + '"');
          }
          this._literal = literal;
        }
        var _proto = CharLiteralPrinterParser2.prototype;
        _proto.print = function print(context, buf) {
          buf.append(this._literal);
          return true;
        };
        _proto.parse = function parse(context, text, position) {
          var length = text.length;
          if (position === length) {
            return ~position;
          }
          var ch = text.charAt(position);
          if (context.charEquals(this._literal, ch) === false) {
            return ~position;
          }
          return position + this._literal.length;
        };
        _proto.toString = function toString() {
          if (this._literal === "'") {
            return "''";
          }
          return "'" + this._literal + "'";
        };
        return CharLiteralPrinterParser2;
      }();
      var CompositePrinterParser = function() {
        function CompositePrinterParser2(printerParsers, optional) {
          this._printerParsers = printerParsers;
          this._optional = optional;
        }
        var _proto = CompositePrinterParser2.prototype;
        _proto.withOptional = function withOptional(optional) {
          if (optional === this._optional) {
            return this;
          }
          return new CompositePrinterParser2(this._printerParsers, optional);
        };
        _proto.print = function print(context, buf) {
          var length = buf.length();
          if (this._optional) {
            context.startOptional();
          }
          try {
            for (var i = 0; i < this._printerParsers.length; i++) {
              var pp = this._printerParsers[i];
              if (pp.print(context, buf) === false) {
                buf.setLength(length);
                return true;
              }
            }
          } finally {
            if (this._optional) {
              context.endOptional();
            }
          }
          return true;
        };
        _proto.parse = function parse(context, text, position) {
          if (this._optional) {
            context.startOptional();
            var pos = position;
            for (var i = 0; i < this._printerParsers.length; i++) {
              var pp = this._printerParsers[i];
              pos = pp.parse(context, text, pos);
              if (pos < 0) {
                context.endOptional(false);
                return position;
              }
            }
            context.endOptional(true);
            return pos;
          } else {
            for (var _i = 0; _i < this._printerParsers.length; _i++) {
              var _pp = this._printerParsers[_i];
              position = _pp.parse(context, text, position);
              if (position < 0) {
                break;
              }
            }
            return position;
          }
        };
        _proto.toString = function toString() {
          var buf = "";
          if (this._printerParsers != null) {
            buf += this._optional ? "[" : "(";
            for (var i = 0; i < this._printerParsers.length; i++) {
              var pp = this._printerParsers[i];
              buf += pp.toString();
            }
            buf += this._optional ? "]" : ")";
          }
          return buf;
        };
        return CompositePrinterParser2;
      }();
      var FractionPrinterParser = function() {
        function FractionPrinterParser2(field, minWidth, maxWidth, decimalPoint) {
          requireNonNull(field, "field");
          if (field.range().isFixed() === false) {
            throw new IllegalArgumentException("Field must have a fixed set of values: " + field);
          }
          if (minWidth < 0 || minWidth > 9) {
            throw new IllegalArgumentException("Minimum width must be from 0 to 9 inclusive but was " + minWidth);
          }
          if (maxWidth < 1 || maxWidth > 9) {
            throw new IllegalArgumentException("Maximum width must be from 1 to 9 inclusive but was " + maxWidth);
          }
          if (maxWidth < minWidth) {
            throw new IllegalArgumentException("Maximum width must exceed or equal the minimum width but " + maxWidth + " < " + minWidth);
          }
          this.field = field;
          this.minWidth = minWidth;
          this.maxWidth = maxWidth;
          this.decimalPoint = decimalPoint;
        }
        var _proto = FractionPrinterParser2.prototype;
        _proto.print = function print(context, buf) {
          var value = context.getValue(this.field);
          if (value === null) {
            return false;
          }
          var symbols = context.symbols();
          if (value === 0) {
            if (this.minWidth > 0) {
              if (this.decimalPoint) {
                buf.append(symbols.decimalSeparator());
              }
              for (var i = 0; i < this.minWidth; i++) {
                buf.append(symbols.zeroDigit());
              }
            }
          } else {
            var fraction = this.convertToFraction(value, symbols.zeroDigit());
            var outputScale = Math.min(Math.max(fraction.length, this.minWidth), this.maxWidth);
            fraction = fraction.substr(0, outputScale);
            if (fraction * 1 > 0) {
              while (fraction.length > this.minWidth && fraction[fraction.length - 1] === "0") {
                fraction = fraction.substr(0, fraction.length - 1);
              }
            }
            var str = fraction;
            str = symbols.convertNumberToI18N(str);
            if (this.decimalPoint) {
              buf.append(symbols.decimalSeparator());
            }
            buf.append(str);
          }
          return true;
        };
        _proto.parse = function parse(context, text, position) {
          var effectiveMin = context.isStrict() ? this.minWidth : 0;
          var effectiveMax = context.isStrict() ? this.maxWidth : 9;
          var length = text.length;
          if (position === length) {
            return effectiveMin > 0 ? ~position : position;
          }
          if (this.decimalPoint) {
            if (text[position] !== context.symbols().decimalSeparator()) {
              return effectiveMin > 0 ? ~position : position;
            }
            position++;
          }
          var minEndPos = position + effectiveMin;
          if (minEndPos > length) {
            return ~position;
          }
          var maxEndPos = Math.min(position + effectiveMax, length);
          var total = 0;
          var pos = position;
          while (pos < maxEndPos) {
            var ch = text.charAt(pos++);
            var digit = context.symbols().convertToDigit(ch);
            if (digit < 0) {
              if (pos < minEndPos) {
                return ~position;
              }
              pos--;
              break;
            }
            total = total * 10 + digit;
          }
          var moveLeft = pos - position;
          var scale = Math.pow(10, moveLeft);
          var value = this.convertFromFraction(total, scale);
          return context.setParsedField(this.field, value, position, pos);
        };
        _proto.convertToFraction = function convertToFraction(value, zeroDigit) {
          var range = this.field.range();
          range.checkValidValue(value, this.field);
          var _min = range.minimum();
          var _range = range.maximum() - _min + 1;
          var _value = value - _min;
          var _scaled = MathUtil.intDiv(_value * 1e9, _range);
          var fraction = "" + _scaled;
          while (fraction.length < 9) {
            fraction = zeroDigit + fraction;
          }
          return fraction;
        };
        _proto.convertFromFraction = function convertFromFraction(total, scale) {
          var range = this.field.range();
          var _min = range.minimum();
          var _range = range.maximum() - _min + 1;
          var _value = MathUtil.intDiv(total * _range, scale);
          return _value;
        };
        _proto.toString = function toString() {
          var decimal = this.decimalPoint ? ",DecimalPoint" : "";
          return "Fraction(" + this.field + "," + this.minWidth + "," + this.maxWidth + decimal + ")";
        };
        return FractionPrinterParser2;
      }();
      var MAX_WIDTH$1 = 15;
      var EXCEED_POINTS = [0, 10, 100, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9];
      var NumberPrinterParser = function() {
        function NumberPrinterParser2(field, minWidth, maxWidth, signStyle, subsequentWidth) {
          if (subsequentWidth === void 0) {
            subsequentWidth = 0;
          }
          this._field = field;
          this._minWidth = minWidth;
          this._maxWidth = maxWidth;
          this._signStyle = signStyle;
          this._subsequentWidth = subsequentWidth;
        }
        var _proto = NumberPrinterParser2.prototype;
        _proto.field = function field() {
          return this._field;
        };
        _proto.minWidth = function minWidth() {
          return this._minWidth;
        };
        _proto.maxWidth = function maxWidth() {
          return this._maxWidth;
        };
        _proto.signStyle = function signStyle() {
          return this._signStyle;
        };
        _proto.withFixedWidth = function withFixedWidth() {
          if (this._subsequentWidth === -1) {
            return this;
          }
          return new NumberPrinterParser2(this._field, this._minWidth, this._maxWidth, this._signStyle, -1);
        };
        _proto.withSubsequentWidth = function withSubsequentWidth(subsequentWidth) {
          return new NumberPrinterParser2(this._field, this._minWidth, this._maxWidth, this._signStyle, this._subsequentWidth + subsequentWidth);
        };
        _proto._isFixedWidth = function _isFixedWidth() {
          return this._subsequentWidth === -1 || this._subsequentWidth > 0 && this._minWidth === this._maxWidth && this._signStyle === SignStyle.NOT_NEGATIVE;
        };
        _proto.print = function print(context, buf) {
          var contextValue = context.getValue(this._field);
          if (contextValue == null) {
            return false;
          }
          var value = this._getValue(context, contextValue);
          var symbols = context.symbols();
          var str = "" + Math.abs(value);
          if (str.length > this._maxWidth) {
            throw new DateTimeException("Field " + this._field + " cannot be printed as the value " + value + " exceeds the maximum print width of " + this._maxWidth);
          }
          str = symbols.convertNumberToI18N(str);
          if (value >= 0) {
            switch (this._signStyle) {
              case SignStyle.EXCEEDS_PAD:
                if (this._minWidth < MAX_WIDTH$1 && value >= EXCEED_POINTS[this._minWidth]) {
                  buf.append(symbols.positiveSign());
                }
                break;
              case SignStyle.ALWAYS:
                buf.append(symbols.positiveSign());
                break;
            }
          } else {
            switch (this._signStyle) {
              case SignStyle.NORMAL:
              case SignStyle.EXCEEDS_PAD:
              case SignStyle.ALWAYS:
                buf.append(symbols.negativeSign());
                break;
              case SignStyle.NOT_NEGATIVE:
                throw new DateTimeException("Field " + this._field + " cannot be printed as the value " + value + " cannot be negative according to the SignStyle");
            }
          }
          for (var i = 0; i < this._minWidth - str.length; i++) {
            buf.append(symbols.zeroDigit());
          }
          buf.append(str);
          return true;
        };
        _proto.parse = function parse(context, text, position) {
          var length = text.length;
          if (position === length) {
            return ~position;
          }
          assert3(position >= 0 && position < length);
          var sign = text.charAt(position);
          var negative = false;
          var positive = false;
          if (sign === context.symbols().positiveSign()) {
            if (this._signStyle.parse(true, context.isStrict(), this._minWidth === this._maxWidth) === false) {
              return ~position;
            }
            positive = true;
            position++;
          } else if (sign === context.symbols().negativeSign()) {
            if (this._signStyle.parse(false, context.isStrict(), this._minWidth === this._maxWidth) === false) {
              return ~position;
            }
            negative = true;
            position++;
          } else {
            if (this._signStyle === SignStyle.ALWAYS && context.isStrict()) {
              return ~position;
            }
          }
          var effMinWidth = context.isStrict() || this._isFixedWidth() ? this._minWidth : 1;
          var minEndPos = position + effMinWidth;
          if (minEndPos > length) {
            return ~position;
          }
          var effMaxWidth = (context.isStrict() || this._isFixedWidth() ? this._maxWidth : 9) + Math.max(this._subsequentWidth, 0);
          var total = 0;
          var pos = position;
          for (var pass = 0; pass < 2; pass++) {
            var maxEndPos = Math.min(pos + effMaxWidth, length);
            while (pos < maxEndPos) {
              var ch = text.charAt(pos++);
              var digit = context.symbols().convertToDigit(ch);
              if (digit < 0) {
                pos--;
                if (pos < minEndPos) {
                  return ~position;
                }
                break;
              }
              if (pos - position > MAX_WIDTH$1) {
                throw new ArithmeticException("number text exceeds length");
              } else {
                total = total * 10 + digit;
              }
            }
            if (this._subsequentWidth > 0 && pass === 0) {
              var parseLen = pos - position;
              effMaxWidth = Math.max(effMinWidth, parseLen - this._subsequentWidth);
              pos = position;
              total = 0;
            } else {
              break;
            }
          }
          if (negative) {
            if (total === 0 && context.isStrict()) {
              return ~(position - 1);
            }
            if (total !== 0) {
              total = -total;
            }
          } else if (this._signStyle === SignStyle.EXCEEDS_PAD && context.isStrict()) {
            var _parseLen = pos - position;
            if (positive) {
              if (_parseLen <= this._minWidth) {
                return ~(position - 1);
              }
            } else {
              if (_parseLen > this._minWidth) {
                return ~position;
              }
            }
          }
          return this._setValue(context, total, position, pos);
        };
        _proto._getValue = function _getValue(context, value) {
          return value;
        };
        _proto._setValue = function _setValue(context, value, errorPos, successPos) {
          return context.setParsedField(this._field, value, errorPos, successPos);
        };
        _proto.toString = function toString() {
          if (this._minWidth === 1 && this._maxWidth === MAX_WIDTH$1 && this._signStyle === SignStyle.NORMAL) {
            return "Value(" + this._field + ")";
          }
          if (this._minWidth === this._maxWidth && this._signStyle === SignStyle.NOT_NEGATIVE) {
            return "Value(" + this._field + "," + this._minWidth + ")";
          }
          return "Value(" + this._field + "," + this._minWidth + "," + this._maxWidth + "," + this._signStyle + ")";
        };
        return NumberPrinterParser2;
      }();
      var ReducedPrinterParser = function(_NumberPrinterParser) {
        _inheritsLoose(ReducedPrinterParser2, _NumberPrinterParser);
        function ReducedPrinterParser2(field, width, maxWidth, baseValue, baseDate) {
          var _this;
          _this = _NumberPrinterParser.call(this, field, width, maxWidth, SignStyle.NOT_NEGATIVE) || this;
          if (width < 1 || width > 10) {
            throw new IllegalArgumentException("The width must be from 1 to 10 inclusive but was " + width);
          }
          if (maxWidth < 1 || maxWidth > 10) {
            throw new IllegalArgumentException("The maxWidth must be from 1 to 10 inclusive but was " + maxWidth);
          }
          if (maxWidth < width) {
            throw new IllegalArgumentException("The maxWidth must be greater than the width");
          }
          if (baseDate === null) {
            if (field.range().isValidValue(baseValue) === false) {
              throw new IllegalArgumentException("The base value must be within the range of the field");
            }
            if (baseValue + EXCEED_POINTS[width] > MathUtil.MAX_SAFE_INTEGER) {
              throw new DateTimeException("Unable to add printer-parser as the range exceeds the capacity of an int");
            }
          }
          _this._baseValue = baseValue;
          _this._baseDate = baseDate;
          return _this;
        }
        var _proto2 = ReducedPrinterParser2.prototype;
        _proto2._getValue = function _getValue(context, value) {
          var absValue = Math.abs(value);
          var baseValue = this._baseValue;
          if (this._baseDate !== null) {
            context.temporal();
            var chrono = IsoChronology.INSTANCE;
            baseValue = chrono.date(this._baseDate).get(this._field);
          }
          if (value >= baseValue && value < baseValue + EXCEED_POINTS[this._minWidth]) {
            return absValue % EXCEED_POINTS[this._minWidth];
          }
          return absValue % EXCEED_POINTS[this._maxWidth];
        };
        _proto2._setValue = function _setValue(context, value, errorPos, successPos) {
          var baseValue = this._baseValue;
          if (this._baseDate != null) {
            var chrono = context.getEffectiveChronology();
            baseValue = chrono.date(this._baseDate).get(this._field);
          }
          var parseLen = successPos - errorPos;
          if (parseLen === this._minWidth && value >= 0) {
            var range = EXCEED_POINTS[this._minWidth];
            var lastPart = baseValue % range;
            var basePart = baseValue - lastPart;
            if (baseValue > 0) {
              value = basePart + value;
            } else {
              value = basePart - value;
            }
            if (value < baseValue) {
              value += range;
            }
          }
          return context.setParsedField(this._field, value, errorPos, successPos);
        };
        _proto2.withFixedWidth = function withFixedWidth() {
          if (this._subsequentWidth === -1) {
            return this;
          }
          return new ReducedPrinterParser2(this._field, this._minWidth, this._maxWidth, this._baseValue, this._baseDate);
        };
        _proto2.withSubsequentWidth = function withSubsequentWidth(subsequentWidth) {
          return new ReducedPrinterParser2(this._field, this._minWidth, this._maxWidth, this._baseValue, this._baseDate, this._subsequentWidth + subsequentWidth);
        };
        _proto2.isFixedWidth = function isFixedWidth(context) {
          if (context.isStrict() === false) {
            return false;
          }
          return _NumberPrinterParser.prototype.isFixedWidth.call(this, context);
        };
        _proto2.toString = function toString() {
          return "ReducedValue(" + this._field + "," + this._minWidth + "," + this._maxWidth + "," + (this._baseDate != null ? this._baseDate : this._baseValue) + ")";
        };
        return ReducedPrinterParser2;
      }(NumberPrinterParser);
      var PATTERNS = ["+HH", "+HHmm", "+HH:mm", "+HHMM", "+HH:MM", "+HHMMss", "+HH:MM:ss", "+HHMMSS", "+HH:MM:SS"];
      var OffsetIdPrinterParser = function() {
        function OffsetIdPrinterParser2(noOffsetText, pattern) {
          requireNonNull(noOffsetText, "noOffsetText");
          requireNonNull(pattern, "pattern");
          this.noOffsetText = noOffsetText;
          this.type = this._checkPattern(pattern);
        }
        var _proto = OffsetIdPrinterParser2.prototype;
        _proto._checkPattern = function _checkPattern(pattern) {
          for (var i = 0; i < PATTERNS.length; i++) {
            if (PATTERNS[i] === pattern) {
              return i;
            }
          }
          throw new IllegalArgumentException("Invalid zone offset pattern: " + pattern);
        };
        _proto.print = function print(context, buf) {
          var offsetSecs = context.getValue(ChronoField.OFFSET_SECONDS);
          if (offsetSecs == null) {
            return false;
          }
          var totalSecs = MathUtil.safeToInt(offsetSecs);
          if (totalSecs === 0) {
            buf.append(this.noOffsetText);
          } else {
            var absHours = Math.abs(MathUtil.intMod(MathUtil.intDiv(totalSecs, 3600), 100));
            var absMinutes = Math.abs(MathUtil.intMod(MathUtil.intDiv(totalSecs, 60), 60));
            var absSeconds = Math.abs(MathUtil.intMod(totalSecs, 60));
            var bufPos = buf.length();
            var output = absHours;
            buf.append(totalSecs < 0 ? "-" : "+").appendChar(MathUtil.intDiv(absHours, 10) + "0").appendChar(MathUtil.intMod(absHours, 10) + "0");
            if (this.type >= 3 || this.type >= 1 && absMinutes > 0) {
              buf.append(this.type % 2 === 0 ? ":" : "").appendChar(MathUtil.intDiv(absMinutes, 10) + "0").appendChar(absMinutes % 10 + "0");
              output += absMinutes;
              if (this.type >= 7 || this.type >= 5 && absSeconds > 0) {
                buf.append(this.type % 2 === 0 ? ":" : "").appendChar(MathUtil.intDiv(absSeconds, 10) + "0").appendChar(absSeconds % 10 + "0");
                output += absSeconds;
              }
            }
            if (output === 0) {
              buf.setLength(bufPos);
              buf.append(this.noOffsetText);
            }
          }
          return true;
        };
        _proto.parse = function parse(context, text, position) {
          var length = text.length;
          var noOffsetLen = this.noOffsetText.length;
          if (noOffsetLen === 0) {
            if (position === length) {
              return context.setParsedField(ChronoField.OFFSET_SECONDS, 0, position, position);
            }
          } else {
            if (position === length) {
              return ~position;
            }
            if (context.subSequenceEquals(text, position, this.noOffsetText, 0, noOffsetLen)) {
              return context.setParsedField(ChronoField.OFFSET_SECONDS, 0, position, position + noOffsetLen);
            }
          }
          var sign = text[position];
          if (sign === "+" || sign === "-") {
            var negative = sign === "-" ? -1 : 1;
            var array = [0, 0, 0, 0];
            array[0] = position + 1;
            if ((this._parseNumber(array, 1, text, true) || this._parseNumber(array, 2, text, this.type >= 3) || this._parseNumber(array, 3, text, false)) === false) {
              var offsetSecs = MathUtil.safeZero(negative * (array[1] * 3600 + array[2] * 60 + array[3]));
              return context.setParsedField(ChronoField.OFFSET_SECONDS, offsetSecs, position, array[0]);
            }
          }
          if (noOffsetLen === 0) {
            return context.setParsedField(ChronoField.OFFSET_SECONDS, 0, position, position + noOffsetLen);
          }
          return ~position;
        };
        _proto._parseNumber = function _parseNumber(array, arrayIndex, parseText, required) {
          if ((this.type + 3) / 2 < arrayIndex) {
            return false;
          }
          var pos = array[0];
          if (this.type % 2 === 0 && arrayIndex > 1) {
            if (pos + 1 > parseText.length || parseText[pos] !== ":") {
              return required;
            }
            pos++;
          }
          if (pos + 2 > parseText.length) {
            return required;
          }
          var ch1 = parseText[pos++];
          var ch2 = parseText[pos++];
          if (ch1 < "0" || ch1 > "9" || ch2 < "0" || ch2 > "9") {
            return required;
          }
          var value = (ch1.charCodeAt(0) - 48) * 10 + (ch2.charCodeAt(0) - 48);
          if (value < 0 || value > 59) {
            return required;
          }
          array[arrayIndex] = value;
          array[0] = pos;
          return false;
        };
        _proto.toString = function toString() {
          var converted = this.noOffsetText.replace("'", "''");
          return "Offset(" + PATTERNS[this.type] + ",'" + converted + "')";
        };
        return OffsetIdPrinterParser2;
      }();
      OffsetIdPrinterParser.INSTANCE_ID = new OffsetIdPrinterParser("Z", "+HH:MM:ss");
      OffsetIdPrinterParser.PATTERNS = PATTERNS;
      var PadPrinterParserDecorator = function() {
        function PadPrinterParserDecorator2(printerParser, padWidth, padChar) {
          this._printerParser = printerParser;
          this._padWidth = padWidth;
          this._padChar = padChar;
        }
        var _proto = PadPrinterParserDecorator2.prototype;
        _proto.print = function print(context, buf) {
          var preLen = buf.length();
          if (this._printerParser.print(context, buf) === false) {
            return false;
          }
          var len = buf.length() - preLen;
          if (len > this._padWidth) {
            throw new DateTimeException("Cannot print as output of " + len + " characters exceeds pad width of " + this._padWidth);
          }
          for (var i = 0; i < this._padWidth - len; i++) {
            buf.insert(preLen, this._padChar);
          }
          return true;
        };
        _proto.parse = function parse(context, text, position) {
          var strict = context.isStrict();
          var caseSensitive = context.isCaseSensitive();
          assert3(!(position > text.length));
          assert3(position >= 0);
          if (position === text.length) {
            return ~position;
          }
          var endPos = position + this._padWidth;
          if (endPos > text.length) {
            if (strict) {
              return ~position;
            }
            endPos = text.length;
          }
          var pos = position;
          while (pos < endPos && (caseSensitive ? text[pos] === this._padChar : context.charEquals(text[pos], this._padChar))) {
            pos++;
          }
          text = text.substring(0, endPos);
          var resultPos = this._printerParser.parse(context, text, pos);
          if (resultPos !== endPos && strict) {
            return ~(position + pos);
          }
          return resultPos;
        };
        _proto.toString = function toString() {
          return "Pad(" + this._printerParser + "," + this._padWidth + (this._padChar === " " ? ")" : ",'" + this._padChar + "')");
        };
        return PadPrinterParserDecorator2;
      }();
      var SettingsParser = function(_Enum) {
        _inheritsLoose(SettingsParser2, _Enum);
        function SettingsParser2() {
          return _Enum.apply(this, arguments) || this;
        }
        var _proto = SettingsParser2.prototype;
        _proto.print = function print() {
          return true;
        };
        _proto.parse = function parse(context, text, position) {
          switch (this) {
            case SettingsParser2.SENSITIVE:
              context.setCaseSensitive(true);
              break;
            case SettingsParser2.INSENSITIVE:
              context.setCaseSensitive(false);
              break;
            case SettingsParser2.STRICT:
              context.setStrict(true);
              break;
            case SettingsParser2.LENIENT:
              context.setStrict(false);
              break;
          }
          return position;
        };
        _proto.toString = function toString() {
          switch (this) {
            case SettingsParser2.SENSITIVE:
              return "ParseCaseSensitive(true)";
            case SettingsParser2.INSENSITIVE:
              return "ParseCaseSensitive(false)";
            case SettingsParser2.STRICT:
              return "ParseStrict(true)";
            case SettingsParser2.LENIENT:
              return "ParseStrict(false)";
          }
        };
        return SettingsParser2;
      }(Enum);
      SettingsParser.SENSITIVE = new SettingsParser("SENSITIVE");
      SettingsParser.INSENSITIVE = new SettingsParser("INSENSITIVE");
      SettingsParser.STRICT = new SettingsParser("STRICT");
      SettingsParser.LENIENT = new SettingsParser("LENIENT");
      var StringLiteralPrinterParser = function() {
        function StringLiteralPrinterParser2(literal) {
          this._literal = literal;
        }
        var _proto = StringLiteralPrinterParser2.prototype;
        _proto.print = function print(context, buf) {
          buf.append(this._literal);
          return true;
        };
        _proto.parse = function parse(context, text, position) {
          var length = text.length;
          assert3(!(position > length || position < 0));
          if (context.subSequenceEquals(text, position, this._literal, 0, this._literal.length) === false) {
            return ~position;
          }
          return position + this._literal.length;
        };
        _proto.toString = function toString() {
          var converted = this._literal.replace("'", "''");
          return "'" + converted + "'";
        };
        return StringLiteralPrinterParser2;
      }();
      var ZoneRulesProvider = function() {
        function ZoneRulesProvider2() {
        }
        ZoneRulesProvider2.getRules = function getRules(zoneId) {
          throw new DateTimeException("unsupported ZoneId:" + zoneId);
        };
        ZoneRulesProvider2.getAvailableZoneIds = function getAvailableZoneIds() {
          return [];
        };
        return ZoneRulesProvider2;
      }();
      var ZoneRegion = function(_ZoneId) {
        _inheritsLoose(ZoneRegion2, _ZoneId);
        ZoneRegion2.ofId = function ofId(zoneId) {
          var rules = ZoneRulesProvider.getRules(zoneId);
          return new ZoneRegion2(zoneId, rules);
        };
        function ZoneRegion2(id, rules) {
          var _this;
          _this = _ZoneId.call(this) || this;
          _this._id = id;
          _this._rules = rules;
          return _this;
        }
        var _proto = ZoneRegion2.prototype;
        _proto.id = function id() {
          return this._id;
        };
        _proto.rules = function rules() {
          return this._rules;
        };
        return ZoneRegion2;
      }(ZoneId2);
      var ZoneIdPrinterParser = function() {
        function ZoneIdPrinterParser2(query, description) {
          this.query = query;
          this.description = description;
        }
        var _proto = ZoneIdPrinterParser2.prototype;
        _proto.print = function print(context, buf) {
          var zone = context.getValueQuery(this.query);
          if (zone == null) {
            return false;
          }
          buf.append(zone.id());
          return true;
        };
        _proto.parse = function parse(context, text, position) {
          var length = text.length;
          if (position > length) {
            return ~position;
          }
          if (position === length) {
            return ~position;
          }
          var nextChar = text.charAt(position);
          if (nextChar === "+" || nextChar === "-") {
            var newContext = context.copy();
            var endPos = OffsetIdPrinterParser.INSTANCE_ID.parse(newContext, text, position);
            if (endPos < 0) {
              return endPos;
            }
            var offset = newContext.getParsed(ChronoField.OFFSET_SECONDS);
            var zone = ZoneOffset.ofTotalSeconds(offset);
            context.setParsedZone(zone);
            return endPos;
          } else if (length >= position + 2) {
            var nextNextChar = text.charAt(position + 1);
            if (context.charEquals(nextChar, "U") && context.charEquals(nextNextChar, "T")) {
              if (length >= position + 3 && context.charEquals(text.charAt(position + 2), "C")) {
                return this._parsePrefixedOffset(context, text, position, position + 3);
              }
              return this._parsePrefixedOffset(context, text, position, position + 2);
            } else if (context.charEquals(nextChar, "G") && length >= position + 3 && context.charEquals(nextNextChar, "M") && context.charEquals(text.charAt(position + 2), "T")) {
              return this._parsePrefixedOffset(context, text, position, position + 3);
            }
          }
          if (text.substr(position, 6) === "SYSTEM") {
            context.setParsedZone(ZoneId2.systemDefault());
            return position + 6;
          }
          if (context.charEquals(nextChar, "Z")) {
            context.setParsedZone(ZoneOffset.UTC);
            return position + 1;
          }
          var availableZoneIds = ZoneRulesProvider.getAvailableZoneIds();
          if (zoneIdTree.size !== availableZoneIds.length) {
            zoneIdTree = ZoneIdTree.createTreeMap(availableZoneIds);
          }
          var maxParseLength = length - position;
          var treeMap = zoneIdTree.treeMap;
          var parsedZoneId = null;
          var parseLength = 0;
          while (treeMap != null) {
            var parsedSubZoneId = text.substr(position, Math.min(treeMap.length, maxParseLength));
            treeMap = treeMap.get(parsedSubZoneId);
            if (treeMap != null && treeMap.isLeaf) {
              parsedZoneId = parsedSubZoneId;
              parseLength = treeMap.length;
            }
          }
          if (parsedZoneId != null) {
            context.setParsedZone(ZoneRegion.ofId(parsedZoneId));
            return position + parseLength;
          }
          return ~position;
        };
        _proto._parsePrefixedOffset = function _parsePrefixedOffset(context, text, prefixPos, position) {
          var prefix = text.substring(prefixPos, position).toUpperCase();
          var newContext = context.copy();
          if (position < text.length && context.charEquals(text.charAt(position), "Z")) {
            context.setParsedZone(ZoneId2.ofOffset(prefix, ZoneOffset.UTC));
            return position;
          }
          var endPos = OffsetIdPrinterParser.INSTANCE_ID.parse(newContext, text, position);
          if (endPos < 0) {
            context.setParsedZone(ZoneId2.ofOffset(prefix, ZoneOffset.UTC));
            return position;
          }
          var offsetSecs = newContext.getParsed(ChronoField.OFFSET_SECONDS);
          var offset = ZoneOffset.ofTotalSeconds(offsetSecs);
          context.setParsedZone(ZoneId2.ofOffset(prefix, offset));
          return endPos;
        };
        _proto.toString = function toString() {
          return this.description;
        };
        return ZoneIdPrinterParser2;
      }();
      var ZoneIdTree = function() {
        ZoneIdTree2.createTreeMap = function createTreeMap(availableZoneIds) {
          var sortedZoneIds = availableZoneIds.sort(function(a, b) {
            return a.length - b.length;
          });
          var treeMap = new ZoneIdTreeMap(sortedZoneIds[0].length, false);
          for (var i = 0; i < sortedZoneIds.length; i++) {
            treeMap.add(sortedZoneIds[i]);
          }
          return new ZoneIdTree2(sortedZoneIds.length, treeMap);
        };
        function ZoneIdTree2(size, treeMap) {
          this.size = size;
          this.treeMap = treeMap;
        }
        return ZoneIdTree2;
      }();
      var ZoneIdTreeMap = function() {
        function ZoneIdTreeMap2(length, isLeaf) {
          if (length === void 0) {
            length = 0;
          }
          if (isLeaf === void 0) {
            isLeaf = false;
          }
          this.length = length;
          this.isLeaf = isLeaf;
          this._treeMap = {};
        }
        var _proto2 = ZoneIdTreeMap2.prototype;
        _proto2.add = function add(zoneId) {
          var idLength = zoneId.length;
          if (idLength === this.length) {
            this._treeMap[zoneId] = new ZoneIdTreeMap2(idLength, true);
          } else if (idLength > this.length) {
            var subZoneId = zoneId.substr(0, this.length);
            var subTreeMap = this._treeMap[subZoneId];
            if (subTreeMap == null) {
              subTreeMap = new ZoneIdTreeMap2(idLength, false);
              this._treeMap[subZoneId] = subTreeMap;
            }
            subTreeMap.add(zoneId);
          }
        };
        _proto2.get = function get(zoneId) {
          return this._treeMap[zoneId];
        };
        return ZoneIdTreeMap2;
      }();
      var zoneIdTree = new ZoneIdTree([]);
      var MAX_WIDTH = 15;
      var DateTimeFormatterBuilder = function() {
        function DateTimeFormatterBuilder2() {
          this._active = this;
          this._parent = null;
          this._printerParsers = [];
          this._optional = false;
          this._padNextWidth = 0;
          this._padNextChar = null;
          this._valueParserIndex = -1;
        }
        DateTimeFormatterBuilder2._of = function _of(parent, optional) {
          requireNonNull(parent, "parent");
          requireNonNull(optional, "optional");
          var dtFormatterBuilder = new DateTimeFormatterBuilder2();
          dtFormatterBuilder._parent = parent;
          dtFormatterBuilder._optional = optional;
          return dtFormatterBuilder;
        };
        var _proto = DateTimeFormatterBuilder2.prototype;
        _proto.parseCaseSensitive = function parseCaseSensitive() {
          this._appendInternalPrinterParser(SettingsParser.SENSITIVE);
          return this;
        };
        _proto.parseCaseInsensitive = function parseCaseInsensitive() {
          this._appendInternalPrinterParser(SettingsParser.INSENSITIVE);
          return this;
        };
        _proto.parseStrict = function parseStrict() {
          this._appendInternalPrinterParser(SettingsParser.STRICT);
          return this;
        };
        _proto.parseLenient = function parseLenient() {
          this._appendInternalPrinterParser(SettingsParser.LENIENT);
          return this;
        };
        _proto.parseDefaulting = function parseDefaulting(field, value) {
          requireNonNull(field);
          this._appendInternal(new DefaultingParser(field, value));
          return this;
        };
        _proto.appendValue = function appendValue() {
          if (arguments.length === 1) {
            return this._appendValue1.apply(this, arguments);
          } else if (arguments.length === 2) {
            return this._appendValue2.apply(this, arguments);
          } else {
            return this._appendValue4.apply(this, arguments);
          }
        };
        _proto._appendValue1 = function _appendValue1(field) {
          requireNonNull(field);
          this._appendValuePrinterParser(new NumberPrinterParser(field, 1, MAX_WIDTH, SignStyle.NORMAL));
          return this;
        };
        _proto._appendValue2 = function _appendValue2(field, width) {
          requireNonNull(field);
          if (width < 1 || width > MAX_WIDTH) {
            throw new IllegalArgumentException("The width must be from 1 to " + MAX_WIDTH + " inclusive but was " + width);
          }
          var pp = new NumberPrinterParser(field, width, width, SignStyle.NOT_NEGATIVE);
          this._appendValuePrinterParser(pp);
          return this;
        };
        _proto._appendValue4 = function _appendValue4(field, minWidth, maxWidth, signStyle) {
          requireNonNull(field);
          requireNonNull(signStyle);
          if (minWidth === maxWidth && signStyle === SignStyle.NOT_NEGATIVE) {
            return this._appendValue2(field, maxWidth);
          }
          if (minWidth < 1 || minWidth > MAX_WIDTH) {
            throw new IllegalArgumentException("The minimum width must be from 1 to " + MAX_WIDTH + " inclusive but was " + minWidth);
          }
          if (maxWidth < 1 || maxWidth > MAX_WIDTH) {
            throw new IllegalArgumentException("The minimum width must be from 1 to " + MAX_WIDTH + " inclusive but was " + maxWidth);
          }
          if (maxWidth < minWidth) {
            throw new IllegalArgumentException("The maximum width must exceed or equal the minimum width but " + maxWidth + " < " + minWidth);
          }
          var pp = new NumberPrinterParser(field, minWidth, maxWidth, signStyle);
          this._appendValuePrinterParser(pp);
          return this;
        };
        _proto.appendValueReduced = function appendValueReduced() {
          if (arguments.length === 4 && arguments[3] instanceof ChronoLocalDate) {
            return this._appendValueReducedFieldWidthMaxWidthBaseDate.apply(this, arguments);
          } else {
            return this._appendValueReducedFieldWidthMaxWidthBaseValue.apply(this, arguments);
          }
        };
        _proto._appendValueReducedFieldWidthMaxWidthBaseValue = function _appendValueReducedFieldWidthMaxWidthBaseValue(field, width, maxWidth, baseValue) {
          requireNonNull(field, "field");
          var pp = new ReducedPrinterParser(field, width, maxWidth, baseValue, null);
          this._appendValuePrinterParser(pp);
          return this;
        };
        _proto._appendValueReducedFieldWidthMaxWidthBaseDate = function _appendValueReducedFieldWidthMaxWidthBaseDate(field, width, maxWidth, baseDate) {
          requireNonNull(field, "field");
          requireNonNull(baseDate, "baseDate");
          requireInstance(baseDate, ChronoLocalDate, "baseDate");
          var pp = new ReducedPrinterParser(field, width, maxWidth, 0, baseDate);
          this._appendValuePrinterParser(pp);
          return this;
        };
        _proto._appendValuePrinterParser = function _appendValuePrinterParser(pp) {
          assert3(pp != null);
          if (this._active._valueParserIndex >= 0 && this._active._printerParsers[this._active._valueParserIndex] instanceof NumberPrinterParser) {
            var activeValueParser = this._active._valueParserIndex;
            var basePP = this._active._printerParsers[activeValueParser];
            if (pp.minWidth() === pp.maxWidth() && pp.signStyle() === SignStyle.NOT_NEGATIVE) {
              basePP = basePP.withSubsequentWidth(pp.maxWidth());
              this._appendInternal(pp.withFixedWidth());
              this._active._valueParserIndex = activeValueParser;
            } else {
              basePP = basePP.withFixedWidth();
              this._active._valueParserIndex = this._appendInternal(pp);
            }
            this._active._printerParsers[activeValueParser] = basePP;
          } else {
            this._active._valueParserIndex = this._appendInternal(pp);
          }
          return this;
        };
        _proto.appendFraction = function appendFraction(field, minWidth, maxWidth, decimalPoint) {
          this._appendInternal(new FractionPrinterParser(field, minWidth, maxWidth, decimalPoint));
          return this;
        };
        _proto.appendInstant = function appendInstant(fractionalDigits) {
          if (fractionalDigits === void 0) {
            fractionalDigits = -2;
          }
          if (fractionalDigits < -2 || fractionalDigits > 9) {
            throw new IllegalArgumentException("Invalid fractional digits: " + fractionalDigits);
          }
          this._appendInternal(new InstantPrinterParser(fractionalDigits));
          return this;
        };
        _proto.appendOffsetId = function appendOffsetId() {
          this._appendInternal(OffsetIdPrinterParser.INSTANCE_ID);
          return this;
        };
        _proto.appendOffset = function appendOffset(pattern, noOffsetText) {
          this._appendInternalPrinterParser(new OffsetIdPrinterParser(noOffsetText, pattern));
          return this;
        };
        _proto.appendZoneId = function appendZoneId() {
          this._appendInternal(new ZoneIdPrinterParser(TemporalQueries.zoneId(), "ZoneId()"));
          return this;
        };
        _proto.appendPattern = function appendPattern(pattern) {
          requireNonNull(pattern, "pattern");
          this._parsePattern(pattern);
          return this;
        };
        _proto.appendZoneText = function appendZoneText() {
          throw new IllegalArgumentException("Pattern using (localized) text not implemented, use @js-joda/locale plugin!");
        };
        _proto.appendText = function appendText() {
          throw new IllegalArgumentException("Pattern using (localized) text not implemented, use @js-joda/locale plugin!");
        };
        _proto.appendLocalizedOffset = function appendLocalizedOffset() {
          throw new IllegalArgumentException("Pattern using (localized) text not implemented, use @js-joda/locale plugin!");
        };
        _proto.appendWeekField = function appendWeekField() {
          throw new IllegalArgumentException("Pattern using (localized) text not implemented, use @js-joda/locale plugin!");
        };
        _proto._parsePattern = function _parsePattern(pattern) {
          var FIELD_MAP = {
            "G": ChronoField.ERA,
            "y": ChronoField.YEAR_OF_ERA,
            "u": ChronoField.YEAR,
            "Q": IsoFields.QUARTER_OF_YEAR,
            "q": IsoFields.QUARTER_OF_YEAR,
            "M": ChronoField.MONTH_OF_YEAR,
            "L": ChronoField.MONTH_OF_YEAR,
            "D": ChronoField.DAY_OF_YEAR,
            "d": ChronoField.DAY_OF_MONTH,
            "F": ChronoField.ALIGNED_DAY_OF_WEEK_IN_MONTH,
            "E": ChronoField.DAY_OF_WEEK,
            "c": ChronoField.DAY_OF_WEEK,
            "e": ChronoField.DAY_OF_WEEK,
            "a": ChronoField.AMPM_OF_DAY,
            "H": ChronoField.HOUR_OF_DAY,
            "k": ChronoField.CLOCK_HOUR_OF_DAY,
            "K": ChronoField.HOUR_OF_AMPM,
            "h": ChronoField.CLOCK_HOUR_OF_AMPM,
            "m": ChronoField.MINUTE_OF_HOUR,
            "s": ChronoField.SECOND_OF_MINUTE,
            "S": ChronoField.NANO_OF_SECOND,
            "A": ChronoField.MILLI_OF_DAY,
            "n": ChronoField.NANO_OF_SECOND,
            "N": ChronoField.NANO_OF_DAY
          };
          for (var pos = 0; pos < pattern.length; pos++) {
            var cur = pattern.charAt(pos);
            if (cur >= "A" && cur <= "Z" || cur >= "a" && cur <= "z") {
              var start = pos++;
              for (; pos < pattern.length && pattern.charAt(pos) === cur; pos++)
                ;
              var count = pos - start;
              if (cur === "p") {
                var pad = 0;
                if (pos < pattern.length) {
                  cur = pattern.charAt(pos);
                  if (cur >= "A" && cur <= "Z" || cur >= "a" && cur <= "z") {
                    pad = count;
                    start = pos++;
                    for (; pos < pattern.length && pattern.charAt(pos) === cur; pos++)
                      ;
                    count = pos - start;
                  }
                }
                if (pad === 0) {
                  throw new IllegalArgumentException("Pad letter 'p' must be followed by valid pad pattern: " + pattern);
                }
                this.padNext(pad);
              }
              var field = FIELD_MAP[cur];
              if (field != null) {
                this._parseField(cur, count, field);
              } else if (cur === "z") {
                if (count > 4) {
                  throw new IllegalArgumentException("Too many pattern letters: " + cur);
                } else if (count === 4) {
                  this.appendZoneText(TextStyle.FULL);
                } else {
                  this.appendZoneText(TextStyle.SHORT);
                }
              } else if (cur === "V") {
                if (count !== 2) {
                  throw new IllegalArgumentException("Pattern letter count must be 2: " + cur);
                }
                this.appendZoneId();
              } else if (cur === "Z") {
                if (count < 4) {
                  this.appendOffset("+HHMM", "+0000");
                } else if (count === 4) {
                  this.appendLocalizedOffset(TextStyle.FULL);
                } else if (count === 5) {
                  this.appendOffset("+HH:MM:ss", "Z");
                } else {
                  throw new IllegalArgumentException("Too many pattern letters: " + cur);
                }
              } else if (cur === "O") {
                if (count === 1) {
                  this.appendLocalizedOffset(TextStyle.SHORT);
                } else if (count === 4) {
                  this.appendLocalizedOffset(TextStyle.FULL);
                } else {
                  throw new IllegalArgumentException("Pattern letter count must be 1 or 4: " + cur);
                }
              } else if (cur === "X") {
                if (count > 5) {
                  throw new IllegalArgumentException("Too many pattern letters: " + cur);
                }
                this.appendOffset(OffsetIdPrinterParser.PATTERNS[count + (count === 1 ? 0 : 1)], "Z");
              } else if (cur === "x") {
                if (count > 5) {
                  throw new IllegalArgumentException("Too many pattern letters: " + cur);
                }
                var zero = count === 1 ? "+00" : count % 2 === 0 ? "+0000" : "+00:00";
                this.appendOffset(OffsetIdPrinterParser.PATTERNS[count + (count === 1 ? 0 : 1)], zero);
              } else if (cur === "W") {
                if (count > 1) {
                  throw new IllegalArgumentException("Too many pattern letters: " + cur);
                }
                this.appendWeekField("W", count);
              } else if (cur === "w") {
                if (count > 2) {
                  throw new IllegalArgumentException("Too many pattern letters: " + cur);
                }
                this.appendWeekField("w", count);
              } else if (cur === "Y") {
                this.appendWeekField("Y", count);
              } else {
                throw new IllegalArgumentException("Unknown pattern letter: " + cur);
              }
              pos--;
            } else if (cur === "'") {
              var _start = pos++;
              for (; pos < pattern.length; pos++) {
                if (pattern.charAt(pos) === "'") {
                  if (pos + 1 < pattern.length && pattern.charAt(pos + 1) === "'") {
                    pos++;
                  } else {
                    break;
                  }
                }
              }
              if (pos >= pattern.length) {
                throw new IllegalArgumentException("Pattern ends with an incomplete string literal: " + pattern);
              }
              var str = pattern.substring(_start + 1, pos);
              if (str.length === 0) {
                this.appendLiteral("'");
              } else {
                this.appendLiteral(str.replace("''", "'"));
              }
            } else if (cur === "[") {
              this.optionalStart();
            } else if (cur === "]") {
              if (this._active._parent === null) {
                throw new IllegalArgumentException("Pattern invalid as it contains ] without previous [");
              }
              this.optionalEnd();
            } else if (cur === "{" || cur === "}" || cur === "#") {
              throw new IllegalArgumentException("Pattern includes reserved character: '" + cur + "'");
            } else {
              this.appendLiteral(cur);
            }
          }
        };
        _proto._parseField = function _parseField(cur, count, field) {
          switch (cur) {
            case "u":
            case "y":
              if (count === 2) {
                this.appendValueReduced(field, 2, 2, ReducedPrinterParser.BASE_DATE);
              } else if (count < 4) {
                this.appendValue(field, count, MAX_WIDTH, SignStyle.NORMAL);
              } else {
                this.appendValue(field, count, MAX_WIDTH, SignStyle.EXCEEDS_PAD);
              }
              break;
            case "M":
            case "Q":
              switch (count) {
                case 1:
                  this.appendValue(field);
                  break;
                case 2:
                  this.appendValue(field, 2);
                  break;
                case 3:
                  this.appendText(field, TextStyle.SHORT);
                  break;
                case 4:
                  this.appendText(field, TextStyle.FULL);
                  break;
                case 5:
                  this.appendText(field, TextStyle.NARROW);
                  break;
                default:
                  throw new IllegalArgumentException("Too many pattern letters: " + cur);
              }
              break;
            case "L":
            case "q":
              switch (count) {
                case 1:
                  this.appendValue(field);
                  break;
                case 2:
                  this.appendValue(field, 2);
                  break;
                case 3:
                  this.appendText(field, TextStyle.SHORT_STANDALONE);
                  break;
                case 4:
                  this.appendText(field, TextStyle.FULL_STANDALONE);
                  break;
                case 5:
                  this.appendText(field, TextStyle.NARROW_STANDALONE);
                  break;
                default:
                  throw new IllegalArgumentException("Too many pattern letters: " + cur);
              }
              break;
            case "e":
              switch (count) {
                case 1:
                case 2:
                  this.appendWeekField("e", count);
                  break;
                case 3:
                  this.appendText(field, TextStyle.SHORT);
                  break;
                case 4:
                  this.appendText(field, TextStyle.FULL);
                  break;
                case 5:
                  this.appendText(field, TextStyle.NARROW);
                  break;
                default:
                  throw new IllegalArgumentException("Too many pattern letters: " + cur);
              }
              break;
            case "c":
              switch (count) {
                case 1:
                  this.appendWeekField("c", count);
                  break;
                case 2:
                  throw new IllegalArgumentException("Invalid number of pattern letters: " + cur);
                case 3:
                  this.appendText(field, TextStyle.SHORT_STANDALONE);
                  break;
                case 4:
                  this.appendText(field, TextStyle.FULL_STANDALONE);
                  break;
                case 5:
                  this.appendText(field, TextStyle.NARROW_STANDALONE);
                  break;
                default:
                  throw new IllegalArgumentException("Too many pattern letters: " + cur);
              }
              break;
            case "a":
              if (count === 1) {
                this.appendText(field, TextStyle.SHORT);
              } else {
                throw new IllegalArgumentException("Too many pattern letters: " + cur);
              }
              break;
            case "E":
            case "G":
              switch (count) {
                case 1:
                case 2:
                case 3:
                  this.appendText(field, TextStyle.SHORT);
                  break;
                case 4:
                  this.appendText(field, TextStyle.FULL);
                  break;
                case 5:
                  this.appendText(field, TextStyle.NARROW);
                  break;
                default:
                  throw new IllegalArgumentException("Too many pattern letters: " + cur);
              }
              break;
            case "S":
              this.appendFraction(ChronoField.NANO_OF_SECOND, count, count, false);
              break;
            case "F":
              if (count === 1) {
                this.appendValue(field);
              } else {
                throw new IllegalArgumentException("Too many pattern letters: " + cur);
              }
              break;
            case "d":
            case "h":
            case "H":
            case "k":
            case "K":
            case "m":
            case "s":
              if (count === 1) {
                this.appendValue(field);
              } else if (count === 2) {
                this.appendValue(field, count);
              } else {
                throw new IllegalArgumentException("Too many pattern letters: " + cur);
              }
              break;
            case "D":
              if (count === 1) {
                this.appendValue(field);
              } else if (count <= 3) {
                this.appendValue(field, count);
              } else {
                throw new IllegalArgumentException("Too many pattern letters: " + cur);
              }
              break;
            default:
              if (count === 1) {
                this.appendValue(field);
              } else {
                this.appendValue(field, count);
              }
              break;
          }
        };
        _proto.padNext = function padNext() {
          if (arguments.length === 1) {
            return this._padNext1.apply(this, arguments);
          } else {
            return this._padNext2.apply(this, arguments);
          }
        };
        _proto._padNext1 = function _padNext1(padWidth) {
          return this._padNext2(padWidth, " ");
        };
        _proto._padNext2 = function _padNext2(padWidth, padChar) {
          if (padWidth < 1) {
            throw new IllegalArgumentException("The pad width must be at least one but was " + padWidth);
          }
          this._active._padNextWidth = padWidth;
          this._active._padNextChar = padChar;
          this._active._valueParserIndex = -1;
          return this;
        };
        _proto.optionalStart = function optionalStart() {
          this._active._valueParserIndex = -1;
          this._active = DateTimeFormatterBuilder2._of(this._active, true);
          return this;
        };
        _proto.optionalEnd = function optionalEnd() {
          if (this._active._parent == null) {
            throw new IllegalStateException("Cannot call optionalEnd() as there was no previous call to optionalStart()");
          }
          if (this._active._printerParsers.length > 0) {
            var cpp = new CompositePrinterParser(this._active._printerParsers, this._active._optional);
            this._active = this._active._parent;
            this._appendInternal(cpp);
          } else {
            this._active = this._active._parent;
          }
          return this;
        };
        _proto._appendInternal = function _appendInternal(pp) {
          assert3(pp != null);
          if (this._active._padNextWidth > 0) {
            if (pp != null) {
              pp = new PadPrinterParserDecorator(pp, this._active._padNextWidth, this._active._padNextChar);
            }
            this._active._padNextWidth = 0;
            this._active._padNextChar = 0;
          }
          this._active._printerParsers.push(pp);
          this._active._valueParserIndex = -1;
          return this._active._printerParsers.length - 1;
        };
        _proto.appendLiteral = function appendLiteral(literal) {
          assert3(literal != null);
          if (literal.length > 0) {
            if (literal.length === 1) {
              this._appendInternalPrinterParser(new CharLiteralPrinterParser(literal.charAt(0)));
            } else {
              this._appendInternalPrinterParser(new StringLiteralPrinterParser(literal));
            }
          }
          return this;
        };
        _proto._appendInternalPrinterParser = function _appendInternalPrinterParser(pp) {
          assert3(pp != null);
          if (this._active._padNextWidth > 0) {
            if (pp != null) {
              pp = new PadPrinterParserDecorator(pp, this._active._padNextWidth, this._active._padNextChar);
            }
            this._active._padNextWidth = 0;
            this._active._padNextChar = 0;
          }
          this._active._printerParsers.push(pp);
          this._active._valueParserIndex = -1;
          return this._active._printerParsers.length - 1;
        };
        _proto.append = function append(formatter) {
          requireNonNull(formatter, "formatter");
          this._appendInternal(formatter._toPrinterParser(false));
          return this;
        };
        _proto.toFormatter = function toFormatter(resolverStyle) {
          if (resolverStyle === void 0) {
            resolverStyle = ResolverStyle.SMART;
          }
          while (this._active._parent != null) {
            this.optionalEnd();
          }
          var pp = new CompositePrinterParser(this._printerParsers, false);
          return new DateTimeFormatter(pp, null, DecimalStyle.STANDARD, resolverStyle, null, null, null);
        };
        return DateTimeFormatterBuilder2;
      }();
      var SECONDS_PER_10000_YEARS = 146097 * 25 * 86400;
      var SECONDS_0000_TO_1970 = (146097 * 5 - (30 * 365 + 7)) * 86400;
      var InstantPrinterParser = function() {
        function InstantPrinterParser2(fractionalDigits) {
          this.fractionalDigits = fractionalDigits;
        }
        var _proto2 = InstantPrinterParser2.prototype;
        _proto2.print = function print(context, buf) {
          var inSecs = context.getValue(ChronoField.INSTANT_SECONDS);
          var inNanos = 0;
          if (context.temporal().isSupported(ChronoField.NANO_OF_SECOND)) {
            inNanos = context.temporal().getLong(ChronoField.NANO_OF_SECOND);
          }
          if (inSecs == null) {
            return false;
          }
          var inSec = inSecs;
          var inNano = ChronoField.NANO_OF_SECOND.checkValidIntValue(inNanos);
          if (inSec >= -SECONDS_0000_TO_1970) {
            var zeroSecs = inSec - SECONDS_PER_10000_YEARS + SECONDS_0000_TO_1970;
            var hi = MathUtil.floorDiv(zeroSecs, SECONDS_PER_10000_YEARS) + 1;
            var lo = MathUtil.floorMod(zeroSecs, SECONDS_PER_10000_YEARS);
            var ldt = LocalDateTime.ofEpochSecond(lo - SECONDS_0000_TO_1970, 0, ZoneOffset.UTC);
            if (hi > 0) {
              buf.append("+").append(hi);
            }
            buf.append(ldt.toString());
            if (ldt.second() === 0) {
              buf.append(":00");
            }
          } else {
            var _zeroSecs = inSec + SECONDS_0000_TO_1970;
            var _hi = MathUtil.intDiv(_zeroSecs, SECONDS_PER_10000_YEARS);
            var _lo = MathUtil.intMod(_zeroSecs, SECONDS_PER_10000_YEARS);
            var _ldt = LocalDateTime.ofEpochSecond(_lo - SECONDS_0000_TO_1970, 0, ZoneOffset.UTC);
            var pos = buf.length();
            buf.append(_ldt.toString());
            if (_ldt.second() === 0) {
              buf.append(":00");
            }
            if (_hi < 0) {
              if (_ldt.year() === -1e4) {
                buf.replace(pos, pos + 2, "" + (_hi - 1));
              } else if (_lo === 0) {
                buf.insert(pos, _hi);
              } else {
                buf.insert(pos + 1, Math.abs(_hi));
              }
            }
          }
          if (this.fractionalDigits === -2) {
            if (inNano !== 0) {
              buf.append(".");
              if (MathUtil.intMod(inNano, 1e6) === 0) {
                buf.append(("" + (MathUtil.intDiv(inNano, 1e6) + 1e3)).substring(1));
              } else if (MathUtil.intMod(inNano, 1e3) === 0) {
                buf.append(("" + (MathUtil.intDiv(inNano, 1e3) + 1e6)).substring(1));
              } else {
                buf.append(("" + (inNano + 1e9)).substring(1));
              }
            }
          } else if (this.fractionalDigits > 0 || this.fractionalDigits === -1 && inNano > 0) {
            buf.append(".");
            var div = 1e8;
            for (var i = 0; this.fractionalDigits === -1 && inNano > 0 || i < this.fractionalDigits; i++) {
              var digit = MathUtil.intDiv(inNano, div);
              buf.append(digit);
              inNano = inNano - digit * div;
              div = MathUtil.intDiv(div, 10);
            }
          }
          buf.append("Z");
          return true;
        };
        _proto2.parse = function parse(context, text, position) {
          var newContext = context.copy();
          var minDigits = this.fractionalDigits < 0 ? 0 : this.fractionalDigits;
          var maxDigits = this.fractionalDigits < 0 ? 9 : this.fractionalDigits;
          var parser = new DateTimeFormatterBuilder().append(DateTimeFormatter.ISO_LOCAL_DATE).appendLiteral("T").appendValue(ChronoField.HOUR_OF_DAY, 2).appendLiteral(":").appendValue(ChronoField.MINUTE_OF_HOUR, 2).appendLiteral(":").appendValue(ChronoField.SECOND_OF_MINUTE, 2).appendFraction(ChronoField.NANO_OF_SECOND, minDigits, maxDigits, true).appendLiteral("Z").toFormatter()._toPrinterParser(false);
          var pos = parser.parse(newContext, text, position);
          if (pos < 0) {
            return pos;
          }
          var yearParsed = newContext.getParsed(ChronoField.YEAR);
          var month = newContext.getParsed(ChronoField.MONTH_OF_YEAR);
          var day = newContext.getParsed(ChronoField.DAY_OF_MONTH);
          var hour = newContext.getParsed(ChronoField.HOUR_OF_DAY);
          var min = newContext.getParsed(ChronoField.MINUTE_OF_HOUR);
          var secVal = newContext.getParsed(ChronoField.SECOND_OF_MINUTE);
          var nanoVal = newContext.getParsed(ChronoField.NANO_OF_SECOND);
          var sec = secVal != null ? secVal : 0;
          var nano = nanoVal != null ? nanoVal : 0;
          var year = MathUtil.intMod(yearParsed, 1e4);
          var days = 0;
          if (hour === 24 && min === 0 && sec === 0 && nano === 0) {
            hour = 0;
            days = 1;
          } else if (hour === 23 && min === 59 && sec === 60) {
            context.setParsedLeapSecond();
            sec = 59;
          }
          var instantSecs;
          try {
            var ldt = LocalDateTime.of(year, month, day, hour, min, sec, 0).plusDays(days);
            instantSecs = ldt.toEpochSecond(ZoneOffset.UTC);
            instantSecs += MathUtil.safeMultiply(MathUtil.intDiv(yearParsed, 1e4), SECONDS_PER_10000_YEARS);
          } catch (ex) {
            return ~position;
          }
          var successPos = pos;
          successPos = context.setParsedField(ChronoField.INSTANT_SECONDS, instantSecs, position, successPos);
          return context.setParsedField(ChronoField.NANO_OF_SECOND, nano, position, successPos);
        };
        _proto2.toString = function toString() {
          return "Instant()";
        };
        return InstantPrinterParser2;
      }();
      var DefaultingParser = function() {
        function DefaultingParser2(field, value) {
          this._field = field;
          this._value = value;
        }
        var _proto3 = DefaultingParser2.prototype;
        _proto3.print = function print() {
          return true;
        };
        _proto3.parse = function parse(context, text, position) {
          if (context.getParsed(this._field) == null) {
            context.setParsedField(this._field, this._value, position, position);
          }
          return position;
        };
        return DefaultingParser2;
      }();
      function _init$e() {
        ReducedPrinterParser.BASE_DATE = LocalDate2.of(2e3, 1, 1);
        DateTimeFormatterBuilder.CompositePrinterParser = CompositePrinterParser;
        DateTimeFormatterBuilder.PadPrinterParserDecorator = PadPrinterParserDecorator;
        DateTimeFormatterBuilder.SettingsParser = SettingsParser;
        DateTimeFormatterBuilder.CharLiteralPrinterParser = StringLiteralPrinterParser;
        DateTimeFormatterBuilder.StringLiteralPrinterParser = StringLiteralPrinterParser;
        DateTimeFormatterBuilder.CharLiteralPrinterParser = CharLiteralPrinterParser;
        DateTimeFormatterBuilder.NumberPrinterParser = NumberPrinterParser;
        DateTimeFormatterBuilder.ReducedPrinterParser = ReducedPrinterParser;
        DateTimeFormatterBuilder.FractionPrinterParser = FractionPrinterParser;
        DateTimeFormatterBuilder.OffsetIdPrinterParser = OffsetIdPrinterParser;
        DateTimeFormatterBuilder.ZoneIdPrinterParser = ZoneIdPrinterParser;
      }
      var StringBuilder = function() {
        function StringBuilder2() {
          this._str = "";
        }
        var _proto = StringBuilder2.prototype;
        _proto.append = function append(str) {
          this._str += str;
          return this;
        };
        _proto.appendChar = function appendChar(str) {
          this._str += str[0];
          return this;
        };
        _proto.insert = function insert(offset, str) {
          this._str = this._str.slice(0, offset) + str + this._str.slice(offset);
          return this;
        };
        _proto.replace = function replace(start, end, str) {
          this._str = this._str.slice(0, start) + str + this._str.slice(end);
          return this;
        };
        _proto.length = function length() {
          return this._str.length;
        };
        _proto.setLength = function setLength(length) {
          this._str = this._str.slice(0, length);
          return this;
        };
        _proto.toString = function toString() {
          return this._str;
        };
        return StringBuilder2;
      }();
      var DateTimeFormatter = function() {
        DateTimeFormatter2.parsedExcessDays = function parsedExcessDays() {
          return DateTimeFormatter2.PARSED_EXCESS_DAYS;
        };
        DateTimeFormatter2.parsedLeapSecond = function parsedLeapSecond() {
          return DateTimeFormatter2.PARSED_LEAP_SECOND;
        };
        DateTimeFormatter2.ofPattern = function ofPattern(pattern) {
          return new DateTimeFormatterBuilder().appendPattern(pattern).toFormatter();
        };
        function DateTimeFormatter2(printerParser, locale, decimalStyle, resolverStyle, resolverFields, chrono, zone) {
          if (chrono === void 0) {
            chrono = IsoChronology.INSTANCE;
          }
          assert3(printerParser != null);
          assert3(decimalStyle != null);
          assert3(resolverStyle != null);
          this._printerParser = printerParser;
          this._locale = locale;
          this._decimalStyle = decimalStyle;
          this._resolverStyle = resolverStyle;
          this._resolverFields = resolverFields;
          this._chrono = chrono;
          this._zone = zone;
        }
        var _proto = DateTimeFormatter2.prototype;
        _proto.locale = function locale() {
          return this._locale;
        };
        _proto.decimalStyle = function decimalStyle() {
          return this._decimalStyle;
        };
        _proto.chronology = function chronology() {
          return this._chrono;
        };
        _proto.withChronology = function withChronology(chrono) {
          if (this._chrono != null && this._chrono.equals(chrono)) {
            return this;
          }
          return new DateTimeFormatter2(this._printerParser, this._locale, this._decimalStyle, this._resolverStyle, this._resolverFields, chrono, this._zone);
        };
        _proto.withLocale = function withLocale() {
          return this;
        };
        _proto.withResolverStyle = function withResolverStyle(resolverStyle) {
          requireNonNull(resolverStyle, "resolverStyle");
          if (resolverStyle.equals(this._resolverStyle)) {
            return this;
          }
          return new DateTimeFormatter2(this._printerParser, this._locale, this._decimalStyle, resolverStyle, this._resolverFields, this._chrono, this._zone);
        };
        _proto.format = function format(temporal) {
          var buf = new StringBuilder(32);
          this._formatTo(temporal, buf);
          return buf.toString();
        };
        _proto._formatTo = function _formatTo(temporal, appendable) {
          requireNonNull(temporal, "temporal");
          requireNonNull(appendable, "appendable");
          var context = new DateTimePrintContext(temporal, this);
          this._printerParser.print(context, appendable);
        };
        _proto.parse = function parse(text, type) {
          if (arguments.length === 1) {
            return this.parse1(text);
          } else {
            return this.parse2(text, type);
          }
        };
        _proto.parse1 = function parse1(text) {
          requireNonNull(text, "text");
          try {
            return this._parseToBuilder(text, null).resolve(this._resolverStyle, this._resolverFields);
          } catch (ex) {
            if (ex instanceof DateTimeParseException) {
              throw ex;
            } else {
              throw this._createError(text, ex);
            }
          }
        };
        _proto.parse2 = function parse2(text, type) {
          requireNonNull(text, "text");
          requireNonNull(type, "type");
          try {
            var builder = this._parseToBuilder(text, null).resolve(this._resolverStyle, this._resolverFields);
            return builder.build(type);
          } catch (ex) {
            if (ex instanceof DateTimeParseException) {
              throw ex;
            } else {
              throw this._createError(text, ex);
            }
          }
        };
        _proto._createError = function _createError(text, ex) {
          var abbr = "";
          if (text.length > 64) {
            abbr = text.substring(0, 64) + "...";
          } else {
            abbr = text;
          }
          return new DateTimeParseException("Text '" + abbr + "' could not be parsed: " + ex.message, text, 0, ex);
        };
        _proto._parseToBuilder = function _parseToBuilder(text, position) {
          var pos = position != null ? position : new ParsePosition(0);
          var result = this._parseUnresolved0(text, pos);
          if (result == null || pos.getErrorIndex() >= 0 || position == null && pos.getIndex() < text.length) {
            var abbr = "";
            if (text.length > 64) {
              abbr = text.substr(0, 64).toString() + "...";
            } else {
              abbr = text;
            }
            if (pos.getErrorIndex() >= 0) {
              throw new DateTimeParseException("Text '" + abbr + "' could not be parsed at index " + pos.getErrorIndex(), text, pos.getErrorIndex());
            } else {
              throw new DateTimeParseException("Text '" + abbr + "' could not be parsed, unparsed text found at index " + pos.getIndex(), text, pos.getIndex());
            }
          }
          return result.toBuilder();
        };
        _proto.parseUnresolved = function parseUnresolved(text, position) {
          return this._parseUnresolved0(text, position);
        };
        _proto._parseUnresolved0 = function _parseUnresolved0(text, position) {
          assert3(text != null, "text", NullPointerException);
          assert3(position != null, "position", NullPointerException);
          var context = new DateTimeParseContext(this);
          var pos = position.getIndex();
          pos = this._printerParser.parse(context, text, pos);
          if (pos < 0) {
            position.setErrorIndex(~pos);
            return null;
          }
          position.setIndex(pos);
          return context.toParsed();
        };
        _proto._toPrinterParser = function _toPrinterParser(optional) {
          return this._printerParser.withOptional(optional);
        };
        _proto.toString = function toString() {
          var pattern = this._printerParser.toString();
          return pattern.indexOf("[") === 0 ? pattern : pattern.substring(1, pattern.length - 1);
        };
        return DateTimeFormatter2;
      }();
      function _init$d() {
        DateTimeFormatter.ISO_LOCAL_DATE = new DateTimeFormatterBuilder().appendValue(ChronoField.YEAR, 4, 10, SignStyle.EXCEEDS_PAD).appendLiteral("-").appendValue(ChronoField.MONTH_OF_YEAR, 2).appendLiteral("-").appendValue(ChronoField.DAY_OF_MONTH, 2).toFormatter(ResolverStyle.STRICT).withChronology(IsoChronology.INSTANCE);
        DateTimeFormatter.ISO_LOCAL_TIME = new DateTimeFormatterBuilder().appendValue(ChronoField.HOUR_OF_DAY, 2).appendLiteral(":").appendValue(ChronoField.MINUTE_OF_HOUR, 2).optionalStart().appendLiteral(":").appendValue(ChronoField.SECOND_OF_MINUTE, 2).optionalStart().appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true).toFormatter(ResolverStyle.STRICT);
        DateTimeFormatter.ISO_LOCAL_DATE_TIME = new DateTimeFormatterBuilder().parseCaseInsensitive().append(DateTimeFormatter.ISO_LOCAL_DATE).appendLiteral("T").append(DateTimeFormatter.ISO_LOCAL_TIME).toFormatter(ResolverStyle.STRICT).withChronology(IsoChronology.INSTANCE);
        DateTimeFormatter.ISO_INSTANT = new DateTimeFormatterBuilder().parseCaseInsensitive().appendInstant().toFormatter(ResolverStyle.STRICT);
        DateTimeFormatter.ISO_OFFSET_DATE_TIME = new DateTimeFormatterBuilder().parseCaseInsensitive().append(DateTimeFormatter.ISO_LOCAL_DATE_TIME).appendOffsetId().toFormatter(ResolverStyle.STRICT).withChronology(IsoChronology.INSTANCE);
        DateTimeFormatter.ISO_ZONED_DATE_TIME = new DateTimeFormatterBuilder().append(DateTimeFormatter.ISO_OFFSET_DATE_TIME).optionalStart().appendLiteral("[").parseCaseSensitive().appendZoneId().appendLiteral("]").toFormatter(ResolverStyle.STRICT).withChronology(IsoChronology.INSTANCE);
        DateTimeFormatter.BASIC_ISO_DATE = new DateTimeFormatterBuilder().appendValue(ChronoField.YEAR, 4, 10, SignStyle.EXCEEDS_PAD).appendValue(ChronoField.MONTH_OF_YEAR, 2).appendValue(ChronoField.DAY_OF_MONTH, 2).toFormatter(ResolverStyle.STRICT).withChronology(IsoChronology.INSTANCE);
        DateTimeFormatter.ISO_OFFSET_DATE = new DateTimeFormatterBuilder().parseCaseInsensitive().append(DateTimeFormatter.ISO_LOCAL_DATE).appendOffsetId().toFormatter(ResolverStyle.STRICT).withChronology(IsoChronology.INSTANCE);
        DateTimeFormatter.ISO_OFFSET_TIME = new DateTimeFormatterBuilder().parseCaseInsensitive().append(DateTimeFormatter.ISO_LOCAL_TIME).appendOffsetId().toFormatter(ResolverStyle.STRICT).withChronology(IsoChronology.INSTANCE);
        DateTimeFormatter.ISO_ORDINAL_DATE = new DateTimeFormatterBuilder().appendValue(ChronoField.YEAR, 4, 10, SignStyle.EXCEEDS_PAD).appendLiteral("-").appendValue(ChronoField.DAY_OF_YEAR).toFormatter(ResolverStyle.STRICT);
        DateTimeFormatter.ISO_WEEK_DATE = new DateTimeFormatterBuilder().appendValue(ChronoField.YEAR, 4, 10, SignStyle.EXCEEDS_PAD).appendLiteral("-W").appendValue(ChronoField.ALIGNED_WEEK_OF_YEAR).appendLiteral("-").appendValue(ChronoField.DAY_OF_WEEK).toFormatter(ResolverStyle.STRICT);
        DateTimeFormatter.ISO_DATE = new DateTimeFormatterBuilder().parseCaseInsensitive().append(DateTimeFormatter.ISO_LOCAL_DATE).optionalStart().appendOffsetId().optionalEnd().toFormatter(ResolverStyle.STRICT).withChronology(IsoChronology.INSTANCE);
        DateTimeFormatter.ISO_TIME = new DateTimeFormatterBuilder().parseCaseInsensitive().append(DateTimeFormatter.ISO_LOCAL_TIME).optionalStart().appendOffsetId().optionalEnd().toFormatter(ResolverStyle.STRICT);
        DateTimeFormatter.ISO_DATE_TIME = new DateTimeFormatterBuilder().append(DateTimeFormatter.ISO_LOCAL_DATE_TIME).optionalStart().appendOffsetId().optionalEnd().toFormatter(ResolverStyle.STRICT).withChronology(IsoChronology.INSTANCE);
        DateTimeFormatter.PARSED_EXCESS_DAYS = createTemporalQuery("PARSED_EXCESS_DAYS", function(temporal) {
          if (temporal instanceof DateTimeBuilder) {
            return temporal.excessDays;
          } else {
            return Period.ZERO;
          }
        });
        DateTimeFormatter.PARSED_LEAP_SECOND = createTemporalQuery("PARSED_LEAP_SECOND", function(temporal) {
          if (temporal instanceof DateTimeBuilder) {
            return temporal.leapSecond;
          } else {
            return false;
          }
        });
      }
      var MonthDay = function(_TemporalAccessor) {
        _inheritsLoose(MonthDay2, _TemporalAccessor);
        MonthDay2.now = function now(zoneIdOrClock) {
          if (arguments.length === 0) {
            return MonthDay2.now0();
          } else if (arguments.length === 1 && zoneIdOrClock instanceof ZoneId2) {
            return MonthDay2.nowZoneId(zoneIdOrClock);
          } else {
            return MonthDay2.nowClock(zoneIdOrClock);
          }
        };
        MonthDay2.now0 = function now0() {
          return this.nowClock(Clock.systemDefaultZone());
        };
        MonthDay2.nowZoneId = function nowZoneId(zone) {
          requireNonNull(zone, "zone");
          return this.nowClock(Clock.system(zone));
        };
        MonthDay2.nowClock = function nowClock(clock) {
          requireNonNull(clock, "clock");
          var now = LocalDate2.now(clock);
          return MonthDay2.of(now.month(), now.dayOfMonth());
        };
        MonthDay2.of = function of(monthOrNumber, number) {
          if (arguments.length === 2 && monthOrNumber instanceof Month) {
            return MonthDay2.ofMonthNumber(monthOrNumber, number);
          } else {
            return MonthDay2.ofNumberNumber(monthOrNumber, number);
          }
        };
        MonthDay2.ofMonthNumber = function ofMonthNumber(month, dayOfMonth) {
          requireNonNull(month, "month");
          ChronoField.DAY_OF_MONTH.checkValidValue(dayOfMonth);
          if (dayOfMonth > month.maxLength()) {
            throw new DateTimeException("Illegal value for DayOfMonth field, value " + dayOfMonth + " is not valid for month " + month.toString());
          }
          return new MonthDay2(month.value(), dayOfMonth);
        };
        MonthDay2.ofNumberNumber = function ofNumberNumber(month, dayOfMonth) {
          requireNonNull(month, "month");
          requireNonNull(dayOfMonth, "dayOfMonth");
          return MonthDay2.of(Month.of(month), dayOfMonth);
        };
        MonthDay2.from = function from(temporal) {
          requireNonNull(temporal, "temporal");
          requireInstance(temporal, TemporalAccessor, "temporal");
          if (temporal instanceof MonthDay2) {
            return temporal;
          }
          try {
            return MonthDay2.of(temporal.get(ChronoField.MONTH_OF_YEAR), temporal.get(ChronoField.DAY_OF_MONTH));
          } catch (ex) {
            throw new DateTimeException("Unable to obtain MonthDay from TemporalAccessor: " + temporal + ", type " + (temporal && temporal.constructor != null ? temporal.constructor.name : ""));
          }
        };
        MonthDay2.parse = function parse(text, formatter) {
          if (arguments.length === 1) {
            return MonthDay2.parseString(text);
          } else {
            return MonthDay2.parseStringFormatter(text, formatter);
          }
        };
        MonthDay2.parseString = function parseString(text) {
          return MonthDay2.parseStringFormatter(text, PARSER$2);
        };
        MonthDay2.parseStringFormatter = function parseStringFormatter(text, formatter) {
          requireNonNull(text, "text");
          requireNonNull(formatter, "formatter");
          requireInstance(formatter, DateTimeFormatter, "formatter");
          return formatter.parse(text, MonthDay2.FROM);
        };
        function MonthDay2(month, dayOfMonth) {
          var _this;
          _this = _TemporalAccessor.call(this) || this;
          _this._month = MathUtil.safeToInt(month);
          _this._day = MathUtil.safeToInt(dayOfMonth);
          return _this;
        }
        var _proto = MonthDay2.prototype;
        _proto.monthValue = function monthValue() {
          return this._month;
        };
        _proto.month = function month() {
          return Month.of(this._month);
        };
        _proto.dayOfMonth = function dayOfMonth() {
          return this._day;
        };
        _proto.isSupported = function isSupported(field) {
          if (field instanceof ChronoField) {
            return field === ChronoField.MONTH_OF_YEAR || field === ChronoField.DAY_OF_MONTH;
          }
          return field != null && field.isSupportedBy(this);
        };
        _proto.range = function range(field) {
          if (field === ChronoField.MONTH_OF_YEAR) {
            return field.range();
          } else if (field === ChronoField.DAY_OF_MONTH) {
            return ValueRange.of(1, this.month().minLength(), this.month().maxLength());
          }
          return _TemporalAccessor.prototype.range.call(this, field);
        };
        _proto.get = function get(field) {
          return this.range(field).checkValidIntValue(this.getLong(field), field);
        };
        _proto.getLong = function getLong(field) {
          requireNonNull(field, "field");
          if (field instanceof ChronoField) {
            switch (field) {
              case ChronoField.DAY_OF_MONTH:
                return this._day;
              case ChronoField.MONTH_OF_YEAR:
                return this._month;
            }
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.getFrom(this);
        };
        _proto.isValidYear = function isValidYear(year) {
          return (this._day === 29 && this._month === 2 && Year.isLeap(year) === false) === false;
        };
        _proto.withMonth = function withMonth(month) {
          return this.with(Month.of(month));
        };
        _proto.with = function _with(month) {
          requireNonNull(month, "month");
          if (month.value() === this._month) {
            return this;
          }
          var day = Math.min(this._day, month.maxLength());
          return new MonthDay2(month.value(), day);
        };
        _proto.withDayOfMonth = function withDayOfMonth(dayOfMonth) {
          if (dayOfMonth === this._day) {
            return this;
          }
          return MonthDay2.of(this._month, dayOfMonth);
        };
        _proto.query = function query(_query) {
          requireNonNull(_query, "query");
          requireInstance(_query, TemporalQuery, "query");
          if (_query === TemporalQueries.chronology()) {
            return IsoChronology.INSTANCE;
          }
          return _TemporalAccessor.prototype.query.call(this, _query);
        };
        _proto.adjustInto = function adjustInto(temporal) {
          requireNonNull(temporal, "temporal");
          temporal = temporal.with(ChronoField.MONTH_OF_YEAR, this._month);
          return temporal.with(ChronoField.DAY_OF_MONTH, Math.min(temporal.range(ChronoField.DAY_OF_MONTH).maximum(), this._day));
        };
        _proto.atYear = function atYear(year) {
          return LocalDate2.of(year, this._month, this.isValidYear(year) ? this._day : 28);
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          requireInstance(other, MonthDay2, "other");
          var cmp = this._month - other.monthValue();
          if (cmp === 0) {
            cmp = this._day - other.dayOfMonth();
          }
          return cmp;
        };
        _proto.isAfter = function isAfter(other) {
          requireNonNull(other, "other");
          requireInstance(other, MonthDay2, "other");
          return this.compareTo(other) > 0;
        };
        _proto.isBefore = function isBefore(other) {
          requireNonNull(other, "other");
          requireInstance(other, MonthDay2, "other");
          return this.compareTo(other) < 0;
        };
        _proto.equals = function equals(obj) {
          if (this === obj) {
            return true;
          }
          if (obj instanceof MonthDay2) {
            var other = obj;
            return this.monthValue() === other.monthValue() && this.dayOfMonth() === other.dayOfMonth();
          }
          return false;
        };
        _proto.toString = function toString() {
          return "--" + (this._month < 10 ? "0" : "") + this._month + (this._day < 10 ? "-0" : "-") + this._day;
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        _proto.format = function format(formatter) {
          requireNonNull(formatter, "formatter");
          requireInstance(formatter, DateTimeFormatter, "formatter");
          return formatter.format(this);
        };
        return MonthDay2;
      }(TemporalAccessor);
      var PARSER$2;
      function _init$c() {
        PARSER$2 = new DateTimeFormatterBuilder().appendLiteral("--").appendValue(ChronoField.MONTH_OF_YEAR, 2).appendLiteral("-").appendValue(ChronoField.DAY_OF_MONTH, 2).toFormatter();
        MonthDay.FROM = createTemporalQuery("MonthDay.FROM", function(temporal) {
          return MonthDay.from(temporal);
        });
      }
      var YearMonth = function(_Temporal) {
        _inheritsLoose(YearMonth2, _Temporal);
        YearMonth2.now = function now(zoneIdOrClock) {
          if (arguments.length === 0) {
            return YearMonth2.now0();
          } else if (arguments.length === 1 && zoneIdOrClock instanceof ZoneId2) {
            return YearMonth2.nowZoneId(zoneIdOrClock);
          } else {
            return YearMonth2.nowClock(zoneIdOrClock);
          }
        };
        YearMonth2.now0 = function now0() {
          return YearMonth2.nowClock(Clock.systemDefaultZone());
        };
        YearMonth2.nowZoneId = function nowZoneId(zone) {
          return YearMonth2.nowClock(Clock.system(zone));
        };
        YearMonth2.nowClock = function nowClock(clock) {
          var now = LocalDate2.now(clock);
          return YearMonth2.of(now.year(), now.month());
        };
        YearMonth2.of = function of(year, monthOrNumber) {
          if (arguments.length === 2 && monthOrNumber instanceof Month) {
            return YearMonth2.ofNumberMonth(year, monthOrNumber);
          } else {
            return YearMonth2.ofNumberNumber(year, monthOrNumber);
          }
        };
        YearMonth2.ofNumberMonth = function ofNumberMonth(year, month) {
          requireNonNull(month, "month");
          requireInstance(month, Month, "month");
          return YearMonth2.ofNumberNumber(year, month.value());
        };
        YearMonth2.ofNumberNumber = function ofNumberNumber(year, month) {
          requireNonNull(year, "year");
          requireNonNull(month, "month");
          ChronoField.YEAR.checkValidValue(year);
          ChronoField.MONTH_OF_YEAR.checkValidValue(month);
          return new YearMonth2(year, month);
        };
        YearMonth2.from = function from(temporal) {
          requireNonNull(temporal, "temporal");
          if (temporal instanceof YearMonth2) {
            return temporal;
          }
          try {
            return YearMonth2.of(temporal.get(ChronoField.YEAR), temporal.get(ChronoField.MONTH_OF_YEAR));
          } catch (ex) {
            throw new DateTimeException("Unable to obtain YearMonth from TemporalAccessor: " + temporal + ", type " + (temporal && temporal.constructor != null ? temporal.constructor.name : ""));
          }
        };
        YearMonth2.parse = function parse(text, formatter) {
          if (arguments.length === 1) {
            return YearMonth2.parseString(text);
          } else {
            return YearMonth2.parseStringFormatter(text, formatter);
          }
        };
        YearMonth2.parseString = function parseString(text) {
          return YearMonth2.parseStringFormatter(text, PARSER$1);
        };
        YearMonth2.parseStringFormatter = function parseStringFormatter(text, formatter) {
          requireNonNull(formatter, "formatter");
          return formatter.parse(text, YearMonth2.FROM);
        };
        function YearMonth2(year, month) {
          var _this;
          _this = _Temporal.call(this) || this;
          _this._year = MathUtil.safeToInt(year);
          _this._month = MathUtil.safeToInt(month);
          return _this;
        }
        var _proto = YearMonth2.prototype;
        _proto.isSupported = function isSupported(fieldOrUnit) {
          if (arguments.length === 1 && fieldOrUnit instanceof TemporalField) {
            return this.isSupportedField(fieldOrUnit);
          } else {
            return this.isSupportedUnit(fieldOrUnit);
          }
        };
        _proto.isSupportedField = function isSupportedField(field) {
          if (field instanceof ChronoField) {
            return field === ChronoField.YEAR || field === ChronoField.MONTH_OF_YEAR || field === ChronoField.PROLEPTIC_MONTH || field === ChronoField.YEAR_OF_ERA || field === ChronoField.ERA;
          }
          return field != null && field.isSupportedBy(this);
        };
        _proto.isSupportedUnit = function isSupportedUnit(unit) {
          if (unit instanceof ChronoUnit) {
            return unit === ChronoUnit.MONTHS || unit === ChronoUnit.YEARS || unit === ChronoUnit.DECADES || unit === ChronoUnit.CENTURIES || unit === ChronoUnit.MILLENNIA || unit === ChronoUnit.ERAS;
          }
          return unit != null && unit.isSupportedBy(this);
        };
        _proto.range = function range(field) {
          if (field === ChronoField.YEAR_OF_ERA) {
            return this.year() <= 0 ? ValueRange.of(1, Year.MAX_VALUE + 1) : ValueRange.of(1, Year.MAX_VALUE);
          }
          return _Temporal.prototype.range.call(this, field);
        };
        _proto.get = function get(field) {
          requireNonNull(field, "field");
          requireInstance(field, TemporalField, "field");
          return this.range(field).checkValidIntValue(this.getLong(field), field);
        };
        _proto.getLong = function getLong(field) {
          requireNonNull(field, "field");
          requireInstance(field, TemporalField, "field");
          if (field instanceof ChronoField) {
            switch (field) {
              case ChronoField.MONTH_OF_YEAR:
                return this._month;
              case ChronoField.PROLEPTIC_MONTH:
                return this._getProlepticMonth();
              case ChronoField.YEAR_OF_ERA:
                return this._year < 1 ? 1 - this._year : this._year;
              case ChronoField.YEAR:
                return this._year;
              case ChronoField.ERA:
                return this._year < 1 ? 0 : 1;
            }
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.getFrom(this);
        };
        _proto._getProlepticMonth = function _getProlepticMonth() {
          return MathUtil.safeAdd(MathUtil.safeMultiply(this._year, 12), this._month - 1);
        };
        _proto.year = function year() {
          return this._year;
        };
        _proto.monthValue = function monthValue() {
          return this._month;
        };
        _proto.month = function month() {
          return Month.of(this._month);
        };
        _proto.isLeapYear = function isLeapYear() {
          return IsoChronology.isLeapYear(this._year);
        };
        _proto.isValidDay = function isValidDay(dayOfMonth) {
          return dayOfMonth >= 1 && dayOfMonth <= this.lengthOfMonth();
        };
        _proto.lengthOfMonth = function lengthOfMonth() {
          return this.month().length(this.isLeapYear());
        };
        _proto.lengthOfYear = function lengthOfYear() {
          return this.isLeapYear() ? 366 : 365;
        };
        _proto.with = function _with(adjusterOrField, value) {
          if (arguments.length === 1) {
            return this._withAdjuster(adjusterOrField);
          } else {
            return this._withField(adjusterOrField, value);
          }
        };
        _proto._withField = function _withField(field, newValue) {
          requireNonNull(field, "field");
          requireInstance(field, TemporalField, "field");
          if (field instanceof ChronoField) {
            var f = field;
            f.checkValidValue(newValue);
            switch (f) {
              case ChronoField.MONTH_OF_YEAR:
                return this.withMonth(newValue);
              case ChronoField.PROLEPTIC_MONTH:
                return this.plusMonths(newValue - this.getLong(ChronoField.PROLEPTIC_MONTH));
              case ChronoField.YEAR_OF_ERA:
                return this.withYear(this._year < 1 ? 1 - newValue : newValue);
              case ChronoField.YEAR:
                return this.withYear(newValue);
              case ChronoField.ERA:
                return this.getLong(ChronoField.ERA) === newValue ? this : this.withYear(1 - this._year);
            }
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.adjustInto(this, newValue);
        };
        _proto.withYear = function withYear(year) {
          ChronoField.YEAR.checkValidValue(year);
          return new YearMonth2(year, this._month);
        };
        _proto.withMonth = function withMonth(month) {
          ChronoField.MONTH_OF_YEAR.checkValidValue(month);
          return new YearMonth2(this._year, month);
        };
        _proto._plusUnit = function _plusUnit(amountToAdd, unit) {
          requireNonNull(unit, "unit");
          requireInstance(unit, TemporalUnit, "unit");
          if (unit instanceof ChronoUnit) {
            switch (unit) {
              case ChronoUnit.MONTHS:
                return this.plusMonths(amountToAdd);
              case ChronoUnit.YEARS:
                return this.plusYears(amountToAdd);
              case ChronoUnit.DECADES:
                return this.plusYears(MathUtil.safeMultiply(amountToAdd, 10));
              case ChronoUnit.CENTURIES:
                return this.plusYears(MathUtil.safeMultiply(amountToAdd, 100));
              case ChronoUnit.MILLENNIA:
                return this.plusYears(MathUtil.safeMultiply(amountToAdd, 1e3));
              case ChronoUnit.ERAS:
                return this.with(ChronoField.ERA, MathUtil.safeAdd(this.getLong(ChronoField.ERA), amountToAdd));
            }
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
          return unit.addTo(this, amountToAdd);
        };
        _proto.plusYears = function plusYears(yearsToAdd) {
          if (yearsToAdd === 0) {
            return this;
          }
          var newYear = ChronoField.YEAR.checkValidIntValue(this._year + yearsToAdd);
          return this.withYear(newYear);
        };
        _proto.plusMonths = function plusMonths(monthsToAdd) {
          if (monthsToAdd === 0) {
            return this;
          }
          var monthCount = this._year * 12 + (this._month - 1);
          var calcMonths = monthCount + monthsToAdd;
          var newYear = ChronoField.YEAR.checkValidIntValue(MathUtil.floorDiv(calcMonths, 12));
          var newMonth = MathUtil.floorMod(calcMonths, 12) + 1;
          return new YearMonth2(newYear, newMonth);
        };
        _proto.minusYears = function minusYears(yearsToSubtract) {
          return yearsToSubtract === MathUtil.MIN_SAFE_INTEGER ? this.plusYears(MathUtil.MIN_SAFE_INTEGER).plusYears(1) : this.plusYears(-yearsToSubtract);
        };
        _proto.minusMonths = function minusMonths(monthsToSubtract) {
          return monthsToSubtract === MathUtil.MIN_SAFE_INTEGER ? this.plusMonths(Math.MAX_SAFE_INTEGER).plusMonths(1) : this.plusMonths(-monthsToSubtract);
        };
        _proto.query = function query(_query) {
          requireNonNull(_query, "query");
          requireInstance(_query, TemporalQuery, "query");
          if (_query === TemporalQueries.chronology()) {
            return IsoChronology.INSTANCE;
          } else if (_query === TemporalQueries.precision()) {
            return ChronoUnit.MONTHS;
          } else if (_query === TemporalQueries.localDate() || _query === TemporalQueries.localTime() || _query === TemporalQueries.zone() || _query === TemporalQueries.zoneId() || _query === TemporalQueries.offset()) {
            return null;
          }
          return _Temporal.prototype.query.call(this, _query);
        };
        _proto.adjustInto = function adjustInto(temporal) {
          requireNonNull(temporal, "temporal");
          requireInstance(temporal, Temporal, "temporal");
          return temporal.with(ChronoField.PROLEPTIC_MONTH, this._getProlepticMonth());
        };
        _proto.until = function until(endExclusive, unit) {
          requireNonNull(endExclusive, "endExclusive");
          requireNonNull(unit, "unit");
          requireInstance(endExclusive, Temporal, "endExclusive");
          requireInstance(unit, TemporalUnit, "unit");
          var end = YearMonth2.from(endExclusive);
          if (unit instanceof ChronoUnit) {
            var monthsUntil = end._getProlepticMonth() - this._getProlepticMonth();
            switch (unit) {
              case ChronoUnit.MONTHS:
                return monthsUntil;
              case ChronoUnit.YEARS:
                return MathUtil.intDiv(monthsUntil, 12);
              case ChronoUnit.DECADES:
                return MathUtil.intDiv(monthsUntil, 120);
              case ChronoUnit.CENTURIES:
                return MathUtil.intDiv(monthsUntil, 1200);
              case ChronoUnit.MILLENNIA:
                return MathUtil.intDiv(monthsUntil, 12e3);
              case ChronoUnit.ERAS:
                return end.getLong(ChronoField.ERA) - this.getLong(ChronoField.ERA);
            }
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
          return unit.between(this, end);
        };
        _proto.atDay = function atDay(dayOfMonth) {
          requireNonNull(dayOfMonth, "dayOfMonth");
          return LocalDate2.of(this._year, this._month, dayOfMonth);
        };
        _proto.atEndOfMonth = function atEndOfMonth() {
          return LocalDate2.of(this._year, this._month, this.lengthOfMonth());
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          requireInstance(other, YearMonth2, "other");
          var cmp = this._year - other.year();
          if (cmp === 0) {
            cmp = this._month - other.monthValue();
          }
          return cmp;
        };
        _proto.isAfter = function isAfter(other) {
          return this.compareTo(other) > 0;
        };
        _proto.isBefore = function isBefore(other) {
          return this.compareTo(other) < 0;
        };
        _proto.equals = function equals(obj) {
          if (this === obj) {
            return true;
          }
          if (obj instanceof YearMonth2) {
            var other = obj;
            return this.year() === other.year() && this.monthValue() === other.monthValue();
          }
          return false;
        };
        _proto.toString = function toString() {
          return PARSER$1.format(this);
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        _proto.format = function format(formatter) {
          requireNonNull(formatter, "formatter");
          return formatter.format(this);
        };
        return YearMonth2;
      }(Temporal);
      var PARSER$1;
      function _init$b() {
        PARSER$1 = new DateTimeFormatterBuilder().appendValue(ChronoField.YEAR, 4, 10, SignStyle.EXCEEDS_PAD).appendLiteral("-").appendValue(ChronoField.MONTH_OF_YEAR, 2).toFormatter();
        YearMonth.FROM = createTemporalQuery("YearMonth.FROM", function(temporal) {
          return YearMonth.from(temporal);
        });
      }
      var Year = function(_Temporal) {
        _inheritsLoose(Year2, _Temporal);
        function Year2(value) {
          var _this;
          _this = _Temporal.call(this) || this;
          _this._year = MathUtil.safeToInt(value);
          return _this;
        }
        var _proto = Year2.prototype;
        _proto.value = function value() {
          return this._year;
        };
        Year2.now = function now(zoneIdOrClock) {
          if (zoneIdOrClock === void 0) {
            zoneIdOrClock = void 0;
          }
          if (zoneIdOrClock === void 0) {
            return Year2.now0();
          } else if (zoneIdOrClock instanceof ZoneId2) {
            return Year2.nowZoneId(zoneIdOrClock);
          } else {
            return Year2.nowClock(zoneIdOrClock);
          }
        };
        Year2.now0 = function now0() {
          return Year2.nowClock(Clock.systemDefaultZone());
        };
        Year2.nowZoneId = function nowZoneId(zone) {
          requireNonNull(zone, "zone");
          requireInstance(zone, ZoneId2, "zone");
          return Year2.nowClock(Clock.system(zone));
        };
        Year2.nowClock = function nowClock(clock) {
          requireNonNull(clock, "clock");
          requireInstance(clock, Clock, "clock");
          var now = LocalDate2.now(clock);
          return Year2.of(now.year());
        };
        Year2.of = function of(isoYear) {
          requireNonNull(isoYear, "isoYear");
          ChronoField.YEAR.checkValidValue(isoYear);
          return new Year2(isoYear);
        };
        Year2.from = function from(temporal) {
          requireNonNull(temporal, "temporal");
          requireInstance(temporal, TemporalAccessor, "temporal");
          if (temporal instanceof Year2) {
            return temporal;
          }
          try {
            return Year2.of(temporal.get(ChronoField.YEAR));
          } catch (ex) {
            throw new DateTimeException("Unable to obtain Year from TemporalAccessor: " + temporal + ", type " + (temporal && temporal.constructor != null ? temporal.constructor.name : ""));
          }
        };
        Year2.parse = function parse(text, formatter) {
          if (arguments.length <= 1) {
            return Year2.parseText(text);
          } else {
            return Year2.parseTextFormatter(text, formatter);
          }
        };
        Year2.parseText = function parseText(text) {
          requireNonNull(text, "text");
          return Year2.parse(text, PARSER);
        };
        Year2.parseTextFormatter = function parseTextFormatter(text, formatter) {
          if (formatter === void 0) {
            formatter = PARSER;
          }
          requireNonNull(text, "text");
          requireNonNull(formatter, "formatter");
          requireInstance(formatter, DateTimeFormatter, "formatter");
          return formatter.parse(text, Year2.FROM);
        };
        Year2.isLeap = function isLeap(year) {
          return MathUtil.intMod(year, 4) === 0 && (MathUtil.intMod(year, 100) !== 0 || MathUtil.intMod(year, 400) === 0);
        };
        _proto.isSupported = function isSupported(fieldOrUnit) {
          if (arguments.length === 1 && fieldOrUnit instanceof TemporalField) {
            return this.isSupportedField(fieldOrUnit);
          } else {
            return this.isSupportedUnit(fieldOrUnit);
          }
        };
        _proto.isSupportedField = function isSupportedField(field) {
          if (field instanceof ChronoField) {
            return field === ChronoField.YEAR || field === ChronoField.YEAR_OF_ERA || field === ChronoField.ERA;
          }
          return field != null && field.isSupportedBy(this);
        };
        _proto.isSupportedUnit = function isSupportedUnit(unit) {
          if (unit instanceof ChronoUnit) {
            return unit === ChronoUnit.YEARS || unit === ChronoUnit.DECADES || unit === ChronoUnit.CENTURIES || unit === ChronoUnit.MILLENNIA || unit === ChronoUnit.ERAS;
          }
          return unit != null && unit.isSupportedBy(this);
        };
        _proto.range = function range(field) {
          if (this.isSupported(field)) {
            return field.range();
          } else if (field instanceof ChronoField) {
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return _Temporal.prototype.range.call(this, field);
        };
        _proto.get = function get(field) {
          return this.range(field).checkValidIntValue(this.getLong(field), field);
        };
        _proto.getLong = function getLong(field) {
          requireNonNull(field, "field");
          if (field instanceof ChronoField) {
            switch (field) {
              case ChronoField.YEAR_OF_ERA:
                return this._year < 1 ? 1 - this._year : this._year;
              case ChronoField.YEAR:
                return this._year;
              case ChronoField.ERA:
                return this._year < 1 ? 0 : 1;
            }
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.getFrom(this);
        };
        _proto.isLeap = function isLeap() {
          return Year2.isLeap(this._year);
        };
        _proto._withField = function _withField(field, newValue) {
          requireNonNull(field, "field");
          requireInstance(field, TemporalField, "field");
          if (field instanceof ChronoField) {
            field.checkValidValue(newValue);
            switch (field) {
              case ChronoField.YEAR_OF_ERA:
                return Year2.of(this._year < 1 ? 1 - newValue : newValue);
              case ChronoField.YEAR:
                return Year2.of(newValue);
              case ChronoField.ERA:
                return this.getLong(ChronoField.ERA) === newValue ? this : Year2.of(1 - this._year);
            }
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.adjustInto(this, newValue);
        };
        _proto._plusUnit = function _plusUnit(amountToAdd, unit) {
          requireNonNull(amountToAdd, "amountToAdd");
          requireNonNull(unit, "unit");
          requireInstance(unit, TemporalUnit, "unit");
          if (unit instanceof ChronoUnit) {
            switch (unit) {
              case ChronoUnit.YEARS:
                return this.plusYears(amountToAdd);
              case ChronoUnit.DECADES:
                return this.plusYears(MathUtil.safeMultiply(amountToAdd, 10));
              case ChronoUnit.CENTURIES:
                return this.plusYears(MathUtil.safeMultiply(amountToAdd, 100));
              case ChronoUnit.MILLENNIA:
                return this.plusYears(MathUtil.safeMultiply(amountToAdd, 1e3));
              case ChronoUnit.ERAS:
                return this.with(ChronoField.ERA, MathUtil.safeAdd(this.getLong(ChronoField.ERA), amountToAdd));
            }
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
          return unit.addTo(this, amountToAdd);
        };
        _proto.plusYears = function plusYears(yearsToAdd) {
          if (yearsToAdd === 0) {
            return this;
          }
          return Year2.of(ChronoField.YEAR.checkValidIntValue(MathUtil.safeAdd(this._year, yearsToAdd)));
        };
        _proto.minusYears = function minusYears(yearsToSubtract) {
          return yearsToSubtract === MathUtil.MIN_SAFE_INTEGER ? this.plusYears(MathUtil.MAX_SAFE_INTEGER).plusYears(1) : this.plusYears(-yearsToSubtract);
        };
        _proto.adjustInto = function adjustInto(temporal) {
          requireNonNull(temporal, "temporal");
          return temporal.with(ChronoField.YEAR, this._year);
        };
        _proto.isValidMonthDay = function isValidMonthDay(monthDay) {
          return monthDay != null && monthDay.isValidYear(this._year);
        };
        _proto.length = function length() {
          return this.isLeap() ? 366 : 365;
        };
        _proto.atDay = function atDay(dayOfYear) {
          return LocalDate2.ofYearDay(this._year, dayOfYear);
        };
        _proto.atMonth = function atMonth(monthOrNumber) {
          if (arguments.length === 1 && monthOrNumber instanceof Month) {
            return this.atMonthMonth(monthOrNumber);
          } else {
            return this.atMonthNumber(monthOrNumber);
          }
        };
        _proto.atMonthMonth = function atMonthMonth(month) {
          requireNonNull(month, "month");
          requireInstance(month, Month, "month");
          return YearMonth.of(this._year, month);
        };
        _proto.atMonthNumber = function atMonthNumber(month) {
          requireNonNull(month, "month");
          return YearMonth.of(this._year, month);
        };
        _proto.atMonthDay = function atMonthDay(monthDay) {
          requireNonNull(monthDay, "monthDay");
          requireInstance(monthDay, MonthDay, "monthDay");
          return monthDay.atYear(this._year);
        };
        _proto.query = function query(_query) {
          requireNonNull(_query, "query()");
          requireInstance(_query, TemporalQuery, "query()");
          if (_query === TemporalQueries.chronology()) {
            return IsoChronology.INSTANCE;
          } else if (_query === TemporalQueries.precision()) {
            return ChronoUnit.YEARS;
          } else if (_query === TemporalQueries.localDate() || _query === TemporalQueries.localTime() || _query === TemporalQueries.zone() || _query === TemporalQueries.zoneId() || _query === TemporalQueries.offset()) {
            return null;
          }
          return _Temporal.prototype.query.call(this, _query);
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          requireInstance(other, Year2, "other");
          return this._year - other._year;
        };
        _proto.isAfter = function isAfter(other) {
          requireNonNull(other, "other");
          requireInstance(other, Year2, "other");
          return this._year > other._year;
        };
        _proto.isBefore = function isBefore(other) {
          requireNonNull(other, "other");
          requireInstance(other, Year2, "other");
          return this._year < other._year;
        };
        _proto.format = function format(formatter) {
          requireNonNull(formatter, "formatter");
          requireInstance(formatter, DateTimeFormatter, "formatter");
          return formatter.format(this);
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof Year2) {
            return this.value() === other.value();
          }
          return false;
        };
        _proto.toString = function toString() {
          return "" + this._year;
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        _proto.until = function until(endExclusive, unit) {
          var end = Year2.from(endExclusive);
          if (unit instanceof ChronoUnit) {
            var yearsUntil = end.value() - this.value();
            switch (unit) {
              case ChronoUnit.YEARS:
                return yearsUntil;
              case ChronoUnit.DECADES:
                return MathUtil.intDiv(yearsUntil, 10);
              case ChronoUnit.CENTURIES:
                return MathUtil.intDiv(yearsUntil, 100);
              case ChronoUnit.MILLENNIA:
                return MathUtil.intDiv(yearsUntil, 1e3);
              case ChronoUnit.ERAS:
                return end.getLong(ChronoField.ERA) - this.getLong(ChronoField.ERA);
            }
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
          return unit.between(this, end);
        };
        return Year2;
      }(Temporal);
      var PARSER;
      function _init$a() {
        Year.MIN_VALUE = YearConstants.MIN_VALUE;
        Year.MAX_VALUE = YearConstants.MAX_VALUE;
        PARSER = new DateTimeFormatterBuilder().appendValue(ChronoField.YEAR, 4, 10, SignStyle.EXCEEDS_PAD).toFormatter();
        Year.FROM = createTemporalQuery("Year.FROM", function(temporal) {
          return Year.from(temporal);
        });
      }
      var TemporalAdjuster = function() {
        function TemporalAdjuster2() {
        }
        var _proto = TemporalAdjuster2.prototype;
        _proto.adjustInto = function adjustInto(temporal) {
          abstractMethodFail("adjustInto");
        };
        return TemporalAdjuster2;
      }();
      var TemporalAdjusters = function() {
        function TemporalAdjusters2() {
        }
        TemporalAdjusters2.firstDayOfMonth = function firstDayOfMonth() {
          return Impl.FIRST_DAY_OF_MONTH;
        };
        TemporalAdjusters2.lastDayOfMonth = function lastDayOfMonth() {
          return Impl.LAST_DAY_OF_MONTH;
        };
        TemporalAdjusters2.firstDayOfNextMonth = function firstDayOfNextMonth() {
          return Impl.FIRST_DAY_OF_NEXT_MONTH;
        };
        TemporalAdjusters2.firstDayOfYear = function firstDayOfYear() {
          return Impl.FIRST_DAY_OF_YEAR;
        };
        TemporalAdjusters2.lastDayOfYear = function lastDayOfYear() {
          return Impl.LAST_DAY_OF_YEAR;
        };
        TemporalAdjusters2.firstDayOfNextYear = function firstDayOfNextYear() {
          return Impl.FIRST_DAY_OF_NEXT_YEAR;
        };
        TemporalAdjusters2.firstInMonth = function firstInMonth(dayOfWeek) {
          requireNonNull(dayOfWeek, "dayOfWeek");
          return new DayOfWeekInMonth(1, dayOfWeek);
        };
        TemporalAdjusters2.lastInMonth = function lastInMonth(dayOfWeek) {
          requireNonNull(dayOfWeek, "dayOfWeek");
          return new DayOfWeekInMonth(-1, dayOfWeek);
        };
        TemporalAdjusters2.dayOfWeekInMonth = function dayOfWeekInMonth(ordinal, dayOfWeek) {
          requireNonNull(dayOfWeek, "dayOfWeek");
          return new DayOfWeekInMonth(ordinal, dayOfWeek);
        };
        TemporalAdjusters2.next = function next(dayOfWeek) {
          return new RelativeDayOfWeek(2, dayOfWeek);
        };
        TemporalAdjusters2.nextOrSame = function nextOrSame(dayOfWeek) {
          return new RelativeDayOfWeek(0, dayOfWeek);
        };
        TemporalAdjusters2.previous = function previous(dayOfWeek) {
          return new RelativeDayOfWeek(3, dayOfWeek);
        };
        TemporalAdjusters2.previousOrSame = function previousOrSame(dayOfWeek) {
          return new RelativeDayOfWeek(1, dayOfWeek);
        };
        return TemporalAdjusters2;
      }();
      var Impl = function(_TemporalAdjuster) {
        _inheritsLoose(Impl2, _TemporalAdjuster);
        function Impl2(ordinal) {
          var _this;
          _this = _TemporalAdjuster.call(this) || this;
          _this._ordinal = ordinal;
          return _this;
        }
        var _proto = Impl2.prototype;
        _proto.adjustInto = function adjustInto(temporal) {
          switch (this._ordinal) {
            case 0:
              return temporal.with(ChronoField.DAY_OF_MONTH, 1);
            case 1:
              return temporal.with(ChronoField.DAY_OF_MONTH, temporal.range(ChronoField.DAY_OF_MONTH).maximum());
            case 2:
              return temporal.with(ChronoField.DAY_OF_MONTH, 1).plus(1, ChronoUnit.MONTHS);
            case 3:
              return temporal.with(ChronoField.DAY_OF_YEAR, 1);
            case 4:
              return temporal.with(ChronoField.DAY_OF_YEAR, temporal.range(ChronoField.DAY_OF_YEAR).maximum());
            case 5:
              return temporal.with(ChronoField.DAY_OF_YEAR, 1).plus(1, ChronoUnit.YEARS);
          }
          throw new IllegalStateException("Unreachable");
        };
        return Impl2;
      }(TemporalAdjuster);
      Impl.FIRST_DAY_OF_MONTH = new Impl(0);
      Impl.LAST_DAY_OF_MONTH = new Impl(1);
      Impl.FIRST_DAY_OF_NEXT_MONTH = new Impl(2);
      Impl.FIRST_DAY_OF_YEAR = new Impl(3);
      Impl.LAST_DAY_OF_YEAR = new Impl(4);
      Impl.FIRST_DAY_OF_NEXT_YEAR = new Impl(5);
      var DayOfWeekInMonth = function(_TemporalAdjuster2) {
        _inheritsLoose(DayOfWeekInMonth2, _TemporalAdjuster2);
        function DayOfWeekInMonth2(ordinal, dow) {
          var _this2;
          _this2 = _TemporalAdjuster2.call(this) || this;
          _this2._ordinal = ordinal;
          _this2._dowValue = dow.value();
          return _this2;
        }
        var _proto2 = DayOfWeekInMonth2.prototype;
        _proto2.adjustInto = function adjustInto(temporal) {
          if (this._ordinal >= 0) {
            var temp = temporal.with(ChronoField.DAY_OF_MONTH, 1);
            var curDow = temp.get(ChronoField.DAY_OF_WEEK);
            var dowDiff = MathUtil.intMod(this._dowValue - curDow + 7, 7);
            dowDiff += (this._ordinal - 1) * 7;
            return temp.plus(dowDiff, ChronoUnit.DAYS);
          } else {
            var _temp = temporal.with(ChronoField.DAY_OF_MONTH, temporal.range(ChronoField.DAY_OF_MONTH).maximum());
            var _curDow = _temp.get(ChronoField.DAY_OF_WEEK);
            var daysDiff = this._dowValue - _curDow;
            daysDiff = daysDiff === 0 ? 0 : daysDiff > 0 ? daysDiff - 7 : daysDiff;
            daysDiff -= (-this._ordinal - 1) * 7;
            return _temp.plus(daysDiff, ChronoUnit.DAYS);
          }
        };
        return DayOfWeekInMonth2;
      }(TemporalAdjuster);
      var RelativeDayOfWeek = function(_TemporalAdjuster3) {
        _inheritsLoose(RelativeDayOfWeek2, _TemporalAdjuster3);
        function RelativeDayOfWeek2(relative, dayOfWeek) {
          var _this3;
          _this3 = _TemporalAdjuster3.call(this) || this;
          requireNonNull(dayOfWeek, "dayOfWeek");
          _this3._relative = relative;
          _this3._dowValue = dayOfWeek.value();
          return _this3;
        }
        var _proto3 = RelativeDayOfWeek2.prototype;
        _proto3.adjustInto = function adjustInto(temporal) {
          var calDow = temporal.get(ChronoField.DAY_OF_WEEK);
          if (this._relative < 2 && calDow === this._dowValue) {
            return temporal;
          }
          if ((this._relative & 1) === 0) {
            var daysDiff = calDow - this._dowValue;
            return temporal.plus(daysDiff >= 0 ? 7 - daysDiff : -daysDiff, ChronoUnit.DAYS);
          } else {
            var _daysDiff = this._dowValue - calDow;
            return temporal.minus(_daysDiff >= 0 ? 7 - _daysDiff : -_daysDiff, ChronoUnit.DAYS);
          }
        };
        return RelativeDayOfWeek2;
      }(TemporalAdjuster);
      var IsoChronology = function(_Enum) {
        _inheritsLoose(IsoChronology2, _Enum);
        function IsoChronology2() {
          return _Enum.apply(this, arguments) || this;
        }
        IsoChronology2.isLeapYear = function isLeapYear(prolepticYear) {
          return (prolepticYear & 3) === 0 && (prolepticYear % 100 !== 0 || prolepticYear % 400 === 0);
        };
        var _proto = IsoChronology2.prototype;
        _proto._updateResolveMap = function _updateResolveMap(fieldValues, field, value) {
          requireNonNull(fieldValues, "fieldValues");
          requireNonNull(field, "field");
          var current = fieldValues.get(field);
          if (current != null && current !== value) {
            throw new DateTimeException("Invalid state, field: " + field + " " + current + " conflicts with " + field + " " + value);
          }
          fieldValues.put(field, value);
        };
        _proto.resolveDate = function resolveDate(fieldValues, resolverStyle) {
          if (fieldValues.containsKey(ChronoField.EPOCH_DAY)) {
            return LocalDate2.ofEpochDay(fieldValues.remove(ChronoField.EPOCH_DAY));
          }
          var prolepticMonth = fieldValues.remove(ChronoField.PROLEPTIC_MONTH);
          if (prolepticMonth != null) {
            if (resolverStyle !== ResolverStyle.LENIENT) {
              ChronoField.PROLEPTIC_MONTH.checkValidValue(prolepticMonth);
            }
            this._updateResolveMap(fieldValues, ChronoField.MONTH_OF_YEAR, MathUtil.floorMod(prolepticMonth, 12) + 1);
            this._updateResolveMap(fieldValues, ChronoField.YEAR, MathUtil.floorDiv(prolepticMonth, 12));
          }
          var yoeLong = fieldValues.remove(ChronoField.YEAR_OF_ERA);
          if (yoeLong != null) {
            if (resolverStyle !== ResolverStyle.LENIENT) {
              ChronoField.YEAR_OF_ERA.checkValidValue(yoeLong);
            }
            var era = fieldValues.remove(ChronoField.ERA);
            if (era == null) {
              var year = fieldValues.get(ChronoField.YEAR);
              if (resolverStyle === ResolverStyle.STRICT) {
                if (year != null) {
                  this._updateResolveMap(fieldValues, ChronoField.YEAR, year > 0 ? yoeLong : MathUtil.safeSubtract(1, yoeLong));
                } else {
                  fieldValues.put(ChronoField.YEAR_OF_ERA, yoeLong);
                }
              } else {
                this._updateResolveMap(fieldValues, ChronoField.YEAR, year == null || year > 0 ? yoeLong : MathUtil.safeSubtract(1, yoeLong));
              }
            } else if (era === 1) {
              this._updateResolveMap(fieldValues, ChronoField.YEAR, yoeLong);
            } else if (era === 0) {
              this._updateResolveMap(fieldValues, ChronoField.YEAR, MathUtil.safeSubtract(1, yoeLong));
            } else {
              throw new DateTimeException("Invalid value for era: " + era);
            }
          } else if (fieldValues.containsKey(ChronoField.ERA)) {
            ChronoField.ERA.checkValidValue(fieldValues.get(ChronoField.ERA));
          }
          if (fieldValues.containsKey(ChronoField.YEAR)) {
            if (fieldValues.containsKey(ChronoField.MONTH_OF_YEAR)) {
              if (fieldValues.containsKey(ChronoField.DAY_OF_MONTH)) {
                var y = ChronoField.YEAR.checkValidIntValue(fieldValues.remove(ChronoField.YEAR));
                var moy = fieldValues.remove(ChronoField.MONTH_OF_YEAR);
                var dom = fieldValues.remove(ChronoField.DAY_OF_MONTH);
                if (resolverStyle === ResolverStyle.LENIENT) {
                  var months = moy - 1;
                  var days = dom - 1;
                  return LocalDate2.of(y, 1, 1).plusMonths(months).plusDays(days);
                } else if (resolverStyle === ResolverStyle.SMART) {
                  ChronoField.DAY_OF_MONTH.checkValidValue(dom);
                  if (moy === 4 || moy === 6 || moy === 9 || moy === 11) {
                    dom = Math.min(dom, 30);
                  } else if (moy === 2) {
                    dom = Math.min(dom, Month.FEBRUARY.length(Year.isLeap(y)));
                  }
                  return LocalDate2.of(y, moy, dom);
                } else {
                  return LocalDate2.of(y, moy, dom);
                }
              }
            }
            if (fieldValues.containsKey(ChronoField.DAY_OF_YEAR)) {
              var _y = ChronoField.YEAR.checkValidIntValue(fieldValues.remove(ChronoField.YEAR));
              if (resolverStyle === ResolverStyle.LENIENT) {
                var _days = MathUtil.safeSubtract(fieldValues.remove(ChronoField.DAY_OF_YEAR), 1);
                return LocalDate2.ofYearDay(_y, 1).plusDays(_days);
              }
              var doy = ChronoField.DAY_OF_YEAR.checkValidIntValue(fieldValues.remove(ChronoField.DAY_OF_YEAR));
              return LocalDate2.ofYearDay(_y, doy);
            }
            if (fieldValues.containsKey(ChronoField.ALIGNED_WEEK_OF_YEAR)) {
              if (fieldValues.containsKey(ChronoField.ALIGNED_DAY_OF_WEEK_IN_YEAR)) {
                var _y2 = ChronoField.YEAR.checkValidIntValue(fieldValues.remove(ChronoField.YEAR));
                if (resolverStyle === ResolverStyle.LENIENT) {
                  var weeks = MathUtil.safeSubtract(fieldValues.remove(ChronoField.ALIGNED_WEEK_OF_YEAR), 1);
                  var _days2 = MathUtil.safeSubtract(fieldValues.remove(ChronoField.ALIGNED_DAY_OF_WEEK_IN_YEAR), 1);
                  return LocalDate2.of(_y2, 1, 1).plusWeeks(weeks).plusDays(_days2);
                }
                var aw = ChronoField.ALIGNED_WEEK_OF_YEAR.checkValidIntValue(fieldValues.remove(ChronoField.ALIGNED_WEEK_OF_YEAR));
                var ad = ChronoField.ALIGNED_DAY_OF_WEEK_IN_YEAR.checkValidIntValue(fieldValues.remove(ChronoField.ALIGNED_DAY_OF_WEEK_IN_YEAR));
                var date = LocalDate2.of(_y2, 1, 1).plusDays((aw - 1) * 7 + (ad - 1));
                if (resolverStyle === ResolverStyle.STRICT && date.get(ChronoField.YEAR) !== _y2) {
                  throw new DateTimeException("Strict mode rejected date parsed to a different year");
                }
                return date;
              }
              if (fieldValues.containsKey(ChronoField.DAY_OF_WEEK)) {
                var _y3 = ChronoField.YEAR.checkValidIntValue(fieldValues.remove(ChronoField.YEAR));
                if (resolverStyle === ResolverStyle.LENIENT) {
                  var _weeks = MathUtil.safeSubtract(fieldValues.remove(ChronoField.ALIGNED_WEEK_OF_YEAR), 1);
                  var _days3 = MathUtil.safeSubtract(fieldValues.remove(ChronoField.DAY_OF_WEEK), 1);
                  return LocalDate2.of(_y3, 1, 1).plusWeeks(_weeks).plusDays(_days3);
                }
                var _aw = ChronoField.ALIGNED_WEEK_OF_YEAR.checkValidIntValue(fieldValues.remove(ChronoField.ALIGNED_WEEK_OF_YEAR));
                var dow = ChronoField.DAY_OF_WEEK.checkValidIntValue(fieldValues.remove(ChronoField.DAY_OF_WEEK));
                var _date = LocalDate2.of(_y3, 1, 1).plusWeeks(_aw - 1).with(TemporalAdjusters.nextOrSame(DayOfWeek.of(dow)));
                if (resolverStyle === ResolverStyle.STRICT && _date.get(ChronoField.YEAR) !== _y3) {
                  throw new DateTimeException("Strict mode rejected date parsed to a different month");
                }
                return _date;
              }
            }
          }
          return null;
        };
        _proto.date = function date(temporal) {
          return LocalDate2.from(temporal);
        };
        return IsoChronology2;
      }(Enum);
      function _init$9() {
        IsoChronology.INSTANCE = new IsoChronology("IsoChronology");
      }
      var OffsetTime = function(_Temporal) {
        _inheritsLoose(OffsetTime2, _Temporal);
        OffsetTime2.from = function from(temporal) {
          requireNonNull(temporal, "temporal");
          if (temporal instanceof OffsetTime2) {
            return temporal;
          } else if (temporal instanceof OffsetDateTime) {
            return temporal.toOffsetTime();
          }
          try {
            var time = LocalTime.from(temporal);
            var offset = ZoneOffset.from(temporal);
            return new OffsetTime2(time, offset);
          } catch (ex) {
            throw new DateTimeException("Unable to obtain OffsetTime TemporalAccessor: " + temporal + ", type " + (temporal.constructor != null ? temporal.constructor.name : ""));
          }
        };
        OffsetTime2.now = function now(clockOrZone) {
          if (arguments.length === 0) {
            return OffsetTime2._now(Clock.systemDefaultZone());
          } else if (clockOrZone instanceof Clock) {
            return OffsetTime2._now(clockOrZone);
          } else {
            return OffsetTime2._now(Clock.system(clockOrZone));
          }
        };
        OffsetTime2._now = function _now(clock) {
          requireNonNull(clock, "clock");
          var now = clock.instant();
          return OffsetTime2.ofInstant(now, clock.zone().rules().offset(now));
        };
        OffsetTime2.of = function of() {
          if (arguments.length <= 2) {
            return OffsetTime2.ofTimeAndOffset.apply(this, arguments);
          } else {
            return OffsetTime2.ofNumbers.apply(this, arguments);
          }
        };
        OffsetTime2.ofNumbers = function ofNumbers(hour, minute, second, nanoOfSecond, offset) {
          var time = LocalTime.of(hour, minute, second, nanoOfSecond);
          return new OffsetTime2(time, offset);
        };
        OffsetTime2.ofTimeAndOffset = function ofTimeAndOffset(time, offset) {
          return new OffsetTime2(time, offset);
        };
        OffsetTime2.ofInstant = function ofInstant(instant, zone) {
          requireNonNull(instant, "instant");
          requireInstance(instant, Instant, "instant");
          requireNonNull(zone, "zone");
          requireInstance(zone, ZoneId2, "zone");
          var rules = zone.rules();
          var offset = rules.offset(instant);
          var secsOfDay = instant.epochSecond() % LocalTime.SECONDS_PER_DAY;
          secsOfDay = (secsOfDay + offset.totalSeconds()) % LocalTime.SECONDS_PER_DAY;
          if (secsOfDay < 0) {
            secsOfDay += LocalTime.SECONDS_PER_DAY;
          }
          var time = LocalTime.ofSecondOfDay(secsOfDay, instant.nano());
          return new OffsetTime2(time, offset);
        };
        OffsetTime2.parse = function parse(text, formatter) {
          if (formatter === void 0) {
            formatter = DateTimeFormatter.ISO_OFFSET_TIME;
          }
          requireNonNull(formatter, "formatter");
          return formatter.parse(text, OffsetTime2.FROM);
        };
        function OffsetTime2(time, offset) {
          var _this;
          _this = _Temporal.call(this) || this;
          requireNonNull(time, "time");
          requireInstance(time, LocalTime, "time");
          requireNonNull(offset, "offset");
          requireInstance(offset, ZoneOffset, "offset");
          _this._time = time;
          _this._offset = offset;
          return _this;
        }
        var _proto = OffsetTime2.prototype;
        _proto.adjustInto = function adjustInto(temporal) {
          return temporal.with(ChronoField.NANO_OF_DAY, this._time.toNanoOfDay()).with(ChronoField.OFFSET_SECONDS, this.offset().totalSeconds());
        };
        _proto.atDate = function atDate(date) {
          return OffsetDateTime.of(date, this._time, this._offset);
        };
        _proto.format = function format(formatter) {
          requireNonNull(formatter, "formatter");
          return formatter.format(this, OffsetTime2.FROM);
        };
        _proto.get = function get(field) {
          return _Temporal.prototype.get.call(this, field);
        };
        _proto.getLong = function getLong(field) {
          if (field instanceof ChronoField) {
            if (field === ChronoField.OFFSET_SECONDS) {
              return this._offset.totalSeconds();
            }
            return this._time.getLong(field);
          }
          return field.getFrom(this);
        };
        _proto.hour = function hour() {
          return this._time.hour();
        };
        _proto.minute = function minute() {
          return this._time.minute();
        };
        _proto.second = function second() {
          return this._time.second();
        };
        _proto.nano = function nano() {
          return this._time.nano();
        };
        _proto.offset = function offset() {
          return this._offset;
        };
        _proto.isAfter = function isAfter(other) {
          requireNonNull(other, "other");
          return this._toEpochNano() > other._toEpochNano();
        };
        _proto.isBefore = function isBefore(other) {
          requireNonNull(other, "other");
          return this._toEpochNano() < other._toEpochNano();
        };
        _proto.isEqual = function isEqual(other) {
          requireNonNull(other, "other");
          return this._toEpochNano() === other._toEpochNano();
        };
        _proto.isSupported = function isSupported(fieldOrUnit) {
          if (fieldOrUnit instanceof ChronoField) {
            return fieldOrUnit.isTimeBased() || fieldOrUnit === ChronoField.OFFSET_SECONDS;
          } else if (fieldOrUnit instanceof ChronoUnit) {
            return fieldOrUnit.isTimeBased();
          }
          return fieldOrUnit != null && fieldOrUnit.isSupportedBy(this);
        };
        _proto.minusHours = function minusHours(hours) {
          return this._withLocalTimeOffset(this._time.minusHours(hours), this._offset);
        };
        _proto.minusMinutes = function minusMinutes(minutes) {
          return this._withLocalTimeOffset(this._time.minusMinutes(minutes), this._offset);
        };
        _proto.minusSeconds = function minusSeconds(seconds) {
          return this._withLocalTimeOffset(this._time.minusSeconds(seconds), this._offset);
        };
        _proto.minusNanos = function minusNanos(nanos) {
          return this._withLocalTimeOffset(this._time.minusNanos(nanos), this._offset);
        };
        _proto._minusAmount = function _minusAmount(amount) {
          requireNonNull(amount);
          return amount.subtractFrom(this);
        };
        _proto._minusUnit = function _minusUnit(amountToSubtract, unit) {
          return this.plus(-1 * amountToSubtract, unit);
        };
        _proto._plusAmount = function _plusAmount(amount) {
          requireNonNull(amount);
          return amount.addTo(this);
        };
        _proto._plusUnit = function _plusUnit(amountToAdd, unit) {
          if (unit instanceof ChronoUnit) {
            return this._withLocalTimeOffset(this._time.plus(amountToAdd, unit), this._offset);
          }
          return unit.addTo(this, amountToAdd);
        };
        _proto.plusHours = function plusHours(hours) {
          return this._withLocalTimeOffset(this._time.plusHours(hours), this._offset);
        };
        _proto.plusMinutes = function plusMinutes(minutes) {
          return this._withLocalTimeOffset(this._time.plusMinutes(minutes), this._offset);
        };
        _proto.plusSeconds = function plusSeconds(seconds) {
          return this._withLocalTimeOffset(this._time.plusSeconds(seconds), this._offset);
        };
        _proto.plusNanos = function plusNanos(nanos) {
          return this._withLocalTimeOffset(this._time.plusNanos(nanos), this._offset);
        };
        _proto.query = function query(_query) {
          requireNonNull(_query, "query");
          if (_query === TemporalQueries.precision()) {
            return ChronoUnit.NANOS;
          } else if (_query === TemporalQueries.offset() || _query === TemporalQueries.zone()) {
            return this.offset();
          } else if (_query === TemporalQueries.localTime()) {
            return this._time;
          } else if (_query === TemporalQueries.chronology() || _query === TemporalQueries.localDate() || _query === TemporalQueries.zoneId()) {
            return null;
          }
          return _Temporal.prototype.query.call(this, _query);
        };
        _proto.range = function range(field) {
          if (field instanceof ChronoField) {
            if (field === ChronoField.OFFSET_SECONDS) {
              return field.range();
            }
            return this._time.range(field);
          }
          return field.rangeRefinedBy(this);
        };
        _proto.toLocalTime = function toLocalTime() {
          return this._time;
        };
        _proto.truncatedTo = function truncatedTo(unit) {
          return this._withLocalTimeOffset(this._time.truncatedTo(unit), this._offset);
        };
        _proto.until = function until(endExclusive, unit) {
          requireNonNull(endExclusive, "endExclusive");
          requireNonNull(unit, "unit");
          var end = OffsetTime2.from(endExclusive);
          if (unit instanceof ChronoUnit) {
            var nanosUntil = end._toEpochNano() - this._toEpochNano();
            switch (unit) {
              case ChronoUnit.NANOS:
                return nanosUntil;
              case ChronoUnit.MICROS:
                return MathUtil.intDiv(nanosUntil, 1e3);
              case ChronoUnit.MILLIS:
                return MathUtil.intDiv(nanosUntil, 1e6);
              case ChronoUnit.SECONDS:
                return MathUtil.intDiv(nanosUntil, LocalTime.NANOS_PER_SECOND);
              case ChronoUnit.MINUTES:
                return MathUtil.intDiv(nanosUntil, LocalTime.NANOS_PER_MINUTE);
              case ChronoUnit.HOURS:
                return MathUtil.intDiv(nanosUntil, LocalTime.NANOS_PER_HOUR);
              case ChronoUnit.HALF_DAYS:
                return MathUtil.intDiv(nanosUntil, 12 * LocalTime.NANOS_PER_HOUR);
            }
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
          return unit.between(this, end);
        };
        _proto.withHour = function withHour(hour) {
          return this._withLocalTimeOffset(this._time.withHour(hour), this._offset);
        };
        _proto.withMinute = function withMinute(minute) {
          return this._withLocalTimeOffset(this._time.withMinute(minute), this._offset);
        };
        _proto.withSecond = function withSecond(second) {
          return this._withLocalTimeOffset(this._time.withSecond(second), this._offset);
        };
        _proto.withNano = function withNano(nano) {
          return this._withLocalTimeOffset(this._time.withNano(nano), this._offset);
        };
        _proto.withOffsetSameInstant = function withOffsetSameInstant(offset) {
          requireNonNull(offset, "offset");
          if (offset.equals(this._offset)) {
            return this;
          }
          var difference = offset.totalSeconds() - this._offset.totalSeconds();
          var adjusted = this._time.plusSeconds(difference);
          return new OffsetTime2(adjusted, offset);
        };
        _proto.withOffsetSameLocal = function withOffsetSameLocal(offset) {
          return offset != null && offset.equals(this._offset) ? this : new OffsetTime2(this._time, offset);
        };
        _proto._toEpochNano = function _toEpochNano() {
          var nod = this._time.toNanoOfDay();
          var offsetNanos = this._offset.totalSeconds() * LocalTime.NANOS_PER_SECOND;
          return nod - offsetNanos;
        };
        _proto._withAdjuster = function _withAdjuster(adjuster) {
          requireNonNull(adjuster, "adjuster");
          if (adjuster instanceof LocalTime) {
            return this._withLocalTimeOffset(adjuster, this._offset);
          } else if (adjuster instanceof ZoneOffset) {
            return this._withLocalTimeOffset(this._time, adjuster);
          } else if (adjuster instanceof OffsetTime2) {
            return adjuster;
          }
          return adjuster.adjustInto(this);
        };
        _proto._withField = function _withField(field, newValue) {
          requireNonNull(field, "field");
          if (field instanceof ChronoField) {
            if (field === ChronoField.OFFSET_SECONDS) {
              return this._withLocalTimeOffset(this._time, ZoneOffset.ofTotalSeconds(field.checkValidIntValue(newValue)));
            }
            return this._withLocalTimeOffset(this._time.with(field, newValue), this._offset);
          }
          return field.adjustInto(this, newValue);
        };
        _proto._withLocalTimeOffset = function _withLocalTimeOffset(time, offset) {
          if (this._time === time && this._offset.equals(offset)) {
            return this;
          }
          return new OffsetTime2(time, offset);
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          requireInstance(other, OffsetTime2, "other");
          if (this._offset.equals(other._offset)) {
            return this._time.compareTo(other._time);
          }
          var compare = MathUtil.compareNumbers(this._toEpochNano(), other._toEpochNano());
          if (compare === 0) {
            return this._time.compareTo(other._time);
          }
          return compare;
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof OffsetTime2) {
            return this._time.equals(other._time) && this._offset.equals(other._offset);
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          return this._time.hashCode() ^ this._offset.hashCode();
        };
        _proto.toString = function toString() {
          return this._time.toString() + this._offset.toString();
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        return OffsetTime2;
      }(Temporal);
      function _init$8() {
        OffsetTime.MIN = OffsetTime.ofNumbers(0, 0, 0, 0, ZoneOffset.MAX);
        OffsetTime.MAX = OffsetTime.ofNumbers(23, 59, 59, 999999999, ZoneOffset.MIN);
        OffsetTime.FROM = createTemporalQuery("OffsetTime.FROM", function(temporal) {
          return OffsetTime.from(temporal);
        });
      }
      var ChronoZonedDateTime = function(_Temporal) {
        _inheritsLoose(ChronoZonedDateTime2, _Temporal);
        function ChronoZonedDateTime2() {
          return _Temporal.apply(this, arguments) || this;
        }
        var _proto = ChronoZonedDateTime2.prototype;
        _proto.query = function query(_query) {
          if (_query === TemporalQueries.zoneId() || _query === TemporalQueries.zone()) {
            return this.zone();
          } else if (_query === TemporalQueries.chronology()) {
            return this.toLocalDate().chronology();
          } else if (_query === TemporalQueries.precision()) {
            return ChronoUnit.NANOS;
          } else if (_query === TemporalQueries.offset()) {
            return this.offset();
          } else if (_query === TemporalQueries.localDate()) {
            return LocalDate2.ofEpochDay(this.toLocalDate().toEpochDay());
          } else if (_query === TemporalQueries.localTime()) {
            return this.toLocalTime();
          }
          return _Temporal.prototype.query.call(this, _query);
        };
        _proto.format = function format(formatter) {
          requireNonNull(formatter, "formatter");
          return formatter.format(this);
        };
        _proto.toInstant = function toInstant() {
          return Instant.ofEpochSecond(this.toEpochSecond(), this.toLocalTime().nano());
        };
        _proto.toEpochSecond = function toEpochSecond() {
          var epochDay = this.toLocalDate().toEpochDay();
          var secs = epochDay * 86400 + this.toLocalTime().toSecondOfDay();
          secs -= this.offset().totalSeconds();
          return secs;
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          var cmp = MathUtil.compareNumbers(this.toEpochSecond(), other.toEpochSecond());
          if (cmp === 0) {
            cmp = this.toLocalTime().nano() - other.toLocalTime().nano();
            if (cmp === 0) {
              cmp = this.toLocalDateTime().compareTo(other.toLocalDateTime());
              if (cmp === 0) {
                cmp = strcmp(this.zone().id(), other.zone().id());
              }
            }
          }
          return cmp;
        };
        _proto.isAfter = function isAfter(other) {
          requireNonNull(other, "other");
          var thisEpochSec = this.toEpochSecond();
          var otherEpochSec = other.toEpochSecond();
          return thisEpochSec > otherEpochSec || thisEpochSec === otherEpochSec && this.toLocalTime().nano() > other.toLocalTime().nano();
        };
        _proto.isBefore = function isBefore(other) {
          requireNonNull(other, "other");
          var thisEpochSec = this.toEpochSecond();
          var otherEpochSec = other.toEpochSecond();
          return thisEpochSec < otherEpochSec || thisEpochSec === otherEpochSec && this.toLocalTime().nano() < other.toLocalTime().nano();
        };
        _proto.isEqual = function isEqual(other) {
          requireNonNull(other, "other");
          return this.toEpochSecond() === other.toEpochSecond() && this.toLocalTime().nano() === other.toLocalTime().nano();
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof ChronoZonedDateTime2) {
            return this.compareTo(other) === 0;
          }
          return false;
        };
        return ChronoZonedDateTime2;
      }(Temporal);
      function strcmp(a, b) {
        if (a < b) {
          return -1;
        }
        if (a > b) {
          return 1;
        }
        return 0;
      }
      var ZonedDateTime2 = function(_ChronoZonedDateTime) {
        _inheritsLoose(ZonedDateTime3, _ChronoZonedDateTime);
        ZonedDateTime3.now = function now(clockOrZone) {
          var clock;
          if (clockOrZone instanceof ZoneId2) {
            clock = Clock.system(clockOrZone);
          } else {
            clock = clockOrZone == null ? Clock.systemDefaultZone() : clockOrZone;
          }
          return ZonedDateTime3.ofInstant(clock.instant(), clock.zone());
        };
        ZonedDateTime3.of = function of() {
          if (arguments.length <= 2) {
            return ZonedDateTime3.of2.apply(this, arguments);
          } else if (arguments.length === 3 && arguments[0] instanceof LocalDate2) {
            return ZonedDateTime3.of3.apply(this, arguments);
          } else {
            return ZonedDateTime3.of8.apply(this, arguments);
          }
        };
        ZonedDateTime3.of3 = function of3(date, time, zone) {
          return ZonedDateTime3.of2(LocalDateTime.of(date, time), zone);
        };
        ZonedDateTime3.of2 = function of2(localDateTime, zone) {
          return ZonedDateTime3.ofLocal(localDateTime, zone, null);
        };
        ZonedDateTime3.of8 = function of8(year, month, dayOfMonth, hour, minute, second, nanoOfSecond, zone) {
          var dt = LocalDateTime.of(year, month, dayOfMonth, hour, minute, second, nanoOfSecond);
          return ZonedDateTime3.ofLocal(dt, zone, null);
        };
        ZonedDateTime3.ofLocal = function ofLocal(localDateTime, zone, preferredOffset) {
          requireNonNull(localDateTime, "localDateTime");
          requireNonNull(zone, "zone");
          if (zone instanceof ZoneOffset) {
            return new ZonedDateTime3(localDateTime, zone, zone);
          }
          var offset = null;
          var rules = zone.rules();
          var validOffsets = rules.validOffsets(localDateTime);
          if (validOffsets.length === 1) {
            offset = validOffsets[0];
          } else if (validOffsets.length === 0) {
            var trans = rules.transition(localDateTime);
            localDateTime = localDateTime.plusSeconds(trans.duration().seconds());
            offset = trans.offsetAfter();
          } else {
            if (preferredOffset != null && validOffsets.some(function(validOffset) {
              return validOffset.equals(preferredOffset);
            })) {
              offset = preferredOffset;
            } else {
              offset = requireNonNull(validOffsets[0], "offset");
            }
          }
          return new ZonedDateTime3(localDateTime, offset, zone);
        };
        ZonedDateTime3.ofInstant = function ofInstant() {
          if (arguments.length === 2) {
            return ZonedDateTime3.ofInstant2.apply(this, arguments);
          } else {
            return ZonedDateTime3.ofInstant3.apply(this, arguments);
          }
        };
        ZonedDateTime3.ofInstant2 = function ofInstant2(instant, zone) {
          requireNonNull(instant, "instant");
          requireNonNull(zone, "zone");
          return ZonedDateTime3._create(instant.epochSecond(), instant.nano(), zone);
        };
        ZonedDateTime3.ofInstant3 = function ofInstant3(localDateTime, offset, zone) {
          requireNonNull(localDateTime, "localDateTime");
          requireNonNull(offset, "offset");
          requireNonNull(zone, "zone");
          return ZonedDateTime3._create(localDateTime.toEpochSecond(offset), localDateTime.nano(), zone);
        };
        ZonedDateTime3._create = function _create(epochSecond, nanoOfSecond, zone) {
          var rules = zone.rules();
          var instant = Instant.ofEpochSecond(epochSecond, nanoOfSecond);
          var offset = rules.offset(instant);
          var ldt = LocalDateTime.ofEpochSecond(epochSecond, nanoOfSecond, offset);
          return new ZonedDateTime3(ldt, offset, zone);
        };
        ZonedDateTime3.ofStrict = function ofStrict(localDateTime, offset, zone) {
          requireNonNull(localDateTime, "localDateTime");
          requireNonNull(offset, "offset");
          requireNonNull(zone, "zone");
          var rules = zone.rules();
          if (rules.isValidOffset(localDateTime, offset) === false) {
            var trans = rules.transition(localDateTime);
            if (trans != null && trans.isGap()) {
              throw new DateTimeException("LocalDateTime " + localDateTime + " does not exist in zone " + zone + " due to a gap in the local time-line, typically caused by daylight savings");
            }
            throw new DateTimeException('ZoneOffset "' + offset + '" is not valid for LocalDateTime "' + localDateTime + '" in zone "' + zone + '"');
          }
          return new ZonedDateTime3(localDateTime, offset, zone);
        };
        ZonedDateTime3.ofLenient = function ofLenient(localDateTime, offset, zone) {
          requireNonNull(localDateTime, "localDateTime");
          requireNonNull(offset, "offset");
          requireNonNull(zone, "zone");
          if (zone instanceof ZoneOffset && offset.equals(zone) === false) {
            throw new IllegalArgumentException("ZoneId must match ZoneOffset");
          }
          return new ZonedDateTime3(localDateTime, offset, zone);
        };
        ZonedDateTime3.from = function from(temporal) {
          requireNonNull(temporal, "temporal");
          if (temporal instanceof ZonedDateTime3) {
            return temporal;
          }
          var zone = ZoneId2.from(temporal);
          if (temporal.isSupported(ChronoField.INSTANT_SECONDS)) {
            var zdt = ZonedDateTime3._from(temporal, zone);
            if (zdt != null)
              return zdt;
          }
          var ldt = LocalDateTime.from(temporal);
          return ZonedDateTime3.of2(ldt, zone);
        };
        ZonedDateTime3._from = function _from(temporal, zone) {
          try {
            return ZonedDateTime3.__from(temporal, zone);
          } catch (ex) {
            if (!(ex instanceof DateTimeException))
              throw ex;
          }
        };
        ZonedDateTime3.__from = function __from(temporal, zone) {
          var epochSecond = temporal.getLong(ChronoField.INSTANT_SECONDS);
          var nanoOfSecond = temporal.get(ChronoField.NANO_OF_SECOND);
          return ZonedDateTime3._create(epochSecond, nanoOfSecond, zone);
        };
        ZonedDateTime3.parse = function parse(text, formatter) {
          if (formatter === void 0) {
            formatter = DateTimeFormatter.ISO_ZONED_DATE_TIME;
          }
          requireNonNull(formatter, "formatter");
          return formatter.parse(text, ZonedDateTime3.FROM);
        };
        function ZonedDateTime3(dateTime, offset, zone) {
          var _this;
          requireNonNull(dateTime, "dateTime");
          requireNonNull(offset, "offset");
          requireNonNull(zone, "zone");
          _this = _ChronoZonedDateTime.call(this) || this;
          _this._dateTime = dateTime;
          _this._offset = offset;
          _this._zone = zone;
          return _this;
        }
        var _proto = ZonedDateTime3.prototype;
        _proto._resolveLocal = function _resolveLocal(newDateTime) {
          requireNonNull(newDateTime, "newDateTime");
          return ZonedDateTime3.ofLocal(newDateTime, this._zone, this._offset);
        };
        _proto._resolveInstant = function _resolveInstant(newDateTime) {
          return ZonedDateTime3.ofInstant3(newDateTime, this._offset, this._zone);
        };
        _proto._resolveOffset = function _resolveOffset(offset) {
          if (offset.equals(this._offset) === false && this._zone.rules().isValidOffset(this._dateTime, offset)) {
            return new ZonedDateTime3(this._dateTime, offset, this._zone);
          }
          return this;
        };
        _proto.isSupported = function isSupported(fieldOrUnit) {
          if (fieldOrUnit instanceof ChronoField) {
            return true;
          } else if (fieldOrUnit instanceof ChronoUnit) {
            return fieldOrUnit.isDateBased() || fieldOrUnit.isTimeBased();
          }
          return fieldOrUnit != null && fieldOrUnit.isSupportedBy(this);
        };
        _proto.range = function range(field) {
          if (field instanceof ChronoField) {
            if (field === ChronoField.INSTANT_SECONDS || field === ChronoField.OFFSET_SECONDS) {
              return field.range();
            }
            return this._dateTime.range(field);
          }
          return field.rangeRefinedBy(this);
        };
        _proto.get = function get(field) {
          return this.getLong(field);
        };
        _proto.getLong = function getLong(field) {
          if (field instanceof ChronoField) {
            switch (field) {
              case ChronoField.INSTANT_SECONDS:
                return this.toEpochSecond();
              case ChronoField.OFFSET_SECONDS:
                return this._offset.totalSeconds();
            }
            return this._dateTime.getLong(field);
          }
          requireNonNull(field, "field");
          return field.getFrom(this);
        };
        _proto.offset = function offset() {
          return this._offset;
        };
        _proto.withEarlierOffsetAtOverlap = function withEarlierOffsetAtOverlap() {
          var trans = this._zone.rules().transition(this._dateTime);
          if (trans != null && trans.isOverlap()) {
            var earlierOffset = trans.offsetBefore();
            if (earlierOffset.equals(this._offset) === false) {
              return new ZonedDateTime3(this._dateTime, earlierOffset, this._zone);
            }
          }
          return this;
        };
        _proto.withLaterOffsetAtOverlap = function withLaterOffsetAtOverlap() {
          var trans = this._zone.rules().transition(this.toLocalDateTime());
          if (trans != null) {
            var laterOffset = trans.offsetAfter();
            if (laterOffset.equals(this._offset) === false) {
              return new ZonedDateTime3(this._dateTime, laterOffset, this._zone);
            }
          }
          return this;
        };
        _proto.zone = function zone() {
          return this._zone;
        };
        _proto.withZoneSameLocal = function withZoneSameLocal(zone) {
          requireNonNull(zone, "zone");
          return this._zone.equals(zone) ? this : ZonedDateTime3.ofLocal(this._dateTime, zone, this._offset);
        };
        _proto.withZoneSameInstant = function withZoneSameInstant(zone) {
          requireNonNull(zone, "zone");
          return this._zone.equals(zone) ? this : ZonedDateTime3._create(this._dateTime.toEpochSecond(this._offset), this._dateTime.nano(), zone);
        };
        _proto.withFixedOffsetZone = function withFixedOffsetZone() {
          return this._zone.equals(this._offset) ? this : new ZonedDateTime3(this._dateTime, this._offset, this._offset);
        };
        _proto.year = function year() {
          return this._dateTime.year();
        };
        _proto.monthValue = function monthValue() {
          return this._dateTime.monthValue();
        };
        _proto.month = function month() {
          return this._dateTime.month();
        };
        _proto.dayOfMonth = function dayOfMonth() {
          return this._dateTime.dayOfMonth();
        };
        _proto.dayOfYear = function dayOfYear() {
          return this._dateTime.dayOfYear();
        };
        _proto.dayOfWeek = function dayOfWeek() {
          return this._dateTime.dayOfWeek();
        };
        _proto.hour = function hour() {
          return this._dateTime.hour();
        };
        _proto.minute = function minute() {
          return this._dateTime.minute();
        };
        _proto.second = function second() {
          return this._dateTime.second();
        };
        _proto.nano = function nano() {
          return this._dateTime.nano();
        };
        _proto._withAdjuster = function _withAdjuster(adjuster) {
          if (adjuster instanceof LocalDate2) {
            return this._resolveLocal(LocalDateTime.of(adjuster, this._dateTime.toLocalTime()));
          } else if (adjuster instanceof LocalTime) {
            return this._resolveLocal(LocalDateTime.of(this._dateTime.toLocalDate(), adjuster));
          } else if (adjuster instanceof LocalDateTime) {
            return this._resolveLocal(adjuster);
          } else if (adjuster instanceof Instant) {
            var instant = adjuster;
            return ZonedDateTime3._create(instant.epochSecond(), instant.nano(), this._zone);
          } else if (adjuster instanceof ZoneOffset) {
            return this._resolveOffset(adjuster);
          }
          return _ChronoZonedDateTime.prototype._withAdjuster.call(this, adjuster);
        };
        _proto._withField = function _withField(field, newValue) {
          if (field instanceof ChronoField) {
            switch (field) {
              case ChronoField.INSTANT_SECONDS:
                return ZonedDateTime3._create(newValue, this.nano(), this._zone);
              case ChronoField.OFFSET_SECONDS: {
                var offset = ZoneOffset.ofTotalSeconds(field.checkValidIntValue(newValue));
                return this._resolveOffset(offset);
              }
            }
            return this._resolveLocal(this._dateTime.with(field, newValue));
          }
          return field.adjustInto(this, newValue);
        };
        _proto.withYear = function withYear(year) {
          return this._resolveLocal(this._dateTime.withYear(year));
        };
        _proto.withMonth = function withMonth(month) {
          return this._resolveLocal(this._dateTime.withMonth(month));
        };
        _proto.withDayOfMonth = function withDayOfMonth(dayOfMonth) {
          return this._resolveLocal(this._dateTime.withDayOfMonth(dayOfMonth));
        };
        _proto.withDayOfYear = function withDayOfYear(dayOfYear) {
          return this._resolveLocal(this._dateTime.withDayOfYear(dayOfYear));
        };
        _proto.withHour = function withHour(hour) {
          return this._resolveLocal(this._dateTime.withHour(hour));
        };
        _proto.withMinute = function withMinute(minute) {
          return this._resolveLocal(this._dateTime.withMinute(minute));
        };
        _proto.withSecond = function withSecond(second) {
          return this._resolveLocal(this._dateTime.withSecond(second));
        };
        _proto.withNano = function withNano(nanoOfSecond) {
          return this._resolveLocal(this._dateTime.withNano(nanoOfSecond));
        };
        _proto.truncatedTo = function truncatedTo(unit) {
          return this._resolveLocal(this._dateTime.truncatedTo(unit));
        };
        _proto._plusUnit = function _plusUnit(amountToAdd, unit) {
          if (unit instanceof ChronoUnit) {
            if (unit.isDateBased()) {
              return this._resolveLocal(this._dateTime.plus(amountToAdd, unit));
            } else {
              return this._resolveInstant(this._dateTime.plus(amountToAdd, unit));
            }
          }
          requireNonNull(unit, "unit");
          return unit.addTo(this, amountToAdd);
        };
        _proto.plusYears = function plusYears(years) {
          return this._resolveLocal(this._dateTime.plusYears(years));
        };
        _proto.plusMonths = function plusMonths(months) {
          return this._resolveLocal(this._dateTime.plusMonths(months));
        };
        _proto.plusWeeks = function plusWeeks(weeks) {
          return this._resolveLocal(this._dateTime.plusWeeks(weeks));
        };
        _proto.plusDays = function plusDays(days) {
          return this._resolveLocal(this._dateTime.plusDays(days));
        };
        _proto.plusHours = function plusHours(hours) {
          return this._resolveInstant(this._dateTime.plusHours(hours));
        };
        _proto.plusMinutes = function plusMinutes(minutes) {
          return this._resolveInstant(this._dateTime.plusMinutes(minutes));
        };
        _proto.plusSeconds = function plusSeconds(seconds) {
          return this._resolveInstant(this._dateTime.plusSeconds(seconds));
        };
        _proto.plusNanos = function plusNanos(nanos) {
          return this._resolveInstant(this._dateTime.plusNanos(nanos));
        };
        _proto._minusUnit = function _minusUnit(amountToSubtract, unit) {
          return this._plusUnit(-1 * amountToSubtract, unit);
        };
        _proto.minusYears = function minusYears(years) {
          return this.plusYears(-1 * years);
        };
        _proto.minusMonths = function minusMonths(months) {
          return this.plusMonths(-1 * months);
        };
        _proto.minusWeeks = function minusWeeks(weeks) {
          return this.plusWeeks(-1 * weeks);
        };
        _proto.minusDays = function minusDays(days) {
          return this.plusDays(-1 * days);
        };
        _proto.minusHours = function minusHours(hours) {
          return this.plusHours(-1 * hours);
        };
        _proto.minusMinutes = function minusMinutes(minutes) {
          return this.plusMinutes(-1 * minutes);
        };
        _proto.minusSeconds = function minusSeconds(seconds) {
          return this.plusSeconds(-1 * seconds);
        };
        _proto.minusNanos = function minusNanos(nanos) {
          return this.plusNanos(-1 * nanos);
        };
        _proto.query = function query(_query) {
          if (_query === TemporalQueries.localDate()) {
            return this.toLocalDate();
          }
          requireNonNull(_query, "query");
          return _ChronoZonedDateTime.prototype.query.call(this, _query);
        };
        _proto.until = function until(endExclusive, unit) {
          var end = ZonedDateTime3.from(endExclusive);
          if (unit instanceof ChronoUnit) {
            end = end.withZoneSameInstant(this._zone);
            if (unit.isDateBased()) {
              return this._dateTime.until(end._dateTime, unit);
            } else {
              var difference = this._offset.totalSeconds() - end._offset.totalSeconds();
              var adjustedEnd = end._dateTime.plusSeconds(difference);
              return this._dateTime.until(adjustedEnd, unit);
            }
          }
          return unit.between(this, end);
        };
        _proto.toLocalDateTime = function toLocalDateTime() {
          return this._dateTime;
        };
        _proto.toLocalDate = function toLocalDate() {
          return this._dateTime.toLocalDate();
        };
        _proto.toLocalTime = function toLocalTime() {
          return this._dateTime.toLocalTime();
        };
        _proto.toOffsetDateTime = function toOffsetDateTime() {
          return OffsetDateTime.of(this._dateTime, this._offset);
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof ZonedDateTime3) {
            return this._dateTime.equals(other._dateTime) && this._offset.equals(other._offset) && this._zone.equals(other._zone);
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          return MathUtil.hashCode(this._dateTime.hashCode(), this._offset.hashCode(), this._zone.hashCode());
        };
        _proto.toString = function toString() {
          var str = this._dateTime.toString() + this._offset.toString();
          if (this._offset !== this._zone) {
            str += "[" + this._zone.toString() + "]";
          }
          return str;
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        _proto.format = function format(formatter) {
          return _ChronoZonedDateTime.prototype.format.call(this, formatter);
        };
        return ZonedDateTime3;
      }(ChronoZonedDateTime);
      function _init$7() {
        ZonedDateTime2.FROM = createTemporalQuery("ZonedDateTime.FROM", function(temporal) {
          return ZonedDateTime2.from(temporal);
        });
      }
      var OffsetDateTime = function(_Temporal) {
        _inheritsLoose(OffsetDateTime2, _Temporal);
        OffsetDateTime2.from = function from(temporal) {
          requireNonNull(temporal, "temporal");
          if (temporal instanceof OffsetDateTime2) {
            return temporal;
          }
          try {
            var offset = ZoneOffset.from(temporal);
            try {
              var ldt = LocalDateTime.from(temporal);
              return OffsetDateTime2.of(ldt, offset);
            } catch (_2) {
              var instant = Instant.from(temporal);
              return OffsetDateTime2.ofInstant(instant, offset);
            }
          } catch (ex) {
            throw new DateTimeException("Unable to obtain OffsetDateTime TemporalAccessor: " + temporal + ", type " + (temporal.constructor != null ? temporal.constructor.name : ""));
          }
        };
        OffsetDateTime2.now = function now(clockOrZone) {
          if (arguments.length === 0) {
            return OffsetDateTime2.now(Clock.systemDefaultZone());
          } else {
            requireNonNull(clockOrZone, "clockOrZone");
            if (clockOrZone instanceof ZoneId2) {
              return OffsetDateTime2.now(Clock.system(clockOrZone));
            } else if (clockOrZone instanceof Clock) {
              var now2 = clockOrZone.instant();
              return OffsetDateTime2.ofInstant(now2, clockOrZone.zone().rules().offset(now2));
            } else {
              throw new IllegalArgumentException("clockOrZone must be an instance of ZoneId or Clock");
            }
          }
        };
        OffsetDateTime2.of = function of() {
          if (arguments.length <= 2) {
            return OffsetDateTime2.ofDateTime.apply(this, arguments);
          } else if (arguments.length === 3) {
            return OffsetDateTime2.ofDateAndTime.apply(this, arguments);
          } else {
            return OffsetDateTime2.ofNumbers.apply(this, arguments);
          }
        };
        OffsetDateTime2.ofDateTime = function ofDateTime(dateTime, offset) {
          return new OffsetDateTime2(dateTime, offset);
        };
        OffsetDateTime2.ofDateAndTime = function ofDateAndTime(date, time, offset) {
          var dt = LocalDateTime.of(date, time);
          return new OffsetDateTime2(dt, offset);
        };
        OffsetDateTime2.ofNumbers = function ofNumbers(year, month, dayOfMonth, hour, minute, second, nanoOfSecond, offset) {
          if (hour === void 0) {
            hour = 0;
          }
          if (minute === void 0) {
            minute = 0;
          }
          if (second === void 0) {
            second = 0;
          }
          if (nanoOfSecond === void 0) {
            nanoOfSecond = 0;
          }
          var dt = LocalDateTime.of(year, month, dayOfMonth, hour, minute, second, nanoOfSecond);
          return new OffsetDateTime2(dt, offset);
        };
        OffsetDateTime2.ofInstant = function ofInstant(instant, zone) {
          requireNonNull(instant, "instant");
          requireNonNull(zone, "zone");
          var rules = zone.rules();
          var offset = rules.offset(instant);
          var ldt = LocalDateTime.ofEpochSecond(instant.epochSecond(), instant.nano(), offset);
          return new OffsetDateTime2(ldt, offset);
        };
        OffsetDateTime2.parse = function parse(text, formatter) {
          if (formatter === void 0) {
            formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
          }
          requireNonNull(formatter, "formatter");
          return formatter.parse(text, OffsetDateTime2.FROM);
        };
        function OffsetDateTime2(dateTime, offset) {
          var _this;
          _this = _Temporal.call(this) || this;
          requireNonNull(dateTime, "dateTime");
          requireInstance(dateTime, LocalDateTime, "dateTime");
          requireNonNull(offset, "offset");
          requireInstance(offset, ZoneOffset, "offset");
          _this._dateTime = dateTime;
          _this._offset = offset;
          return _this;
        }
        var _proto = OffsetDateTime2.prototype;
        _proto.adjustInto = function adjustInto(temporal) {
          return temporal.with(ChronoField.EPOCH_DAY, this.toLocalDate().toEpochDay()).with(ChronoField.NANO_OF_DAY, this.toLocalTime().toNanoOfDay()).with(ChronoField.OFFSET_SECONDS, this.offset().totalSeconds());
        };
        _proto.until = function until(endExclusive, unit) {
          var end = OffsetDateTime2.from(endExclusive);
          if (unit instanceof ChronoUnit) {
            end = end.withOffsetSameInstant(this._offset);
            return this._dateTime.until(end._dateTime, unit);
          }
          return unit.between(this, end);
        };
        _proto.atZoneSameInstant = function atZoneSameInstant(zone) {
          return ZonedDateTime2.ofInstant(this._dateTime, this._offset, zone);
        };
        _proto.atZoneSimilarLocal = function atZoneSimilarLocal(zone) {
          return ZonedDateTime2.ofLocal(this._dateTime, zone, this._offset);
        };
        _proto.query = function query(_query) {
          requireNonNull(_query, "query");
          if (_query === TemporalQueries.chronology()) {
            return IsoChronology.INSTANCE;
          } else if (_query === TemporalQueries.precision()) {
            return ChronoUnit.NANOS;
          } else if (_query === TemporalQueries.offset() || _query === TemporalQueries.zone()) {
            return this.offset();
          } else if (_query === TemporalQueries.localDate()) {
            return this.toLocalDate();
          } else if (_query === TemporalQueries.localTime()) {
            return this.toLocalTime();
          } else if (_query === TemporalQueries.zoneId()) {
            return null;
          }
          return _Temporal.prototype.query.call(this, _query);
        };
        _proto.get = function get(field) {
          if (field instanceof ChronoField) {
            switch (field) {
              case ChronoField.INSTANT_SECONDS:
                throw new DateTimeException("Field too large for an int: " + field);
              case ChronoField.OFFSET_SECONDS:
                return this.offset().totalSeconds();
            }
            return this._dateTime.get(field);
          }
          return _Temporal.prototype.get.call(this, field);
        };
        _proto.getLong = function getLong(field) {
          if (field instanceof ChronoField) {
            switch (field) {
              case ChronoField.INSTANT_SECONDS:
                return this.toEpochSecond();
              case ChronoField.OFFSET_SECONDS:
                return this.offset().totalSeconds();
            }
            return this._dateTime.getLong(field);
          }
          return field.getFrom(this);
        };
        _proto.offset = function offset() {
          return this._offset;
        };
        _proto.year = function year() {
          return this._dateTime.year();
        };
        _proto.monthValue = function monthValue() {
          return this._dateTime.monthValue();
        };
        _proto.month = function month() {
          return this._dateTime.month();
        };
        _proto.dayOfMonth = function dayOfMonth() {
          return this._dateTime.dayOfMonth();
        };
        _proto.dayOfYear = function dayOfYear() {
          return this._dateTime.dayOfYear();
        };
        _proto.dayOfWeek = function dayOfWeek() {
          return this._dateTime.dayOfWeek();
        };
        _proto.hour = function hour() {
          return this._dateTime.hour();
        };
        _proto.minute = function minute() {
          return this._dateTime.minute();
        };
        _proto.second = function second() {
          return this._dateTime.second();
        };
        _proto.nano = function nano() {
          return this._dateTime.nano();
        };
        _proto.toLocalDateTime = function toLocalDateTime() {
          return this._dateTime;
        };
        _proto.toLocalDate = function toLocalDate() {
          return this._dateTime.toLocalDate();
        };
        _proto.toLocalTime = function toLocalTime() {
          return this._dateTime.toLocalTime();
        };
        _proto.toOffsetTime = function toOffsetTime() {
          return OffsetTime.of(this._dateTime.toLocalTime(), this._offset);
        };
        _proto.toZonedDateTime = function toZonedDateTime() {
          return ZonedDateTime2.of(this._dateTime, this._offset);
        };
        _proto.toInstant = function toInstant() {
          return this._dateTime.toInstant(this._offset);
        };
        _proto.toEpochSecond = function toEpochSecond() {
          return this._dateTime.toEpochSecond(this._offset);
        };
        _proto.isSupported = function isSupported(fieldOrUnit) {
          if (fieldOrUnit instanceof ChronoField) {
            return fieldOrUnit.isDateBased() || fieldOrUnit.isTimeBased();
          }
          if (fieldOrUnit instanceof ChronoUnit) {
            return fieldOrUnit.isDateBased() || fieldOrUnit.isTimeBased();
          }
          return fieldOrUnit != null && fieldOrUnit.isSupportedBy(this);
        };
        _proto.range = function range(field) {
          if (field instanceof ChronoField) {
            if (field === ChronoField.INSTANT_SECONDS || field === ChronoField.OFFSET_SECONDS) {
              return field.range();
            }
            return this._dateTime.range(field);
          }
          return field.rangeRefinedBy(this);
        };
        _proto._withAdjuster = function _withAdjuster(adjuster) {
          requireNonNull(adjuster);
          if (adjuster instanceof LocalDate2 || adjuster instanceof LocalTime || adjuster instanceof LocalDateTime) {
            return this._withDateTimeOffset(this._dateTime.with(adjuster), this._offset);
          } else if (adjuster instanceof Instant) {
            return OffsetDateTime2.ofInstant(adjuster, this._offset);
          } else if (adjuster instanceof ZoneOffset) {
            return this._withDateTimeOffset(this._dateTime, adjuster);
          } else if (adjuster instanceof OffsetDateTime2) {
            return adjuster;
          }
          return adjuster.adjustInto(this);
        };
        _proto._withField = function _withField(field, newValue) {
          requireNonNull(field);
          if (field instanceof ChronoField) {
            var f = field;
            switch (f) {
              case ChronoField.INSTANT_SECONDS:
                return OffsetDateTime2.ofInstant(Instant.ofEpochSecond(newValue, this.nano()), this._offset);
              case ChronoField.OFFSET_SECONDS: {
                return this._withDateTimeOffset(this._dateTime, ZoneOffset.ofTotalSeconds(f.checkValidIntValue(newValue)));
              }
            }
            return this._withDateTimeOffset(this._dateTime.with(field, newValue), this._offset);
          }
          return field.adjustInto(this, newValue);
        };
        _proto._withDateTimeOffset = function _withDateTimeOffset(dateTime, offset) {
          if (this._dateTime === dateTime && this._offset.equals(offset)) {
            return this;
          }
          return new OffsetDateTime2(dateTime, offset);
        };
        _proto.withYear = function withYear(year) {
          return this._withDateTimeOffset(this._dateTime.withYear(year), this._offset);
        };
        _proto.withMonth = function withMonth(month) {
          return this._withDateTimeOffset(this._dateTime.withMonth(month), this._offset);
        };
        _proto.withDayOfMonth = function withDayOfMonth(dayOfMonth) {
          return this._withDateTimeOffset(this._dateTime.withDayOfMonth(dayOfMonth), this._offset);
        };
        _proto.withDayOfYear = function withDayOfYear(dayOfYear) {
          return this._withDateTimeOffset(this._dateTime.withDayOfYear(dayOfYear), this._offset);
        };
        _proto.withHour = function withHour(hour) {
          return this._withDateTimeOffset(this._dateTime.withHour(hour), this._offset);
        };
        _proto.withMinute = function withMinute(minute) {
          return this._withDateTimeOffset(this._dateTime.withMinute(minute), this._offset);
        };
        _proto.withSecond = function withSecond(second) {
          return this._withDateTimeOffset(this._dateTime.withSecond(second), this._offset);
        };
        _proto.withNano = function withNano(nanoOfSecond) {
          return this._withDateTimeOffset(this._dateTime.withNano(nanoOfSecond), this._offset);
        };
        _proto.withOffsetSameLocal = function withOffsetSameLocal(offset) {
          requireNonNull(offset, "offset");
          return this._withDateTimeOffset(this._dateTime, offset);
        };
        _proto.withOffsetSameInstant = function withOffsetSameInstant(offset) {
          requireNonNull(offset, "offset");
          if (offset.equals(this._offset)) {
            return this;
          }
          var difference = offset.totalSeconds() - this._offset.totalSeconds();
          var adjusted = this._dateTime.plusSeconds(difference);
          return new OffsetDateTime2(adjusted, offset);
        };
        _proto.truncatedTo = function truncatedTo(unit) {
          return this._withDateTimeOffset(this._dateTime.truncatedTo(unit), this._offset);
        };
        _proto._plusAmount = function _plusAmount(amount) {
          requireNonNull(amount, "amount");
          return amount.addTo(this);
        };
        _proto._plusUnit = function _plusUnit(amountToAdd, unit) {
          if (unit instanceof ChronoUnit) {
            return this._withDateTimeOffset(this._dateTime.plus(amountToAdd, unit), this._offset);
          }
          return unit.addTo(this, amountToAdd);
        };
        _proto.plusYears = function plusYears(years) {
          return this._withDateTimeOffset(this._dateTime.plusYears(years), this._offset);
        };
        _proto.plusMonths = function plusMonths(months) {
          return this._withDateTimeOffset(this._dateTime.plusMonths(months), this._offset);
        };
        _proto.plusWeeks = function plusWeeks(weeks) {
          return this._withDateTimeOffset(this._dateTime.plusWeeks(weeks), this._offset);
        };
        _proto.plusDays = function plusDays(days) {
          return this._withDateTimeOffset(this._dateTime.plusDays(days), this._offset);
        };
        _proto.plusHours = function plusHours(hours) {
          return this._withDateTimeOffset(this._dateTime.plusHours(hours), this._offset);
        };
        _proto.plusMinutes = function plusMinutes(minutes) {
          return this._withDateTimeOffset(this._dateTime.plusMinutes(minutes), this._offset);
        };
        _proto.plusSeconds = function plusSeconds(seconds) {
          return this._withDateTimeOffset(this._dateTime.plusSeconds(seconds), this._offset);
        };
        _proto.plusNanos = function plusNanos(nanos) {
          return this._withDateTimeOffset(this._dateTime.plusNanos(nanos), this._offset);
        };
        _proto._minusAmount = function _minusAmount(amount) {
          requireNonNull(amount);
          return amount.subtractFrom(this);
        };
        _proto._minusUnit = function _minusUnit(amountToSubtract, unit) {
          return this.plus(-1 * amountToSubtract, unit);
        };
        _proto.minusYears = function minusYears(years) {
          return this._withDateTimeOffset(this._dateTime.minusYears(years), this._offset);
        };
        _proto.minusMonths = function minusMonths(months) {
          return this._withDateTimeOffset(this._dateTime.minusMonths(months), this._offset);
        };
        _proto.minusWeeks = function minusWeeks(weeks) {
          return this._withDateTimeOffset(this._dateTime.minusWeeks(weeks), this._offset);
        };
        _proto.minusDays = function minusDays(days) {
          return this._withDateTimeOffset(this._dateTime.minusDays(days), this._offset);
        };
        _proto.minusHours = function minusHours(hours) {
          return this._withDateTimeOffset(this._dateTime.minusHours(hours), this._offset);
        };
        _proto.minusMinutes = function minusMinutes(minutes) {
          return this._withDateTimeOffset(this._dateTime.minusMinutes(minutes), this._offset);
        };
        _proto.minusSeconds = function minusSeconds(seconds) {
          return this._withDateTimeOffset(this._dateTime.minusSeconds(seconds), this._offset);
        };
        _proto.minusNanos = function minusNanos(nanos) {
          return this._withDateTimeOffset(this._dateTime.minusNanos(nanos), this._offset);
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          requireInstance(other, OffsetDateTime2, "other");
          if (this.offset().equals(other.offset())) {
            return this.toLocalDateTime().compareTo(other.toLocalDateTime());
          }
          var cmp = MathUtil.compareNumbers(this.toEpochSecond(), other.toEpochSecond());
          if (cmp === 0) {
            cmp = this.toLocalTime().nano() - other.toLocalTime().nano();
            if (cmp === 0) {
              cmp = this.toLocalDateTime().compareTo(other.toLocalDateTime());
            }
          }
          return cmp;
        };
        _proto.isAfter = function isAfter(other) {
          requireNonNull(other, "other");
          var thisEpochSec = this.toEpochSecond();
          var otherEpochSec = other.toEpochSecond();
          return thisEpochSec > otherEpochSec || thisEpochSec === otherEpochSec && this.toLocalTime().nano() > other.toLocalTime().nano();
        };
        _proto.isBefore = function isBefore(other) {
          requireNonNull(other, "other");
          var thisEpochSec = this.toEpochSecond();
          var otherEpochSec = other.toEpochSecond();
          return thisEpochSec < otherEpochSec || thisEpochSec === otherEpochSec && this.toLocalTime().nano() < other.toLocalTime().nano();
        };
        _proto.isEqual = function isEqual(other) {
          requireNonNull(other, "other");
          return this.toEpochSecond() === other.toEpochSecond() && this.toLocalTime().nano() === other.toLocalTime().nano();
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof OffsetDateTime2) {
            return this._dateTime.equals(other._dateTime) && this._offset.equals(other._offset);
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          return this._dateTime.hashCode() ^ this._offset.hashCode();
        };
        _proto.toString = function toString() {
          return this._dateTime.toString() + this._offset.toString();
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        _proto.format = function format(formatter) {
          requireNonNull(formatter, "formatter");
          return formatter.format(this);
        };
        return OffsetDateTime2;
      }(Temporal);
      function _init$6() {
        OffsetDateTime.MIN = LocalDateTime.MIN.atOffset(ZoneOffset.MAX);
        OffsetDateTime.MAX = LocalDateTime.MAX.atOffset(ZoneOffset.MIN);
        OffsetDateTime.FROM = createTemporalQuery("OffsetDateTime.FROM", function(temporal) {
          return OffsetDateTime.from(temporal);
        });
      }
      var DAYS_PER_CYCLE = 146097;
      var DAYS_0000_TO_1970 = DAYS_PER_CYCLE * 5 - (30 * 365 + 7);
      var LocalDate2 = function(_ChronoLocalDate) {
        _inheritsLoose(LocalDate3, _ChronoLocalDate);
        LocalDate3.now = function now(clockOrZone) {
          var clock;
          if (clockOrZone == null) {
            clock = Clock.systemDefaultZone();
          } else if (clockOrZone instanceof ZoneId2) {
            clock = Clock.system(clockOrZone);
          } else {
            clock = clockOrZone;
          }
          return LocalDate3.ofInstant(clock.instant(), clock.zone());
        };
        LocalDate3.ofInstant = function ofInstant(instant, zone) {
          if (zone === void 0) {
            zone = ZoneId2.systemDefault();
          }
          requireNonNull(instant, "instant");
          var offset = zone.rules().offset(instant);
          var epochSec = instant.epochSecond() + offset.totalSeconds();
          var epochDay = MathUtil.floorDiv(epochSec, LocalTime.SECONDS_PER_DAY);
          return LocalDate3.ofEpochDay(epochDay);
        };
        LocalDate3.of = function of(year, month, dayOfMonth) {
          return new LocalDate3(year, month, dayOfMonth);
        };
        LocalDate3.ofYearDay = function ofYearDay(year, dayOfYear) {
          ChronoField.YEAR.checkValidValue(year);
          var leap = IsoChronology.isLeapYear(year);
          if (dayOfYear === 366 && leap === false) {
            assert3(false, "Invalid date 'DayOfYear 366' as '" + year + "' is not a leap year", DateTimeException);
          }
          var moy = Month.of(Math.floor((dayOfYear - 1) / 31 + 1));
          var monthEnd = moy.firstDayOfYear(leap) + moy.length(leap) - 1;
          if (dayOfYear > monthEnd) {
            moy = moy.plus(1);
          }
          var dom = dayOfYear - moy.firstDayOfYear(leap) + 1;
          return new LocalDate3(year, moy.value(), dom);
        };
        LocalDate3.ofEpochDay = function ofEpochDay(epochDay) {
          if (epochDay === void 0) {
            epochDay = 0;
          }
          var adjust, adjustCycles, doyEst, yearEst, zeroDay;
          zeroDay = epochDay + DAYS_0000_TO_1970;
          zeroDay -= 60;
          adjust = 0;
          if (zeroDay < 0) {
            adjustCycles = MathUtil.intDiv(zeroDay + 1, DAYS_PER_CYCLE) - 1;
            adjust = adjustCycles * 400;
            zeroDay += -adjustCycles * DAYS_PER_CYCLE;
          }
          yearEst = MathUtil.intDiv(400 * zeroDay + 591, DAYS_PER_CYCLE);
          doyEst = zeroDay - (365 * yearEst + MathUtil.intDiv(yearEst, 4) - MathUtil.intDiv(yearEst, 100) + MathUtil.intDiv(yearEst, 400));
          if (doyEst < 0) {
            yearEst--;
            doyEst = zeroDay - (365 * yearEst + MathUtil.intDiv(yearEst, 4) - MathUtil.intDiv(yearEst, 100) + MathUtil.intDiv(yearEst, 400));
          }
          yearEst += adjust;
          var marchDoy0 = doyEst;
          var marchMonth0 = MathUtil.intDiv(marchDoy0 * 5 + 2, 153);
          var month = (marchMonth0 + 2) % 12 + 1;
          var dom = marchDoy0 - MathUtil.intDiv(marchMonth0 * 306 + 5, 10) + 1;
          yearEst += MathUtil.intDiv(marchMonth0, 10);
          var year = yearEst;
          return new LocalDate3(year, month, dom);
        };
        LocalDate3.from = function from(temporal) {
          requireNonNull(temporal, "temporal");
          var date = temporal.query(TemporalQueries.localDate());
          if (date == null) {
            throw new DateTimeException("Unable to obtain LocalDate from TemporalAccessor: " + temporal + ", type " + (temporal.constructor != null ? temporal.constructor.name : ""));
          }
          return date;
        };
        LocalDate3.parse = function parse(text, formatter) {
          if (formatter === void 0) {
            formatter = DateTimeFormatter.ISO_LOCAL_DATE;
          }
          assert3(formatter != null, "formatter", NullPointerException);
          return formatter.parse(text, LocalDate3.FROM);
        };
        LocalDate3._resolvePreviousValid = function _resolvePreviousValid(year, month, day) {
          switch (month) {
            case 2:
              day = Math.min(day, IsoChronology.isLeapYear(year) ? 29 : 28);
              break;
            case 4:
            case 6:
            case 9:
            case 11:
              day = Math.min(day, 30);
              break;
          }
          return LocalDate3.of(year, month, day);
        };
        function LocalDate3(year, month, dayOfMonth) {
          var _this;
          _this = _ChronoLocalDate.call(this) || this;
          requireNonNull(year, "year");
          requireNonNull(month, "month");
          requireNonNull(dayOfMonth, "dayOfMonth");
          if (month instanceof Month) {
            month = month.value();
          }
          _this._year = MathUtil.safeToInt(year);
          _this._month = MathUtil.safeToInt(month);
          _this._day = MathUtil.safeToInt(dayOfMonth);
          LocalDate3._validate(_this._year, _this._month, _this._day);
          return _this;
        }
        LocalDate3._validate = function _validate(year, month, dayOfMonth) {
          var dom;
          ChronoField.YEAR.checkValidValue(year);
          ChronoField.MONTH_OF_YEAR.checkValidValue(month);
          ChronoField.DAY_OF_MONTH.checkValidValue(dayOfMonth);
          if (dayOfMonth > 28) {
            dom = 31;
            switch (month) {
              case 2:
                dom = IsoChronology.isLeapYear(year) ? 29 : 28;
                break;
              case 4:
              case 6:
              case 9:
              case 11:
                dom = 30;
            }
            if (dayOfMonth > dom) {
              if (dayOfMonth === 29) {
                assert3(false, "Invalid date 'February 29' as '" + year + "' is not a leap year", DateTimeException);
              } else {
                assert3(false, "Invalid date '" + year + "' '" + month + "' '" + dayOfMonth + "'", DateTimeException);
              }
            }
          }
        };
        var _proto = LocalDate3.prototype;
        _proto.isSupported = function isSupported(field) {
          return _ChronoLocalDate.prototype.isSupported.call(this, field);
        };
        _proto.range = function range(field) {
          if (field instanceof ChronoField) {
            if (field.isDateBased()) {
              switch (field) {
                case ChronoField.DAY_OF_MONTH:
                  return ValueRange.of(1, this.lengthOfMonth());
                case ChronoField.DAY_OF_YEAR:
                  return ValueRange.of(1, this.lengthOfYear());
                case ChronoField.ALIGNED_WEEK_OF_MONTH:
                  return ValueRange.of(1, this.month() === Month.FEBRUARY && this.isLeapYear() === false ? 4 : 5);
                case ChronoField.YEAR_OF_ERA:
                  return this._year <= 0 ? ValueRange.of(1, Year.MAX_VALUE + 1) : ValueRange.of(1, Year.MAX_VALUE);
              }
              return field.range();
            }
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.rangeRefinedBy(this);
        };
        _proto.get = function get(field) {
          return this.getLong(field);
        };
        _proto.getLong = function getLong(field) {
          assert3(field != null, "", NullPointerException);
          if (field instanceof ChronoField) {
            return this._get0(field);
          }
          return field.getFrom(this);
        };
        _proto._get0 = function _get0(field) {
          switch (field) {
            case ChronoField.DAY_OF_WEEK:
              return this.dayOfWeek().value();
            case ChronoField.ALIGNED_DAY_OF_WEEK_IN_MONTH:
              return MathUtil.intMod(this._day - 1, 7) + 1;
            case ChronoField.ALIGNED_DAY_OF_WEEK_IN_YEAR:
              return MathUtil.intMod(this.dayOfYear() - 1, 7) + 1;
            case ChronoField.DAY_OF_MONTH:
              return this._day;
            case ChronoField.DAY_OF_YEAR:
              return this.dayOfYear();
            case ChronoField.EPOCH_DAY:
              return this.toEpochDay();
            case ChronoField.ALIGNED_WEEK_OF_MONTH:
              return MathUtil.intDiv(this._day - 1, 7) + 1;
            case ChronoField.ALIGNED_WEEK_OF_YEAR:
              return MathUtil.intDiv(this.dayOfYear() - 1, 7) + 1;
            case ChronoField.MONTH_OF_YEAR:
              return this._month;
            case ChronoField.PROLEPTIC_MONTH:
              return this._prolepticMonth();
            case ChronoField.YEAR_OF_ERA:
              return this._year >= 1 ? this._year : 1 - this._year;
            case ChronoField.YEAR:
              return this._year;
            case ChronoField.ERA:
              return this._year >= 1 ? 1 : 0;
          }
          throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
        };
        _proto._prolepticMonth = function _prolepticMonth() {
          return this._year * 12 + (this._month - 1);
        };
        _proto.chronology = function chronology() {
          return IsoChronology.INSTANCE;
        };
        _proto.year = function year() {
          return this._year;
        };
        _proto.monthValue = function monthValue() {
          return this._month;
        };
        _proto.month = function month() {
          return Month.of(this._month);
        };
        _proto.dayOfMonth = function dayOfMonth() {
          return this._day;
        };
        _proto.dayOfYear = function dayOfYear() {
          return this.month().firstDayOfYear(this.isLeapYear()) + this._day - 1;
        };
        _proto.dayOfWeek = function dayOfWeek() {
          var dow0 = MathUtil.floorMod(this.toEpochDay() + 3, 7);
          return DayOfWeek.of(dow0 + 1);
        };
        _proto.isLeapYear = function isLeapYear() {
          return IsoChronology.isLeapYear(this._year);
        };
        _proto.lengthOfMonth = function lengthOfMonth() {
          switch (this._month) {
            case 2:
              return this.isLeapYear() ? 29 : 28;
            case 4:
            case 6:
            case 9:
            case 11:
              return 30;
            default:
              return 31;
          }
        };
        _proto.lengthOfYear = function lengthOfYear() {
          return this.isLeapYear() ? 366 : 365;
        };
        _proto._withAdjuster = function _withAdjuster(adjuster) {
          requireNonNull(adjuster, "adjuster");
          if (adjuster instanceof LocalDate3) {
            return adjuster;
          }
          return _ChronoLocalDate.prototype._withAdjuster.call(this, adjuster);
        };
        _proto._withField = function _withField(field, newValue) {
          assert3(field != null, "field", NullPointerException);
          if (field instanceof ChronoField) {
            var f = field;
            f.checkValidValue(newValue);
            switch (f) {
              case ChronoField.DAY_OF_WEEK:
                return this.plusDays(newValue - this.dayOfWeek().value());
              case ChronoField.ALIGNED_DAY_OF_WEEK_IN_MONTH:
                return this.plusDays(newValue - this.getLong(ChronoField.ALIGNED_DAY_OF_WEEK_IN_MONTH));
              case ChronoField.ALIGNED_DAY_OF_WEEK_IN_YEAR:
                return this.plusDays(newValue - this.getLong(ChronoField.ALIGNED_DAY_OF_WEEK_IN_YEAR));
              case ChronoField.DAY_OF_MONTH:
                return this.withDayOfMonth(newValue);
              case ChronoField.DAY_OF_YEAR:
                return this.withDayOfYear(newValue);
              case ChronoField.EPOCH_DAY:
                return LocalDate3.ofEpochDay(newValue);
              case ChronoField.ALIGNED_WEEK_OF_MONTH:
                return this.plusWeeks(newValue - this.getLong(ChronoField.ALIGNED_WEEK_OF_MONTH));
              case ChronoField.ALIGNED_WEEK_OF_YEAR:
                return this.plusWeeks(newValue - this.getLong(ChronoField.ALIGNED_WEEK_OF_YEAR));
              case ChronoField.MONTH_OF_YEAR:
                return this.withMonth(newValue);
              case ChronoField.PROLEPTIC_MONTH:
                return this.plusMonths(newValue - this.getLong(ChronoField.PROLEPTIC_MONTH));
              case ChronoField.YEAR_OF_ERA:
                return this.withYear(this._year >= 1 ? newValue : 1 - newValue);
              case ChronoField.YEAR:
                return this.withYear(newValue);
              case ChronoField.ERA:
                return this.getLong(ChronoField.ERA) === newValue ? this : this.withYear(1 - this._year);
            }
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.adjustInto(this, newValue);
        };
        _proto.withYear = function withYear(year) {
          if (this._year === year) {
            return this;
          }
          ChronoField.YEAR.checkValidValue(year);
          return LocalDate3._resolvePreviousValid(year, this._month, this._day);
        };
        _proto.withMonth = function withMonth(month) {
          var m = month instanceof Month ? month.value() : month;
          if (this._month === m) {
            return this;
          }
          ChronoField.MONTH_OF_YEAR.checkValidValue(m);
          return LocalDate3._resolvePreviousValid(this._year, m, this._day);
        };
        _proto.withDayOfMonth = function withDayOfMonth(dayOfMonth) {
          if (this._day === dayOfMonth) {
            return this;
          }
          return LocalDate3.of(this._year, this._month, dayOfMonth);
        };
        _proto.withDayOfYear = function withDayOfYear(dayOfYear) {
          if (this.dayOfYear() === dayOfYear) {
            return this;
          }
          return LocalDate3.ofYearDay(this._year, dayOfYear);
        };
        _proto._plusUnit = function _plusUnit(amountToAdd, unit) {
          requireNonNull(amountToAdd, "amountToAdd");
          requireNonNull(unit, "unit");
          if (unit instanceof ChronoUnit) {
            switch (unit) {
              case ChronoUnit.DAYS:
                return this.plusDays(amountToAdd);
              case ChronoUnit.WEEKS:
                return this.plusWeeks(amountToAdd);
              case ChronoUnit.MONTHS:
                return this.plusMonths(amountToAdd);
              case ChronoUnit.YEARS:
                return this.plusYears(amountToAdd);
              case ChronoUnit.DECADES:
                return this.plusYears(MathUtil.safeMultiply(amountToAdd, 10));
              case ChronoUnit.CENTURIES:
                return this.plusYears(MathUtil.safeMultiply(amountToAdd, 100));
              case ChronoUnit.MILLENNIA:
                return this.plusYears(MathUtil.safeMultiply(amountToAdd, 1e3));
              case ChronoUnit.ERAS:
                return this.with(ChronoField.ERA, MathUtil.safeAdd(this.getLong(ChronoField.ERA), amountToAdd));
            }
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
          return unit.addTo(this, amountToAdd);
        };
        _proto.plusYears = function plusYears(yearsToAdd) {
          if (yearsToAdd === 0) {
            return this;
          }
          var newYear = ChronoField.YEAR.checkValidIntValue(this._year + yearsToAdd);
          return LocalDate3._resolvePreviousValid(newYear, this._month, this._day);
        };
        _proto.plusMonths = function plusMonths(monthsToAdd) {
          if (monthsToAdd === 0) {
            return this;
          }
          var monthCount = this._year * 12 + (this._month - 1);
          var calcMonths = monthCount + monthsToAdd;
          var newYear = ChronoField.YEAR.checkValidIntValue(MathUtil.floorDiv(calcMonths, 12));
          var newMonth = MathUtil.floorMod(calcMonths, 12) + 1;
          return LocalDate3._resolvePreviousValid(newYear, newMonth, this._day);
        };
        _proto.plusWeeks = function plusWeeks(weeksToAdd) {
          return this.plusDays(MathUtil.safeMultiply(weeksToAdd, 7));
        };
        _proto.plusDays = function plusDays(daysToAdd) {
          if (daysToAdd === 0) {
            return this;
          }
          var mjDay = MathUtil.safeAdd(this.toEpochDay(), daysToAdd);
          return LocalDate3.ofEpochDay(mjDay);
        };
        _proto._minusUnit = function _minusUnit(amountToSubtract, unit) {
          requireNonNull(amountToSubtract, "amountToSubtract");
          requireNonNull(unit, "unit");
          return this._plusUnit(-1 * amountToSubtract, unit);
        };
        _proto.minusYears = function minusYears(yearsToSubtract) {
          return this.plusYears(yearsToSubtract * -1);
        };
        _proto.minusMonths = function minusMonths(monthsToSubtract) {
          return this.plusMonths(monthsToSubtract * -1);
        };
        _proto.minusWeeks = function minusWeeks(weeksToSubtract) {
          return this.plusWeeks(weeksToSubtract * -1);
        };
        _proto.minusDays = function minusDays(daysToSubtract) {
          return this.plusDays(daysToSubtract * -1);
        };
        _proto.query = function query(_query) {
          requireNonNull(_query, "query");
          if (_query === TemporalQueries.localDate()) {
            return this;
          }
          return _ChronoLocalDate.prototype.query.call(this, _query);
        };
        _proto.adjustInto = function adjustInto(temporal) {
          return _ChronoLocalDate.prototype.adjustInto.call(this, temporal);
        };
        _proto.until = function until(p1, p2) {
          if (arguments.length < 2) {
            return this.until1(p1);
          } else {
            return this.until2(p1, p2);
          }
        };
        _proto.until2 = function until2(endExclusive, unit) {
          var end = LocalDate3.from(endExclusive);
          if (unit instanceof ChronoUnit) {
            switch (unit) {
              case ChronoUnit.DAYS:
                return this.daysUntil(end);
              case ChronoUnit.WEEKS:
                return MathUtil.intDiv(this.daysUntil(end), 7);
              case ChronoUnit.MONTHS:
                return this._monthsUntil(end);
              case ChronoUnit.YEARS:
                return MathUtil.intDiv(this._monthsUntil(end), 12);
              case ChronoUnit.DECADES:
                return MathUtil.intDiv(this._monthsUntil(end), 120);
              case ChronoUnit.CENTURIES:
                return MathUtil.intDiv(this._monthsUntil(end), 1200);
              case ChronoUnit.MILLENNIA:
                return MathUtil.intDiv(this._monthsUntil(end), 12e3);
              case ChronoUnit.ERAS:
                return end.getLong(ChronoField.ERA) - this.getLong(ChronoField.ERA);
            }
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
          return unit.between(this, end);
        };
        _proto.daysUntil = function daysUntil(end) {
          return end.toEpochDay() - this.toEpochDay();
        };
        _proto._monthsUntil = function _monthsUntil(end) {
          var packed1 = this._prolepticMonth() * 32 + this.dayOfMonth();
          var packed2 = end._prolepticMonth() * 32 + end.dayOfMonth();
          return MathUtil.intDiv(packed2 - packed1, 32);
        };
        _proto.until1 = function until1(endDate) {
          var end = LocalDate3.from(endDate);
          var totalMonths = end._prolepticMonth() - this._prolepticMonth();
          var days = end._day - this._day;
          if (totalMonths > 0 && days < 0) {
            totalMonths--;
            var calcDate = this.plusMonths(totalMonths);
            days = end.toEpochDay() - calcDate.toEpochDay();
          } else if (totalMonths < 0 && days > 0) {
            totalMonths++;
            days -= end.lengthOfMonth();
          }
          var years = MathUtil.intDiv(totalMonths, 12);
          var months = MathUtil.intMod(totalMonths, 12);
          return Period.of(years, months, days);
        };
        _proto.atTime = function atTime() {
          if (arguments.length === 1) {
            return this.atTime1.apply(this, arguments);
          } else {
            return this.atTime4.apply(this, arguments);
          }
        };
        _proto.atTime1 = function atTime1(time) {
          requireNonNull(time, "time");
          if (time instanceof LocalTime) {
            return LocalDateTime.of(this, time);
          } else if (time instanceof OffsetTime) {
            return this._atTimeOffsetTime(time);
          } else {
            throw new IllegalArgumentException("time must be an instance of LocalTime or OffsetTime" + (time && time.constructor && time.constructor.name ? ", but is " + time.constructor.name : ""));
          }
        };
        _proto.atTime4 = function atTime4(hour, minute, second, nanoOfSecond) {
          if (second === void 0) {
            second = 0;
          }
          if (nanoOfSecond === void 0) {
            nanoOfSecond = 0;
          }
          return this.atTime1(LocalTime.of(hour, minute, second, nanoOfSecond));
        };
        _proto._atTimeOffsetTime = function _atTimeOffsetTime(time) {
          return OffsetDateTime.of(LocalDateTime.of(this, time.toLocalTime()), time.offset());
        };
        _proto.atStartOfDay = function atStartOfDay(zone) {
          if (zone != null) {
            return this._atStartOfDayWithZone(zone);
          } else {
            return LocalDateTime.of(this, LocalTime.MIDNIGHT);
          }
        };
        _proto._atStartOfDayWithZone = function _atStartOfDayWithZone(zone) {
          requireNonNull(zone, "zone");
          var ldt = this.atTime(LocalTime.MIDNIGHT);
          if (zone instanceof ZoneOffset === false) {
            var trans = zone.rules().transition(ldt);
            if (trans != null && trans.isGap()) {
              ldt = trans.dateTimeAfter();
            }
          }
          return ZonedDateTime2.of(ldt, zone);
        };
        _proto.toEpochDay = function toEpochDay() {
          var y = this._year;
          var m = this._month;
          var total = 0;
          total += 365 * y;
          if (y >= 0) {
            total += MathUtil.intDiv(y + 3, 4) - MathUtil.intDiv(y + 99, 100) + MathUtil.intDiv(y + 399, 400);
          } else {
            total -= MathUtil.intDiv(y, -4) - MathUtil.intDiv(y, -100) + MathUtil.intDiv(y, -400);
          }
          total += MathUtil.intDiv(367 * m - 362, 12);
          total += this.dayOfMonth() - 1;
          if (m > 2) {
            total--;
            if (!IsoChronology.isLeapYear(y)) {
              total--;
            }
          }
          return total - DAYS_0000_TO_1970;
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          requireInstance(other, LocalDate3, "other");
          return this._compareTo0(other);
        };
        _proto._compareTo0 = function _compareTo0(otherDate) {
          var cmp = this._year - otherDate._year;
          if (cmp === 0) {
            cmp = this._month - otherDate._month;
            if (cmp === 0) {
              cmp = this._day - otherDate._day;
            }
          }
          return cmp;
        };
        _proto.isAfter = function isAfter(other) {
          return this.compareTo(other) > 0;
        };
        _proto.isBefore = function isBefore(other) {
          return this.compareTo(other) < 0;
        };
        _proto.isEqual = function isEqual(other) {
          return this.compareTo(other) === 0;
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof LocalDate3) {
            return this._compareTo0(other) === 0;
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          var yearValue = this._year;
          var monthValue = this._month;
          var dayValue = this._day;
          return MathUtil.hash(yearValue & 4294965248 ^ (yearValue << 11) + (monthValue << 6) + dayValue);
        };
        _proto.toString = function toString() {
          var dayString, monthString, yearString;
          var yearValue = this._year;
          var monthValue = this._month;
          var dayValue = this._day;
          var absYear = Math.abs(yearValue);
          if (absYear < 1e3) {
            if (yearValue < 0) {
              yearString = "-" + ("" + (yearValue - 1e4)).slice(-4);
            } else {
              yearString = ("" + (yearValue + 1e4)).slice(-4);
            }
          } else {
            if (yearValue > 9999) {
              yearString = "+" + yearValue;
            } else {
              yearString = "" + yearValue;
            }
          }
          if (monthValue < 10) {
            monthString = "-0" + monthValue;
          } else {
            monthString = "-" + monthValue;
          }
          if (dayValue < 10) {
            dayString = "-0" + dayValue;
          } else {
            dayString = "-" + dayValue;
          }
          return yearString + monthString + dayString;
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        _proto.format = function format(formatter) {
          requireNonNull(formatter, "formatter");
          requireInstance(formatter, DateTimeFormatter, "formatter");
          return _ChronoLocalDate.prototype.format.call(this, formatter);
        };
        return LocalDate3;
      }(ChronoLocalDate);
      function _init$5() {
        LocalDate2.MIN = LocalDate2.of(YearConstants.MIN_VALUE, 1, 1);
        LocalDate2.MAX = LocalDate2.of(YearConstants.MAX_VALUE, 12, 31);
        LocalDate2.EPOCH_0 = LocalDate2.ofEpochDay(0);
        LocalDate2.FROM = createTemporalQuery("LocalDate.FROM", function(temporal) {
          return LocalDate2.from(temporal);
        });
      }
      var ChronoLocalDateTime = function(_Temporal) {
        _inheritsLoose(ChronoLocalDateTime2, _Temporal);
        function ChronoLocalDateTime2() {
          return _Temporal.apply(this, arguments) || this;
        }
        var _proto = ChronoLocalDateTime2.prototype;
        _proto.chronology = function chronology() {
          return this.toLocalDate().chronology();
        };
        _proto.query = function query(_query) {
          if (_query === TemporalQueries.chronology()) {
            return this.chronology();
          } else if (_query === TemporalQueries.precision()) {
            return ChronoUnit.NANOS;
          } else if (_query === TemporalQueries.localDate()) {
            return LocalDate2.ofEpochDay(this.toLocalDate().toEpochDay());
          } else if (_query === TemporalQueries.localTime()) {
            return this.toLocalTime();
          } else if (_query === TemporalQueries.zone() || _query === TemporalQueries.zoneId() || _query === TemporalQueries.offset()) {
            return null;
          }
          return _Temporal.prototype.query.call(this, _query);
        };
        _proto.adjustInto = function adjustInto(temporal) {
          return temporal.with(ChronoField.EPOCH_DAY, this.toLocalDate().toEpochDay()).with(ChronoField.NANO_OF_DAY, this.toLocalTime().toNanoOfDay());
        };
        _proto.toInstant = function toInstant(offset) {
          requireInstance(offset, ZoneOffset, "zoneId");
          return Instant.ofEpochSecond(this.toEpochSecond(offset), this.toLocalTime().nano());
        };
        _proto.toEpochSecond = function toEpochSecond(offset) {
          requireNonNull(offset, "offset");
          var epochDay = this.toLocalDate().toEpochDay();
          var secs = epochDay * 86400 + this.toLocalTime().toSecondOfDay();
          secs -= offset.totalSeconds();
          return MathUtil.safeToInt(secs);
        };
        return ChronoLocalDateTime2;
      }(Temporal);
      var LocalDateTime = function(_ChronoLocalDateTime) {
        _inheritsLoose(LocalDateTime2, _ChronoLocalDateTime);
        LocalDateTime2.now = function now(clockOrZone) {
          if (clockOrZone == null) {
            return LocalDateTime2._now(Clock.systemDefaultZone());
          } else if (clockOrZone instanceof Clock) {
            return LocalDateTime2._now(clockOrZone);
          } else {
            return LocalDateTime2._now(Clock.system(clockOrZone));
          }
        };
        LocalDateTime2._now = function _now(clock) {
          requireNonNull(clock, "clock");
          return LocalDateTime2.ofInstant(clock.instant(), clock.zone());
        };
        LocalDateTime2._ofEpochMillis = function _ofEpochMillis(epochMilli, offset) {
          var localSecond = MathUtil.floorDiv(epochMilli, 1e3) + offset.totalSeconds();
          var localEpochDay = MathUtil.floorDiv(localSecond, LocalTime.SECONDS_PER_DAY);
          var secsOfDay = MathUtil.floorMod(localSecond, LocalTime.SECONDS_PER_DAY);
          var nanoOfSecond = MathUtil.floorMod(epochMilli, 1e3) * 1e6;
          var date = LocalDate2.ofEpochDay(localEpochDay);
          var time = LocalTime.ofSecondOfDay(secsOfDay, nanoOfSecond);
          return new LocalDateTime2(date, time);
        };
        LocalDateTime2.of = function of() {
          if (arguments.length <= 2) {
            return LocalDateTime2.ofDateAndTime.apply(this, arguments);
          } else {
            return LocalDateTime2.ofNumbers.apply(this, arguments);
          }
        };
        LocalDateTime2.ofNumbers = function ofNumbers(year, month, dayOfMonth, hour, minute, second, nanoOfSecond) {
          if (hour === void 0) {
            hour = 0;
          }
          if (minute === void 0) {
            minute = 0;
          }
          if (second === void 0) {
            second = 0;
          }
          if (nanoOfSecond === void 0) {
            nanoOfSecond = 0;
          }
          var date = LocalDate2.of(year, month, dayOfMonth);
          var time = LocalTime.of(hour, minute, second, nanoOfSecond);
          return new LocalDateTime2(date, time);
        };
        LocalDateTime2.ofDateAndTime = function ofDateAndTime(date, time) {
          requireNonNull(date, "date");
          requireNonNull(time, "time");
          return new LocalDateTime2(date, time);
        };
        LocalDateTime2.ofInstant = function ofInstant(instant, zone) {
          if (zone === void 0) {
            zone = ZoneId2.systemDefault();
          }
          requireNonNull(instant, "instant");
          requireInstance(instant, Instant, "instant");
          requireNonNull(zone, "zone");
          var offset = zone.rules().offset(instant);
          return LocalDateTime2.ofEpochSecond(instant.epochSecond(), instant.nano(), offset);
        };
        LocalDateTime2.ofEpochSecond = function ofEpochSecond(epochSecond, nanoOfSecond, offset) {
          if (epochSecond === void 0) {
            epochSecond = 0;
          }
          if (nanoOfSecond === void 0) {
            nanoOfSecond = 0;
          }
          if (arguments.length === 2 && nanoOfSecond instanceof ZoneOffset) {
            offset = nanoOfSecond;
            nanoOfSecond = 0;
          }
          requireNonNull(offset, "offset");
          var localSecond = epochSecond + offset.totalSeconds();
          var localEpochDay = MathUtil.floorDiv(localSecond, LocalTime.SECONDS_PER_DAY);
          var secsOfDay = MathUtil.floorMod(localSecond, LocalTime.SECONDS_PER_DAY);
          var date = LocalDate2.ofEpochDay(localEpochDay);
          var time = LocalTime.ofSecondOfDay(secsOfDay, nanoOfSecond);
          return new LocalDateTime2(date, time);
        };
        LocalDateTime2.from = function from(temporal) {
          requireNonNull(temporal, "temporal");
          if (temporal instanceof LocalDateTime2) {
            return temporal;
          } else if (temporal instanceof ZonedDateTime2) {
            return temporal.toLocalDateTime();
          }
          try {
            var date = LocalDate2.from(temporal);
            var time = LocalTime.from(temporal);
            return new LocalDateTime2(date, time);
          } catch (ex) {
            throw new DateTimeException("Unable to obtain LocalDateTime TemporalAccessor: " + temporal + ", type " + (temporal.constructor != null ? temporal.constructor.name : ""));
          }
        };
        LocalDateTime2.parse = function parse(text, formatter) {
          if (formatter === void 0) {
            formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
          }
          requireNonNull(formatter, "formatter");
          return formatter.parse(text, LocalDateTime2.FROM);
        };
        function LocalDateTime2(date, time) {
          var _this;
          _this = _ChronoLocalDateTime.call(this) || this;
          requireInstance(date, LocalDate2, "date");
          requireInstance(time, LocalTime, "time");
          _this._date = date;
          _this._time = time;
          return _this;
        }
        var _proto = LocalDateTime2.prototype;
        _proto._withDateTime = function _withDateTime(newDate, newTime) {
          if (this._date.equals(newDate) && this._time.equals(newTime)) {
            return this;
          }
          return new LocalDateTime2(newDate, newTime);
        };
        _proto.isSupported = function isSupported(fieldOrUnit) {
          if (fieldOrUnit instanceof ChronoField) {
            return fieldOrUnit.isDateBased() || fieldOrUnit.isTimeBased();
          } else if (fieldOrUnit instanceof ChronoUnit) {
            return fieldOrUnit.isDateBased() || fieldOrUnit.isTimeBased();
          }
          return fieldOrUnit != null && fieldOrUnit.isSupportedBy(this);
        };
        _proto.range = function range(field) {
          if (field instanceof ChronoField) {
            return field.isTimeBased() ? this._time.range(field) : this._date.range(field);
          }
          return field.rangeRefinedBy(this);
        };
        _proto.get = function get(field) {
          if (field instanceof ChronoField) {
            return field.isTimeBased() ? this._time.get(field) : this._date.get(field);
          }
          return _ChronoLocalDateTime.prototype.get.call(this, field);
        };
        _proto.getLong = function getLong(field) {
          requireNonNull(field, "field");
          if (field instanceof ChronoField) {
            return field.isTimeBased() ? this._time.getLong(field) : this._date.getLong(field);
          }
          return field.getFrom(this);
        };
        _proto.year = function year() {
          return this._date.year();
        };
        _proto.monthValue = function monthValue() {
          return this._date.monthValue();
        };
        _proto.month = function month() {
          return this._date.month();
        };
        _proto.dayOfMonth = function dayOfMonth() {
          return this._date.dayOfMonth();
        };
        _proto.dayOfYear = function dayOfYear() {
          return this._date.dayOfYear();
        };
        _proto.dayOfWeek = function dayOfWeek() {
          return this._date.dayOfWeek();
        };
        _proto.hour = function hour() {
          return this._time.hour();
        };
        _proto.minute = function minute() {
          return this._time.minute();
        };
        _proto.second = function second() {
          return this._time.second();
        };
        _proto.nano = function nano() {
          return this._time.nano();
        };
        _proto._withAdjuster = function _withAdjuster(adjuster) {
          requireNonNull(adjuster, "adjuster");
          if (adjuster instanceof LocalDate2) {
            return this._withDateTime(adjuster, this._time);
          } else if (adjuster instanceof LocalTime) {
            return this._withDateTime(this._date, adjuster);
          } else if (adjuster instanceof LocalDateTime2) {
            return adjuster;
          }
          return _ChronoLocalDateTime.prototype._withAdjuster.call(this, adjuster);
        };
        _proto._withField = function _withField(field, newValue) {
          requireNonNull(field, "field");
          if (field instanceof ChronoField) {
            if (field.isTimeBased()) {
              return this._withDateTime(this._date, this._time.with(field, newValue));
            } else {
              return this._withDateTime(this._date.with(field, newValue), this._time);
            }
          }
          return field.adjustInto(this, newValue);
        };
        _proto.withYear = function withYear(year) {
          return this._withDateTime(this._date.withYear(year), this._time);
        };
        _proto.withMonth = function withMonth(month) {
          return this._withDateTime(this._date.withMonth(month), this._time);
        };
        _proto.withDayOfMonth = function withDayOfMonth(dayOfMonth) {
          return this._withDateTime(this._date.withDayOfMonth(dayOfMonth), this._time);
        };
        _proto.withDayOfYear = function withDayOfYear(dayOfYear) {
          return this._withDateTime(this._date.withDayOfYear(dayOfYear), this._time);
        };
        _proto.withHour = function withHour(hour) {
          var newTime = this._time.withHour(hour);
          return this._withDateTime(this._date, newTime);
        };
        _proto.withMinute = function withMinute(minute) {
          var newTime = this._time.withMinute(minute);
          return this._withDateTime(this._date, newTime);
        };
        _proto.withSecond = function withSecond(second) {
          var newTime = this._time.withSecond(second);
          return this._withDateTime(this._date, newTime);
        };
        _proto.withNano = function withNano(nanoOfSecond) {
          var newTime = this._time.withNano(nanoOfSecond);
          return this._withDateTime(this._date, newTime);
        };
        _proto.truncatedTo = function truncatedTo(unit) {
          return this._withDateTime(this._date, this._time.truncatedTo(unit));
        };
        _proto._plusUnit = function _plusUnit(amountToAdd, unit) {
          requireNonNull(unit, "unit");
          if (unit instanceof ChronoUnit) {
            switch (unit) {
              case ChronoUnit.NANOS:
                return this.plusNanos(amountToAdd);
              case ChronoUnit.MICROS:
                return this.plusDays(MathUtil.intDiv(amountToAdd, LocalTime.MICROS_PER_DAY)).plusNanos(MathUtil.intMod(amountToAdd, LocalTime.MICROS_PER_DAY) * 1e3);
              case ChronoUnit.MILLIS:
                return this.plusDays(MathUtil.intDiv(amountToAdd, LocalTime.MILLIS_PER_DAY)).plusNanos(MathUtil.intMod(amountToAdd, LocalTime.MILLIS_PER_DAY) * 1e6);
              case ChronoUnit.SECONDS:
                return this.plusSeconds(amountToAdd);
              case ChronoUnit.MINUTES:
                return this.plusMinutes(amountToAdd);
              case ChronoUnit.HOURS:
                return this.plusHours(amountToAdd);
              case ChronoUnit.HALF_DAYS:
                return this.plusDays(MathUtil.intDiv(amountToAdd, 256)).plusHours(MathUtil.intMod(amountToAdd, 256) * 12);
            }
            return this._withDateTime(this._date.plus(amountToAdd, unit), this._time);
          }
          return unit.addTo(this, amountToAdd);
        };
        _proto.plusYears = function plusYears(years) {
          var newDate = this._date.plusYears(years);
          return this._withDateTime(newDate, this._time);
        };
        _proto.plusMonths = function plusMonths(months) {
          var newDate = this._date.plusMonths(months);
          return this._withDateTime(newDate, this._time);
        };
        _proto.plusWeeks = function plusWeeks(weeks) {
          var newDate = this._date.plusWeeks(weeks);
          return this._withDateTime(newDate, this._time);
        };
        _proto.plusDays = function plusDays(days) {
          var newDate = this._date.plusDays(days);
          return this._withDateTime(newDate, this._time);
        };
        _proto.plusHours = function plusHours(hours) {
          return this._plusWithOverflow(this._date, hours, 0, 0, 0, 1);
        };
        _proto.plusMinutes = function plusMinutes(minutes) {
          return this._plusWithOverflow(this._date, 0, minutes, 0, 0, 1);
        };
        _proto.plusSeconds = function plusSeconds(seconds) {
          return this._plusWithOverflow(this._date, 0, 0, seconds, 0, 1);
        };
        _proto.plusNanos = function plusNanos(nanos) {
          return this._plusWithOverflow(this._date, 0, 0, 0, nanos, 1);
        };
        _proto._minusUnit = function _minusUnit(amountToSubtract, unit) {
          requireNonNull(unit, "unit");
          return this._plusUnit(-1 * amountToSubtract, unit);
        };
        _proto.minusYears = function minusYears(years) {
          return this.plusYears(-1 * years);
        };
        _proto.minusMonths = function minusMonths(months) {
          return this.plusMonths(-1 * months);
        };
        _proto.minusWeeks = function minusWeeks(weeks) {
          return this.plusWeeks(-1 * weeks);
        };
        _proto.minusDays = function minusDays(days) {
          return this.plusDays(-1 * days);
        };
        _proto.minusHours = function minusHours(hours) {
          return this._plusWithOverflow(this._date, hours, 0, 0, 0, -1);
        };
        _proto.minusMinutes = function minusMinutes(minutes) {
          return this._plusWithOverflow(this._date, 0, minutes, 0, 0, -1);
        };
        _proto.minusSeconds = function minusSeconds(seconds) {
          return this._plusWithOverflow(this._date, 0, 0, seconds, 0, -1);
        };
        _proto.minusNanos = function minusNanos(nanos) {
          return this._plusWithOverflow(this._date, 0, 0, 0, nanos, -1);
        };
        _proto._plusWithOverflow = function _plusWithOverflow(newDate, hours, minutes, seconds, nanos, sign) {
          if (hours === 0 && minutes === 0 && seconds === 0 && nanos === 0) {
            return this._withDateTime(newDate, this._time);
          }
          var totDays = MathUtil.intDiv(nanos, LocalTime.NANOS_PER_DAY) + MathUtil.intDiv(seconds, LocalTime.SECONDS_PER_DAY) + MathUtil.intDiv(minutes, LocalTime.MINUTES_PER_DAY) + MathUtil.intDiv(hours, LocalTime.HOURS_PER_DAY);
          totDays *= sign;
          var totNanos = MathUtil.intMod(nanos, LocalTime.NANOS_PER_DAY) + MathUtil.intMod(seconds, LocalTime.SECONDS_PER_DAY) * LocalTime.NANOS_PER_SECOND + MathUtil.intMod(minutes, LocalTime.MINUTES_PER_DAY) * LocalTime.NANOS_PER_MINUTE + MathUtil.intMod(hours, LocalTime.HOURS_PER_DAY) * LocalTime.NANOS_PER_HOUR;
          var curNoD = this._time.toNanoOfDay();
          totNanos = totNanos * sign + curNoD;
          totDays += MathUtil.floorDiv(totNanos, LocalTime.NANOS_PER_DAY);
          var newNoD = MathUtil.floorMod(totNanos, LocalTime.NANOS_PER_DAY);
          var newTime = newNoD === curNoD ? this._time : LocalTime.ofNanoOfDay(newNoD);
          return this._withDateTime(newDate.plusDays(totDays), newTime);
        };
        _proto.query = function query(_query) {
          requireNonNull(_query, "query");
          if (_query === TemporalQueries.localDate()) {
            return this.toLocalDate();
          }
          return _ChronoLocalDateTime.prototype.query.call(this, _query);
        };
        _proto.adjustInto = function adjustInto(temporal) {
          return _ChronoLocalDateTime.prototype.adjustInto.call(this, temporal);
        };
        _proto.until = function until(endExclusive, unit) {
          requireNonNull(endExclusive, "endExclusive");
          requireNonNull(unit, "unit");
          var end = LocalDateTime2.from(endExclusive);
          if (unit instanceof ChronoUnit) {
            if (unit.isTimeBased()) {
              var daysUntil = this._date.daysUntil(end._date);
              var timeUntil = end._time.toNanoOfDay() - this._time.toNanoOfDay();
              if (daysUntil > 0 && timeUntil < 0) {
                daysUntil--;
                timeUntil += LocalTime.NANOS_PER_DAY;
              } else if (daysUntil < 0 && timeUntil > 0) {
                daysUntil++;
                timeUntil -= LocalTime.NANOS_PER_DAY;
              }
              var amount = daysUntil;
              switch (unit) {
                case ChronoUnit.NANOS:
                  amount = MathUtil.safeMultiply(amount, LocalTime.NANOS_PER_DAY);
                  return MathUtil.safeAdd(amount, timeUntil);
                case ChronoUnit.MICROS:
                  amount = MathUtil.safeMultiply(amount, LocalTime.MICROS_PER_DAY);
                  return MathUtil.safeAdd(amount, MathUtil.intDiv(timeUntil, 1e3));
                case ChronoUnit.MILLIS:
                  amount = MathUtil.safeMultiply(amount, LocalTime.MILLIS_PER_DAY);
                  return MathUtil.safeAdd(amount, MathUtil.intDiv(timeUntil, 1e6));
                case ChronoUnit.SECONDS:
                  amount = MathUtil.safeMultiply(amount, LocalTime.SECONDS_PER_DAY);
                  return MathUtil.safeAdd(amount, MathUtil.intDiv(timeUntil, LocalTime.NANOS_PER_SECOND));
                case ChronoUnit.MINUTES:
                  amount = MathUtil.safeMultiply(amount, LocalTime.MINUTES_PER_DAY);
                  return MathUtil.safeAdd(amount, MathUtil.intDiv(timeUntil, LocalTime.NANOS_PER_MINUTE));
                case ChronoUnit.HOURS:
                  amount = MathUtil.safeMultiply(amount, LocalTime.HOURS_PER_DAY);
                  return MathUtil.safeAdd(amount, MathUtil.intDiv(timeUntil, LocalTime.NANOS_PER_HOUR));
                case ChronoUnit.HALF_DAYS:
                  amount = MathUtil.safeMultiply(amount, 2);
                  return MathUtil.safeAdd(amount, MathUtil.intDiv(timeUntil, LocalTime.NANOS_PER_HOUR * 12));
              }
              throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
            }
            var endDate = end._date;
            var endTime = end._time;
            if (endDate.isAfter(this._date) && endTime.isBefore(this._time)) {
              endDate = endDate.minusDays(1);
            } else if (endDate.isBefore(this._date) && endTime.isAfter(this._time)) {
              endDate = endDate.plusDays(1);
            }
            return this._date.until(endDate, unit);
          }
          return unit.between(this, end);
        };
        _proto.atOffset = function atOffset(offset) {
          return OffsetDateTime.of(this, offset);
        };
        _proto.atZone = function atZone(zone) {
          return ZonedDateTime2.of(this, zone);
        };
        _proto.toLocalDate = function toLocalDate() {
          return this._date;
        };
        _proto.toLocalTime = function toLocalTime() {
          return this._time;
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          requireInstance(other, LocalDateTime2, "other");
          return this._compareTo0(other);
        };
        _proto._compareTo0 = function _compareTo0(other) {
          var cmp = this._date.compareTo(other.toLocalDate());
          if (cmp === 0) {
            cmp = this._time.compareTo(other.toLocalTime());
          }
          return cmp;
        };
        _proto.isAfter = function isAfter(other) {
          return this.compareTo(other) > 0;
        };
        _proto.isBefore = function isBefore(other) {
          return this.compareTo(other) < 0;
        };
        _proto.isEqual = function isEqual(other) {
          return this.compareTo(other) === 0;
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof LocalDateTime2) {
            return this._date.equals(other._date) && this._time.equals(other._time);
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          return this._date.hashCode() ^ this._time.hashCode();
        };
        _proto.toString = function toString() {
          return this._date.toString() + "T" + this._time.toString();
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        _proto.format = function format(formatter) {
          requireNonNull(formatter, "formatter");
          return formatter.format(this);
        };
        return LocalDateTime2;
      }(ChronoLocalDateTime);
      function _init$4() {
        LocalDateTime.MIN = LocalDateTime.of(LocalDate2.MIN, LocalTime.MIN);
        LocalDateTime.MAX = LocalDateTime.of(LocalDate2.MAX, LocalTime.MAX);
        LocalDateTime.FROM = createTemporalQuery("LocalDateTime.FROM", function(temporal) {
          return LocalDateTime.from(temporal);
        });
      }
      var LocalTime = function(_Temporal) {
        _inheritsLoose(LocalTime2, _Temporal);
        LocalTime2.now = function now(clockOrZone) {
          if (clockOrZone == null) {
            return LocalTime2._now(Clock.systemDefaultZone());
          } else if (clockOrZone instanceof Clock) {
            return LocalTime2._now(clockOrZone);
          } else {
            return LocalTime2._now(Clock.system(clockOrZone));
          }
        };
        LocalTime2._now = function _now(clock) {
          if (clock === void 0) {
            clock = Clock.systemDefaultZone();
          }
          requireNonNull(clock, "clock");
          return LocalTime2.ofInstant(clock.instant(), clock.zone());
        };
        LocalTime2.ofInstant = function ofInstant(instant, zone) {
          if (zone === void 0) {
            zone = ZoneId2.systemDefault();
          }
          var offset = zone.rules().offset(instant);
          var secsOfDay = MathUtil.intMod(instant.epochSecond(), LocalTime2.SECONDS_PER_DAY);
          secsOfDay = MathUtil.intMod(secsOfDay + offset.totalSeconds(), LocalTime2.SECONDS_PER_DAY);
          if (secsOfDay < 0) {
            secsOfDay += LocalTime2.SECONDS_PER_DAY;
          }
          return LocalTime2.ofSecondOfDay(secsOfDay, instant.nano());
        };
        LocalTime2.of = function of(hour, minute, second, nanoOfSecond) {
          return new LocalTime2(hour, minute, second, nanoOfSecond);
        };
        LocalTime2.ofSecondOfDay = function ofSecondOfDay(secondOfDay, nanoOfSecond) {
          if (secondOfDay === void 0) {
            secondOfDay = 0;
          }
          if (nanoOfSecond === void 0) {
            nanoOfSecond = 0;
          }
          ChronoField.SECOND_OF_DAY.checkValidValue(secondOfDay);
          ChronoField.NANO_OF_SECOND.checkValidValue(nanoOfSecond);
          var hours = MathUtil.intDiv(secondOfDay, LocalTime2.SECONDS_PER_HOUR);
          secondOfDay -= hours * LocalTime2.SECONDS_PER_HOUR;
          var minutes = MathUtil.intDiv(secondOfDay, LocalTime2.SECONDS_PER_MINUTE);
          secondOfDay -= minutes * LocalTime2.SECONDS_PER_MINUTE;
          return new LocalTime2(hours, minutes, secondOfDay, nanoOfSecond);
        };
        LocalTime2.ofNanoOfDay = function ofNanoOfDay(nanoOfDay) {
          if (nanoOfDay === void 0) {
            nanoOfDay = 0;
          }
          ChronoField.NANO_OF_DAY.checkValidValue(nanoOfDay);
          var hours = MathUtil.intDiv(nanoOfDay, LocalTime2.NANOS_PER_HOUR);
          nanoOfDay -= hours * LocalTime2.NANOS_PER_HOUR;
          var minutes = MathUtil.intDiv(nanoOfDay, LocalTime2.NANOS_PER_MINUTE);
          nanoOfDay -= minutes * LocalTime2.NANOS_PER_MINUTE;
          var seconds = MathUtil.intDiv(nanoOfDay, LocalTime2.NANOS_PER_SECOND);
          nanoOfDay -= seconds * LocalTime2.NANOS_PER_SECOND;
          return new LocalTime2(hours, minutes, seconds, nanoOfDay);
        };
        LocalTime2.from = function from(temporal) {
          requireNonNull(temporal, "temporal");
          var time = temporal.query(TemporalQueries.localTime());
          if (time == null) {
            throw new DateTimeException("Unable to obtain LocalTime TemporalAccessor: " + temporal + ", type " + (temporal.constructor != null ? temporal.constructor.name : ""));
          }
          return time;
        };
        LocalTime2.parse = function parse(text, formatter) {
          if (formatter === void 0) {
            formatter = DateTimeFormatter.ISO_LOCAL_TIME;
          }
          requireNonNull(formatter, "formatter");
          return formatter.parse(text, LocalTime2.FROM);
        };
        function LocalTime2(hour, minute, second, nanoOfSecond) {
          var _this;
          if (hour === void 0) {
            hour = 0;
          }
          if (minute === void 0) {
            minute = 0;
          }
          if (second === void 0) {
            second = 0;
          }
          if (nanoOfSecond === void 0) {
            nanoOfSecond = 0;
          }
          _this = _Temporal.call(this) || this;
          var _hour = MathUtil.safeToInt(hour);
          var _minute = MathUtil.safeToInt(minute);
          var _second = MathUtil.safeToInt(second);
          var _nanoOfSecond = MathUtil.safeToInt(nanoOfSecond);
          LocalTime2._validate(_hour, _minute, _second, _nanoOfSecond);
          if (_minute === 0 && _second === 0 && _nanoOfSecond === 0) {
            if (!LocalTime2.HOURS[_hour]) {
              _this._hour = _hour;
              _this._minute = _minute;
              _this._second = _second;
              _this._nano = _nanoOfSecond;
              LocalTime2.HOURS[_hour] = _assertThisInitialized(_this);
            }
            return LocalTime2.HOURS[_hour] || _assertThisInitialized(_this);
          }
          _this._hour = _hour;
          _this._minute = _minute;
          _this._second = _second;
          _this._nano = _nanoOfSecond;
          return _this;
        }
        LocalTime2._validate = function _validate(hour, minute, second, nanoOfSecond) {
          ChronoField.HOUR_OF_DAY.checkValidValue(hour);
          ChronoField.MINUTE_OF_HOUR.checkValidValue(minute);
          ChronoField.SECOND_OF_MINUTE.checkValidValue(second);
          ChronoField.NANO_OF_SECOND.checkValidValue(nanoOfSecond);
        };
        var _proto = LocalTime2.prototype;
        _proto.isSupported = function isSupported(fieldOrUnit) {
          if (fieldOrUnit instanceof ChronoField) {
            return fieldOrUnit.isTimeBased();
          } else if (fieldOrUnit instanceof ChronoUnit) {
            return fieldOrUnit.isTimeBased();
          }
          return fieldOrUnit != null && fieldOrUnit.isSupportedBy(this);
        };
        _proto.range = function range(field) {
          requireNonNull(field);
          return _Temporal.prototype.range.call(this, field);
        };
        _proto.get = function get(field) {
          return this.getLong(field);
        };
        _proto.getLong = function getLong(field) {
          requireNonNull(field, "field");
          if (field instanceof ChronoField) {
            return this._get0(field);
          }
          return field.getFrom(this);
        };
        _proto._get0 = function _get0(field) {
          switch (field) {
            case ChronoField.NANO_OF_SECOND:
              return this._nano;
            case ChronoField.NANO_OF_DAY:
              return this.toNanoOfDay();
            case ChronoField.MICRO_OF_SECOND:
              return MathUtil.intDiv(this._nano, 1e3);
            case ChronoField.MICRO_OF_DAY:
              return MathUtil.intDiv(this.toNanoOfDay(), 1e3);
            case ChronoField.MILLI_OF_SECOND:
              return MathUtil.intDiv(this._nano, 1e6);
            case ChronoField.MILLI_OF_DAY:
              return MathUtil.intDiv(this.toNanoOfDay(), 1e6);
            case ChronoField.SECOND_OF_MINUTE:
              return this._second;
            case ChronoField.SECOND_OF_DAY:
              return this.toSecondOfDay();
            case ChronoField.MINUTE_OF_HOUR:
              return this._minute;
            case ChronoField.MINUTE_OF_DAY:
              return this._hour * 60 + this._minute;
            case ChronoField.HOUR_OF_AMPM:
              return MathUtil.intMod(this._hour, 12);
            case ChronoField.CLOCK_HOUR_OF_AMPM: {
              var ham = MathUtil.intMod(this._hour, 12);
              return ham % 12 === 0 ? 12 : ham;
            }
            case ChronoField.HOUR_OF_DAY:
              return this._hour;
            case ChronoField.CLOCK_HOUR_OF_DAY:
              return this._hour === 0 ? 24 : this._hour;
            case ChronoField.AMPM_OF_DAY:
              return MathUtil.intDiv(this._hour, 12);
          }
          throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
        };
        _proto.hour = function hour() {
          return this._hour;
        };
        _proto.minute = function minute() {
          return this._minute;
        };
        _proto.second = function second() {
          return this._second;
        };
        _proto.nano = function nano() {
          return this._nano;
        };
        _proto._withAdjuster = function _withAdjuster(adjuster) {
          requireNonNull(adjuster, "adjuster");
          if (adjuster instanceof LocalTime2) {
            return adjuster;
          }
          return _Temporal.prototype._withAdjuster.call(this, adjuster);
        };
        _proto._withField = function _withField(field, newValue) {
          requireNonNull(field, "field");
          requireInstance(field, TemporalField, "field");
          if (field instanceof ChronoField) {
            field.checkValidValue(newValue);
            switch (field) {
              case ChronoField.NANO_OF_SECOND:
                return this.withNano(newValue);
              case ChronoField.NANO_OF_DAY:
                return LocalTime2.ofNanoOfDay(newValue);
              case ChronoField.MICRO_OF_SECOND:
                return this.withNano(newValue * 1e3);
              case ChronoField.MICRO_OF_DAY:
                return LocalTime2.ofNanoOfDay(newValue * 1e3);
              case ChronoField.MILLI_OF_SECOND:
                return this.withNano(newValue * 1e6);
              case ChronoField.MILLI_OF_DAY:
                return LocalTime2.ofNanoOfDay(newValue * 1e6);
              case ChronoField.SECOND_OF_MINUTE:
                return this.withSecond(newValue);
              case ChronoField.SECOND_OF_DAY:
                return this.plusSeconds(newValue - this.toSecondOfDay());
              case ChronoField.MINUTE_OF_HOUR:
                return this.withMinute(newValue);
              case ChronoField.MINUTE_OF_DAY:
                return this.plusMinutes(newValue - (this._hour * 60 + this._minute));
              case ChronoField.HOUR_OF_AMPM:
                return this.plusHours(newValue - MathUtil.intMod(this._hour, 12));
              case ChronoField.CLOCK_HOUR_OF_AMPM:
                return this.plusHours((newValue === 12 ? 0 : newValue) - MathUtil.intMod(this._hour, 12));
              case ChronoField.HOUR_OF_DAY:
                return this.withHour(newValue);
              case ChronoField.CLOCK_HOUR_OF_DAY:
                return this.withHour(newValue === 24 ? 0 : newValue);
              case ChronoField.AMPM_OF_DAY:
                return this.plusHours((newValue - MathUtil.intDiv(this._hour, 12)) * 12);
            }
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.adjustInto(this, newValue);
        };
        _proto.withHour = function withHour(hour) {
          if (hour === void 0) {
            hour = 0;
          }
          if (this._hour === hour) {
            return this;
          }
          return new LocalTime2(hour, this._minute, this._second, this._nano);
        };
        _proto.withMinute = function withMinute(minute) {
          if (minute === void 0) {
            minute = 0;
          }
          if (this._minute === minute) {
            return this;
          }
          return new LocalTime2(this._hour, minute, this._second, this._nano);
        };
        _proto.withSecond = function withSecond(second) {
          if (second === void 0) {
            second = 0;
          }
          if (this._second === second) {
            return this;
          }
          return new LocalTime2(this._hour, this._minute, second, this._nano);
        };
        _proto.withNano = function withNano(nanoOfSecond) {
          if (nanoOfSecond === void 0) {
            nanoOfSecond = 0;
          }
          if (this._nano === nanoOfSecond) {
            return this;
          }
          return new LocalTime2(this._hour, this._minute, this._second, nanoOfSecond);
        };
        _proto.truncatedTo = function truncatedTo(unit) {
          requireNonNull(unit, "unit");
          if (unit === ChronoUnit.NANOS) {
            return this;
          }
          var unitDur = unit.duration();
          if (unitDur.seconds() > LocalTime2.SECONDS_PER_DAY) {
            throw new DateTimeException("Unit is too large to be used for truncation");
          }
          var dur = unitDur.toNanos();
          if (MathUtil.intMod(LocalTime2.NANOS_PER_DAY, dur) !== 0) {
            throw new DateTimeException("Unit must divide into a standard day without remainder");
          }
          var nod = this.toNanoOfDay();
          return LocalTime2.ofNanoOfDay(MathUtil.intDiv(nod, dur) * dur);
        };
        _proto._plusUnit = function _plusUnit(amountToAdd, unit) {
          requireNonNull(unit, "unit");
          if (unit instanceof ChronoUnit) {
            switch (unit) {
              case ChronoUnit.NANOS:
                return this.plusNanos(amountToAdd);
              case ChronoUnit.MICROS:
                return this.plusNanos(MathUtil.intMod(amountToAdd, LocalTime2.MICROS_PER_DAY) * 1e3);
              case ChronoUnit.MILLIS:
                return this.plusNanos(MathUtil.intMod(amountToAdd, LocalTime2.MILLIS_PER_DAY) * 1e6);
              case ChronoUnit.SECONDS:
                return this.plusSeconds(amountToAdd);
              case ChronoUnit.MINUTES:
                return this.plusMinutes(amountToAdd);
              case ChronoUnit.HOURS:
                return this.plusHours(amountToAdd);
              case ChronoUnit.HALF_DAYS:
                return this.plusHours(MathUtil.intMod(amountToAdd, 2) * 12);
            }
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
          return unit.addTo(this, amountToAdd);
        };
        _proto.plusHours = function plusHours(hoursToAdd) {
          if (hoursToAdd === 0) {
            return this;
          }
          var newHour = MathUtil.intMod(MathUtil.intMod(hoursToAdd, LocalTime2.HOURS_PER_DAY) + this._hour + LocalTime2.HOURS_PER_DAY, LocalTime2.HOURS_PER_DAY);
          return new LocalTime2(newHour, this._minute, this._second, this._nano);
        };
        _proto.plusMinutes = function plusMinutes(minutesToAdd) {
          if (minutesToAdd === 0) {
            return this;
          }
          var mofd = this._hour * LocalTime2.MINUTES_PER_HOUR + this._minute;
          var newMofd = MathUtil.intMod(MathUtil.intMod(minutesToAdd, LocalTime2.MINUTES_PER_DAY) + mofd + LocalTime2.MINUTES_PER_DAY, LocalTime2.MINUTES_PER_DAY);
          if (mofd === newMofd) {
            return this;
          }
          var newHour = MathUtil.intDiv(newMofd, LocalTime2.MINUTES_PER_HOUR);
          var newMinute = MathUtil.intMod(newMofd, LocalTime2.MINUTES_PER_HOUR);
          return new LocalTime2(newHour, newMinute, this._second, this._nano);
        };
        _proto.plusSeconds = function plusSeconds(secondsToAdd) {
          if (secondsToAdd === 0) {
            return this;
          }
          var sofd = this._hour * LocalTime2.SECONDS_PER_HOUR + this._minute * LocalTime2.SECONDS_PER_MINUTE + this._second;
          var newSofd = MathUtil.intMod(MathUtil.intMod(secondsToAdd, LocalTime2.SECONDS_PER_DAY) + sofd + LocalTime2.SECONDS_PER_DAY, LocalTime2.SECONDS_PER_DAY);
          if (sofd === newSofd) {
            return this;
          }
          var newHour = MathUtil.intDiv(newSofd, LocalTime2.SECONDS_PER_HOUR);
          var newMinute = MathUtil.intMod(MathUtil.intDiv(newSofd, LocalTime2.SECONDS_PER_MINUTE), LocalTime2.MINUTES_PER_HOUR);
          var newSecond = MathUtil.intMod(newSofd, LocalTime2.SECONDS_PER_MINUTE);
          return new LocalTime2(newHour, newMinute, newSecond, this._nano);
        };
        _proto.plusNanos = function plusNanos(nanosToAdd) {
          if (nanosToAdd === 0) {
            return this;
          }
          var nofd = this.toNanoOfDay();
          var newNofd = MathUtil.intMod(MathUtil.intMod(nanosToAdd, LocalTime2.NANOS_PER_DAY) + nofd + LocalTime2.NANOS_PER_DAY, LocalTime2.NANOS_PER_DAY);
          if (nofd === newNofd) {
            return this;
          }
          var newHour = MathUtil.intDiv(newNofd, LocalTime2.NANOS_PER_HOUR);
          var newMinute = MathUtil.intMod(MathUtil.intDiv(newNofd, LocalTime2.NANOS_PER_MINUTE), LocalTime2.MINUTES_PER_HOUR);
          var newSecond = MathUtil.intMod(MathUtil.intDiv(newNofd, LocalTime2.NANOS_PER_SECOND), LocalTime2.SECONDS_PER_MINUTE);
          var newNano = MathUtil.intMod(newNofd, LocalTime2.NANOS_PER_SECOND);
          return new LocalTime2(newHour, newMinute, newSecond, newNano);
        };
        _proto._minusUnit = function _minusUnit(amountToSubtract, unit) {
          requireNonNull(unit, "unit");
          return this._plusUnit(-1 * amountToSubtract, unit);
        };
        _proto.minusHours = function minusHours(hoursToSubtract) {
          return this.plusHours(-1 * MathUtil.intMod(hoursToSubtract, LocalTime2.HOURS_PER_DAY));
        };
        _proto.minusMinutes = function minusMinutes(minutesToSubtract) {
          return this.plusMinutes(-1 * MathUtil.intMod(minutesToSubtract, LocalTime2.MINUTES_PER_DAY));
        };
        _proto.minusSeconds = function minusSeconds(secondsToSubtract) {
          return this.plusSeconds(-1 * MathUtil.intMod(secondsToSubtract, LocalTime2.SECONDS_PER_DAY));
        };
        _proto.minusNanos = function minusNanos(nanosToSubtract) {
          return this.plusNanos(-1 * MathUtil.intMod(nanosToSubtract, LocalTime2.NANOS_PER_DAY));
        };
        _proto.query = function query(_query) {
          requireNonNull(_query, "query");
          if (_query === TemporalQueries.precision()) {
            return ChronoUnit.NANOS;
          } else if (_query === TemporalQueries.localTime()) {
            return this;
          }
          if (_query === TemporalQueries.chronology() || _query === TemporalQueries.zoneId() || _query === TemporalQueries.zone() || _query === TemporalQueries.offset() || _query === TemporalQueries.localDate()) {
            return null;
          }
          return _query.queryFrom(this);
        };
        _proto.adjustInto = function adjustInto(temporal) {
          return temporal.with(LocalTime2.NANO_OF_DAY, this.toNanoOfDay());
        };
        _proto.until = function until(endExclusive, unit) {
          requireNonNull(endExclusive, "endExclusive");
          requireNonNull(unit, "unit");
          var end = LocalTime2.from(endExclusive);
          if (unit instanceof ChronoUnit) {
            var nanosUntil = end.toNanoOfDay() - this.toNanoOfDay();
            switch (unit) {
              case ChronoUnit.NANOS:
                return nanosUntil;
              case ChronoUnit.MICROS:
                return MathUtil.intDiv(nanosUntil, 1e3);
              case ChronoUnit.MILLIS:
                return MathUtil.intDiv(nanosUntil, 1e6);
              case ChronoUnit.SECONDS:
                return MathUtil.intDiv(nanosUntil, LocalTime2.NANOS_PER_SECOND);
              case ChronoUnit.MINUTES:
                return MathUtil.intDiv(nanosUntil, LocalTime2.NANOS_PER_MINUTE);
              case ChronoUnit.HOURS:
                return MathUtil.intDiv(nanosUntil, LocalTime2.NANOS_PER_HOUR);
              case ChronoUnit.HALF_DAYS:
                return MathUtil.intDiv(nanosUntil, 12 * LocalTime2.NANOS_PER_HOUR);
            }
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
          return unit.between(this, end);
        };
        _proto.atDate = function atDate(date) {
          return LocalDateTime.of(date, this);
        };
        _proto.atOffset = function atOffset(offset) {
          return OffsetTime.of(this, offset);
        };
        _proto.toSecondOfDay = function toSecondOfDay() {
          var total = this._hour * LocalTime2.SECONDS_PER_HOUR;
          total += this._minute * LocalTime2.SECONDS_PER_MINUTE;
          total += this._second;
          return total;
        };
        _proto.toNanoOfDay = function toNanoOfDay() {
          var total = this._hour * LocalTime2.NANOS_PER_HOUR;
          total += this._minute * LocalTime2.NANOS_PER_MINUTE;
          total += this._second * LocalTime2.NANOS_PER_SECOND;
          total += this._nano;
          return total;
        };
        _proto.compareTo = function compareTo(other) {
          requireNonNull(other, "other");
          requireInstance(other, LocalTime2, "other");
          var cmp = MathUtil.compareNumbers(this._hour, other._hour);
          if (cmp === 0) {
            cmp = MathUtil.compareNumbers(this._minute, other._minute);
            if (cmp === 0) {
              cmp = MathUtil.compareNumbers(this._second, other._second);
              if (cmp === 0) {
                cmp = MathUtil.compareNumbers(this._nano, other._nano);
              }
            }
          }
          return cmp;
        };
        _proto.isAfter = function isAfter(other) {
          return this.compareTo(other) > 0;
        };
        _proto.isBefore = function isBefore(other) {
          return this.compareTo(other) < 0;
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof LocalTime2) {
            return this._hour === other._hour && this._minute === other._minute && this._second === other._second && this._nano === other._nano;
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          var nod = this.toNanoOfDay();
          return MathUtil.hash(nod);
        };
        _proto.toString = function toString() {
          var buf = "";
          var hourValue = this._hour;
          var minuteValue = this._minute;
          var secondValue = this._second;
          var nanoValue = this._nano;
          buf += hourValue < 10 ? "0" : "";
          buf += hourValue;
          buf += minuteValue < 10 ? ":0" : ":";
          buf += minuteValue;
          if (secondValue > 0 || nanoValue > 0) {
            buf += secondValue < 10 ? ":0" : ":";
            buf += secondValue;
            if (nanoValue > 0) {
              buf += ".";
              if (MathUtil.intMod(nanoValue, 1e6) === 0) {
                buf += ("" + (MathUtil.intDiv(nanoValue, 1e6) + 1e3)).substring(1);
              } else if (MathUtil.intMod(nanoValue, 1e3) === 0) {
                buf += ("" + (MathUtil.intDiv(nanoValue, 1e3) + 1e6)).substring(1);
              } else {
                buf += ("" + (nanoValue + 1e9)).substring(1);
              }
            }
          }
          return buf;
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        _proto.format = function format(formatter) {
          requireNonNull(formatter, "formatter");
          return formatter.format(this);
        };
        return LocalTime2;
      }(Temporal);
      function _init$3() {
        LocalTime.HOURS = [];
        for (var hour = 0; hour < 24; hour++) {
          LocalTime.of(hour, 0, 0, 0);
        }
        LocalTime.MIN = LocalTime.HOURS[0];
        LocalTime.MAX = new LocalTime(23, 59, 59, 999999999);
        LocalTime.MIDNIGHT = LocalTime.HOURS[0];
        LocalTime.NOON = LocalTime.HOURS[12];
        LocalTime.FROM = createTemporalQuery("LocalTime.FROM", function(temporal) {
          return LocalTime.from(temporal);
        });
      }
      LocalTime.HOURS_PER_DAY = 24;
      LocalTime.MINUTES_PER_HOUR = 60;
      LocalTime.MINUTES_PER_DAY = LocalTime.MINUTES_PER_HOUR * LocalTime.HOURS_PER_DAY;
      LocalTime.SECONDS_PER_MINUTE = 60;
      LocalTime.SECONDS_PER_HOUR = LocalTime.SECONDS_PER_MINUTE * LocalTime.MINUTES_PER_HOUR;
      LocalTime.SECONDS_PER_DAY = LocalTime.SECONDS_PER_HOUR * LocalTime.HOURS_PER_DAY;
      LocalTime.MILLIS_PER_DAY = LocalTime.SECONDS_PER_DAY * 1e3;
      LocalTime.MICROS_PER_DAY = LocalTime.SECONDS_PER_DAY * 1e6;
      LocalTime.NANOS_PER_SECOND = 1e9;
      LocalTime.NANOS_PER_MINUTE = LocalTime.NANOS_PER_SECOND * LocalTime.SECONDS_PER_MINUTE;
      LocalTime.NANOS_PER_HOUR = LocalTime.NANOS_PER_MINUTE * LocalTime.MINUTES_PER_HOUR;
      LocalTime.NANOS_PER_DAY = LocalTime.NANOS_PER_HOUR * LocalTime.HOURS_PER_DAY;
      var NANOS_PER_MILLI = 1e6;
      var Instant = function(_Temporal) {
        _inheritsLoose(Instant2, _Temporal);
        Instant2.now = function now(clock) {
          if (clock === void 0) {
            clock = Clock.systemUTC();
          }
          return clock.instant();
        };
        Instant2.ofEpochSecond = function ofEpochSecond(epochSecond, nanoAdjustment) {
          if (nanoAdjustment === void 0) {
            nanoAdjustment = 0;
          }
          var secs = epochSecond + MathUtil.floorDiv(nanoAdjustment, LocalTime.NANOS_PER_SECOND);
          var nos = MathUtil.floorMod(nanoAdjustment, LocalTime.NANOS_PER_SECOND);
          return Instant2._create(secs, nos);
        };
        Instant2.ofEpochMilli = function ofEpochMilli(epochMilli) {
          var secs = MathUtil.floorDiv(epochMilli, 1e3);
          var mos = MathUtil.floorMod(epochMilli, 1e3);
          return Instant2._create(secs, mos * 1e6);
        };
        Instant2.ofEpochMicro = function ofEpochMicro(epochMicro) {
          var secs = MathUtil.floorDiv(epochMicro, 1e6);
          var mos = MathUtil.floorMod(epochMicro, 1e6);
          return Instant2._create(secs, mos * 1e3);
        };
        Instant2.from = function from(temporal) {
          try {
            var instantSecs = temporal.getLong(ChronoField.INSTANT_SECONDS);
            var nanoOfSecond = temporal.get(ChronoField.NANO_OF_SECOND);
            return Instant2.ofEpochSecond(instantSecs, nanoOfSecond);
          } catch (ex) {
            throw new DateTimeException("Unable to obtain Instant from TemporalAccessor: " + temporal + ", type " + typeof temporal, ex);
          }
        };
        Instant2.parse = function parse(text) {
          return DateTimeFormatter.ISO_INSTANT.parse(text, Instant2.FROM);
        };
        Instant2._create = function _create(seconds, nanoOfSecond) {
          if (seconds === 0 && nanoOfSecond === 0) {
            return Instant2.EPOCH;
          }
          return new Instant2(seconds, nanoOfSecond);
        };
        Instant2._validate = function _validate(seconds, nanoOfSecond) {
          if (seconds < Instant2.MIN_SECONDS || seconds > Instant2.MAX_SECONDS) {
            throw new DateTimeException("Instant exceeds minimum or maximum instant");
          }
          if (nanoOfSecond < 0 || nanoOfSecond > LocalTime.NANOS_PER_SECOND) {
            throw new DateTimeException("Instant exceeds minimum or maximum instant");
          }
        };
        function Instant2(seconds, nanoOfSecond) {
          var _this;
          _this = _Temporal.call(this) || this;
          Instant2._validate(seconds, nanoOfSecond);
          _this._seconds = MathUtil.safeToInt(seconds);
          _this._nanos = MathUtil.safeToInt(nanoOfSecond);
          return _this;
        }
        var _proto = Instant2.prototype;
        _proto.isSupported = function isSupported(fieldOrUnit) {
          if (fieldOrUnit instanceof ChronoField) {
            return fieldOrUnit === ChronoField.INSTANT_SECONDS || fieldOrUnit === ChronoField.NANO_OF_SECOND || fieldOrUnit === ChronoField.MICRO_OF_SECOND || fieldOrUnit === ChronoField.MILLI_OF_SECOND;
          }
          if (fieldOrUnit instanceof ChronoUnit) {
            return fieldOrUnit.isTimeBased() || fieldOrUnit === ChronoUnit.DAYS;
          }
          return fieldOrUnit != null && fieldOrUnit.isSupportedBy(this);
        };
        _proto.range = function range(field) {
          return _Temporal.prototype.range.call(this, field);
        };
        _proto.get = function get(field) {
          return this.getLong(field);
        };
        _proto.getLong = function getLong(field) {
          if (field instanceof ChronoField) {
            switch (field) {
              case ChronoField.NANO_OF_SECOND:
                return this._nanos;
              case ChronoField.MICRO_OF_SECOND:
                return MathUtil.intDiv(this._nanos, 1e3);
              case ChronoField.MILLI_OF_SECOND:
                return MathUtil.intDiv(this._nanos, NANOS_PER_MILLI);
              case ChronoField.INSTANT_SECONDS:
                return this._seconds;
            }
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.getFrom(this);
        };
        _proto.epochSecond = function epochSecond() {
          return this._seconds;
        };
        _proto.nano = function nano() {
          return this._nanos;
        };
        _proto._withField = function _withField(field, newValue) {
          requireNonNull(field, "field");
          if (field instanceof ChronoField) {
            field.checkValidValue(newValue);
            switch (field) {
              case ChronoField.MILLI_OF_SECOND: {
                var nval = newValue * NANOS_PER_MILLI;
                return nval !== this._nanos ? Instant2._create(this._seconds, nval) : this;
              }
              case ChronoField.MICRO_OF_SECOND: {
                var _nval = newValue * 1e3;
                return _nval !== this._nanos ? Instant2._create(this._seconds, _nval) : this;
              }
              case ChronoField.NANO_OF_SECOND:
                return newValue !== this._nanos ? Instant2._create(this._seconds, newValue) : this;
              case ChronoField.INSTANT_SECONDS:
                return newValue !== this._seconds ? Instant2._create(newValue, this._nanos) : this;
            }
            throw new UnsupportedTemporalTypeException("Unsupported field: " + field);
          }
          return field.adjustInto(this, newValue);
        };
        _proto.truncatedTo = function truncatedTo(unit) {
          requireNonNull(unit, "unit");
          if (unit === ChronoUnit.NANOS) {
            return this;
          }
          var unitDur = unit.duration();
          if (unitDur.seconds() > LocalTime.SECONDS_PER_DAY) {
            throw new DateTimeException("Unit is too large to be used for truncation");
          }
          var dur = unitDur.toNanos();
          if (MathUtil.intMod(LocalTime.NANOS_PER_DAY, dur) !== 0) {
            throw new DateTimeException("Unit must divide into a standard day without remainder");
          }
          var nod = MathUtil.intMod(this._seconds, LocalTime.SECONDS_PER_DAY) * LocalTime.NANOS_PER_SECOND + this._nanos;
          var result = MathUtil.intDiv(nod, dur) * dur;
          return this.plusNanos(result - nod);
        };
        _proto._plusUnit = function _plusUnit(amountToAdd, unit) {
          requireNonNull(amountToAdd, "amountToAdd");
          requireNonNull(unit, "unit");
          requireInstance(unit, TemporalUnit);
          if (unit instanceof ChronoUnit) {
            switch (unit) {
              case ChronoUnit.NANOS:
                return this.plusNanos(amountToAdd);
              case ChronoUnit.MICROS:
                return this.plusMicros(amountToAdd);
              case ChronoUnit.MILLIS:
                return this.plusMillis(amountToAdd);
              case ChronoUnit.SECONDS:
                return this.plusSeconds(amountToAdd);
              case ChronoUnit.MINUTES:
                return this.plusSeconds(MathUtil.safeMultiply(amountToAdd, LocalTime.SECONDS_PER_MINUTE));
              case ChronoUnit.HOURS:
                return this.plusSeconds(MathUtil.safeMultiply(amountToAdd, LocalTime.SECONDS_PER_HOUR));
              case ChronoUnit.HALF_DAYS:
                return this.plusSeconds(MathUtil.safeMultiply(amountToAdd, LocalTime.SECONDS_PER_DAY / 2));
              case ChronoUnit.DAYS:
                return this.plusSeconds(MathUtil.safeMultiply(amountToAdd, LocalTime.SECONDS_PER_DAY));
            }
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
          return unit.addTo(this, amountToAdd);
        };
        _proto.plusSeconds = function plusSeconds(secondsToAdd) {
          return this._plus(secondsToAdd, 0);
        };
        _proto.plusMillis = function plusMillis(millisToAdd) {
          return this._plus(MathUtil.intDiv(millisToAdd, 1e3), MathUtil.intMod(millisToAdd, 1e3) * NANOS_PER_MILLI);
        };
        _proto.plusNanos = function plusNanos(nanosToAdd) {
          return this._plus(0, nanosToAdd);
        };
        _proto.plusMicros = function plusMicros(microsToAdd) {
          return this._plus(MathUtil.intDiv(microsToAdd, 1e6), MathUtil.intMod(microsToAdd, 1e6) * 1e3);
        };
        _proto._plus = function _plus(secondsToAdd, nanosToAdd) {
          if (secondsToAdd === 0 && nanosToAdd === 0) {
            return this;
          }
          var epochSec = this._seconds + secondsToAdd;
          epochSec = epochSec + MathUtil.intDiv(nanosToAdd, LocalTime.NANOS_PER_SECOND);
          var nanoAdjustment = this._nanos + nanosToAdd % LocalTime.NANOS_PER_SECOND;
          return Instant2.ofEpochSecond(epochSec, nanoAdjustment);
        };
        _proto._minusUnit = function _minusUnit(amountToSubtract, unit) {
          return this._plusUnit(-1 * amountToSubtract, unit);
        };
        _proto.minusSeconds = function minusSeconds(secondsToSubtract) {
          return this.plusSeconds(secondsToSubtract * -1);
        };
        _proto.minusMillis = function minusMillis(millisToSubtract) {
          return this.plusMillis(-1 * millisToSubtract);
        };
        _proto.minusNanos = function minusNanos(nanosToSubtract) {
          return this.plusNanos(-1 * nanosToSubtract);
        };
        _proto.minusMicros = function minusMicros(microsToSubtract) {
          return this.plusMicros(-1 * microsToSubtract);
        };
        _proto.query = function query(_query) {
          requireNonNull(_query, "query");
          if (_query === TemporalQueries.precision()) {
            return ChronoUnit.NANOS;
          }
          if (_query === TemporalQueries.localDate() || _query === TemporalQueries.localTime() || _query === TemporalQueries.chronology() || _query === TemporalQueries.zoneId() || _query === TemporalQueries.zone() || _query === TemporalQueries.offset()) {
            return null;
          }
          return _query.queryFrom(this);
        };
        _proto.adjustInto = function adjustInto(temporal) {
          requireNonNull(temporal, "temporal");
          return temporal.with(ChronoField.INSTANT_SECONDS, this._seconds).with(ChronoField.NANO_OF_SECOND, this._nanos);
        };
        _proto.until = function until(endExclusive, unit) {
          requireNonNull(endExclusive, "endExclusive");
          requireNonNull(unit, "unit");
          var end = Instant2.from(endExclusive);
          if (unit instanceof ChronoUnit) {
            switch (unit) {
              case ChronoUnit.NANOS:
                return this._nanosUntil(end);
              case ChronoUnit.MICROS:
                return this._microsUntil(end);
              case ChronoUnit.MILLIS:
                return MathUtil.safeSubtract(end.toEpochMilli(), this.toEpochMilli());
              case ChronoUnit.SECONDS:
                return this._secondsUntil(end);
              case ChronoUnit.MINUTES:
                return MathUtil.intDiv(this._secondsUntil(end), LocalTime.SECONDS_PER_MINUTE);
              case ChronoUnit.HOURS:
                return MathUtil.intDiv(this._secondsUntil(end), LocalTime.SECONDS_PER_HOUR);
              case ChronoUnit.HALF_DAYS:
                return MathUtil.intDiv(this._secondsUntil(end), 12 * LocalTime.SECONDS_PER_HOUR);
              case ChronoUnit.DAYS:
                return MathUtil.intDiv(this._secondsUntil(end), LocalTime.SECONDS_PER_DAY);
            }
            throw new UnsupportedTemporalTypeException("Unsupported unit: " + unit);
          }
          return unit.between(this, end);
        };
        _proto._microsUntil = function _microsUntil(end) {
          var secsDiff = MathUtil.safeSubtract(end.epochSecond(), this.epochSecond());
          var totalMicros = MathUtil.safeMultiply(secsDiff, 1e6);
          return MathUtil.safeAdd(totalMicros, MathUtil.intDiv(end.nano() - this.nano(), 1e3));
        };
        _proto._nanosUntil = function _nanosUntil(end) {
          var secsDiff = MathUtil.safeSubtract(end.epochSecond(), this.epochSecond());
          var totalNanos = MathUtil.safeMultiply(secsDiff, LocalTime.NANOS_PER_SECOND);
          return MathUtil.safeAdd(totalNanos, end.nano() - this.nano());
        };
        _proto._secondsUntil = function _secondsUntil(end) {
          var secsDiff = MathUtil.safeSubtract(end.epochSecond(), this.epochSecond());
          var nanosDiff = end.nano() - this.nano();
          if (secsDiff > 0 && nanosDiff < 0) {
            secsDiff--;
          } else if (secsDiff < 0 && nanosDiff > 0) {
            secsDiff++;
          }
          return secsDiff;
        };
        _proto.atOffset = function atOffset(offset) {
          return OffsetDateTime.ofInstant(this, offset);
        };
        _proto.atZone = function atZone(zone) {
          return ZonedDateTime2.ofInstant(this, zone);
        };
        _proto.toEpochMilli = function toEpochMilli() {
          var millis = MathUtil.safeMultiply(this._seconds, 1e3);
          return millis + MathUtil.intDiv(this._nanos, NANOS_PER_MILLI);
        };
        _proto.compareTo = function compareTo(otherInstant) {
          requireNonNull(otherInstant, "otherInstant");
          requireInstance(otherInstant, Instant2, "otherInstant");
          var cmp = MathUtil.compareNumbers(this._seconds, otherInstant._seconds);
          if (cmp !== 0) {
            return cmp;
          }
          return this._nanos - otherInstant._nanos;
        };
        _proto.isAfter = function isAfter(otherInstant) {
          return this.compareTo(otherInstant) > 0;
        };
        _proto.isBefore = function isBefore(otherInstant) {
          return this.compareTo(otherInstant) < 0;
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          if (other instanceof Instant2) {
            return this.epochSecond() === other.epochSecond() && this.nano() === other.nano();
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          return MathUtil.hashCode(this._seconds, this._nanos);
        };
        _proto.toString = function toString() {
          return DateTimeFormatter.ISO_INSTANT.format(this);
        };
        _proto.toJSON = function toJSON() {
          return this.toString();
        };
        return Instant2;
      }(Temporal);
      function _init$2() {
        Instant.MIN_SECONDS = -31619119219200;
        Instant.MAX_SECONDS = 31494816403199;
        Instant.EPOCH = new Instant(0, 0);
        Instant.MIN = Instant.ofEpochSecond(Instant.MIN_SECONDS, 0);
        Instant.MAX = Instant.ofEpochSecond(Instant.MAX_SECONDS, 999999999);
        Instant.FROM = createTemporalQuery("Instant.FROM", function(temporal) {
          return Instant.from(temporal);
        });
      }
      var Clock = function() {
        function Clock2() {
        }
        Clock2.systemUTC = function systemUTC() {
          return new SystemClock(ZoneOffset.UTC);
        };
        Clock2.systemDefaultZone = function systemDefaultZone() {
          return new SystemClock(ZoneId2.systemDefault());
        };
        Clock2.system = function system(zone) {
          return new SystemClock(zone);
        };
        Clock2.fixed = function fixed(fixedInstant, zoneId) {
          return new FixedClock(fixedInstant, zoneId);
        };
        Clock2.offset = function offset(baseClock, duration) {
          return new OffsetClock(baseClock, duration);
        };
        var _proto = Clock2.prototype;
        _proto.millis = function millis() {
          abstractMethodFail("Clock.millis");
        };
        _proto.instant = function instant() {
          abstractMethodFail("Clock.instant");
        };
        _proto.zone = function zone() {
          abstractMethodFail("Clock.zone");
        };
        _proto.withZone = function withZone() {
          abstractMethodFail("Clock.withZone");
        };
        return Clock2;
      }();
      var SystemClock = function(_Clock) {
        _inheritsLoose(SystemClock2, _Clock);
        function SystemClock2(zone) {
          var _this;
          requireNonNull(zone, "zone");
          _this = _Clock.call(this) || this;
          _this._zone = zone;
          return _this;
        }
        var _proto2 = SystemClock2.prototype;
        _proto2.zone = function zone() {
          return this._zone;
        };
        _proto2.millis = function millis() {
          return (/* @__PURE__ */ new Date()).getTime();
        };
        _proto2.instant = function instant() {
          return Instant.ofEpochMilli(this.millis());
        };
        _proto2.equals = function equals(obj) {
          if (obj instanceof SystemClock2) {
            return this._zone.equals(obj._zone);
          }
          return false;
        };
        _proto2.withZone = function withZone(zone) {
          if (zone.equals(this._zone)) {
            return this;
          }
          return new SystemClock2(zone);
        };
        _proto2.toString = function toString() {
          return "SystemClock[" + this._zone.toString() + "]";
        };
        return SystemClock2;
      }(Clock);
      var FixedClock = function(_Clock2) {
        _inheritsLoose(FixedClock2, _Clock2);
        function FixedClock2(fixedInstant, zoneId) {
          var _this2;
          _this2 = _Clock2.call(this) || this;
          _this2._instant = fixedInstant;
          _this2._zoneId = zoneId;
          return _this2;
        }
        var _proto3 = FixedClock2.prototype;
        _proto3.instant = function instant() {
          return this._instant;
        };
        _proto3.millis = function millis() {
          return this._instant.toEpochMilli();
        };
        _proto3.zone = function zone() {
          return this._zoneId;
        };
        _proto3.toString = function toString() {
          return "FixedClock[]";
        };
        _proto3.equals = function equals(obj) {
          if (obj instanceof FixedClock2) {
            return this._instant.equals(obj._instant) && this._zoneId.equals(obj._zoneId);
          }
          return false;
        };
        _proto3.withZone = function withZone(zone) {
          if (zone.equals(this._zoneId)) {
            return this;
          }
          return new FixedClock2(this._instant, zone);
        };
        return FixedClock2;
      }(Clock);
      var OffsetClock = function(_Clock3) {
        _inheritsLoose(OffsetClock2, _Clock3);
        function OffsetClock2(baseClock, offset) {
          var _this3;
          _this3 = _Clock3.call(this) || this;
          _this3._baseClock = baseClock;
          _this3._offset = offset;
          return _this3;
        }
        var _proto4 = OffsetClock2.prototype;
        _proto4.zone = function zone() {
          return this._baseClock.zone();
        };
        _proto4.withZone = function withZone(zone) {
          if (zone.equals(this._baseClock.zone())) {
            return this;
          }
          return new OffsetClock2(this._baseClock.withZone(zone), this._offset);
        };
        _proto4.millis = function millis() {
          return this._baseClock.millis() + this._offset.toMillis();
        };
        _proto4.instant = function instant() {
          return this._baseClock.instant().plus(this._offset);
        };
        _proto4.equals = function equals(obj) {
          if (obj instanceof OffsetClock2) {
            return this._baseClock.equals(obj._baseClock) && this._offset.equals(obj._offset);
          }
          return false;
        };
        _proto4.toString = function toString() {
          return "OffsetClock[" + this._baseClock + "," + this._offset + "]";
        };
        return OffsetClock2;
      }(Clock);
      var ZoneOffsetTransition = function() {
        ZoneOffsetTransition2.of = function of(transition, offsetBefore, offsetAfter) {
          return new ZoneOffsetTransition2(transition, offsetBefore, offsetAfter);
        };
        function ZoneOffsetTransition2(transition, offsetBefore, offsetAfter) {
          requireNonNull(transition, "transition");
          requireNonNull(offsetBefore, "offsetBefore");
          requireNonNull(offsetAfter, "offsetAfter");
          if (offsetBefore.equals(offsetAfter)) {
            throw new IllegalArgumentException("Offsets must not be equal");
          }
          if (transition.nano() !== 0) {
            throw new IllegalArgumentException("Nano-of-second must be zero");
          }
          if (transition instanceof LocalDateTime) {
            this._transition = transition;
          } else {
            this._transition = LocalDateTime.ofEpochSecond(transition, 0, offsetBefore);
          }
          this._offsetBefore = offsetBefore;
          this._offsetAfter = offsetAfter;
        }
        var _proto = ZoneOffsetTransition2.prototype;
        _proto.instant = function instant() {
          return this._transition.toInstant(this._offsetBefore);
        };
        _proto.toEpochSecond = function toEpochSecond() {
          return this._transition.toEpochSecond(this._offsetBefore);
        };
        _proto.dateTimeBefore = function dateTimeBefore() {
          return this._transition;
        };
        _proto.dateTimeAfter = function dateTimeAfter() {
          return this._transition.plusSeconds(this.durationSeconds());
        };
        _proto.offsetBefore = function offsetBefore() {
          return this._offsetBefore;
        };
        _proto.offsetAfter = function offsetAfter() {
          return this._offsetAfter;
        };
        _proto.duration = function duration() {
          return Duration.ofSeconds(this.durationSeconds());
        };
        _proto.durationSeconds = function durationSeconds() {
          return this._offsetAfter.totalSeconds() - this._offsetBefore.totalSeconds();
        };
        _proto.isGap = function isGap() {
          return this._offsetAfter.totalSeconds() > this._offsetBefore.totalSeconds();
        };
        _proto.isOverlap = function isOverlap() {
          return this._offsetAfter.totalSeconds() < this._offsetBefore.totalSeconds();
        };
        _proto.isValidOffset = function isValidOffset(offset) {
          return this.isGap() ? false : this._offsetBefore.equals(offset) || this._offsetAfter.equals(offset);
        };
        _proto.validOffsets = function validOffsets() {
          if (this.isGap()) {
            return [];
          } else {
            return [this._offsetBefore, this._offsetAfter];
          }
        };
        _proto.compareTo = function compareTo(transition) {
          return this.instant().compareTo(transition.instant());
        };
        _proto.equals = function equals(other) {
          if (other === this) {
            return true;
          }
          if (other instanceof ZoneOffsetTransition2) {
            var d = other;
            return this._transition.equals(d._transition) && this._offsetBefore.equals(d.offsetBefore()) && this._offsetAfter.equals(d.offsetAfter());
          }
          return false;
        };
        _proto.hashCode = function hashCode() {
          return this._transition.hashCode() ^ this._offsetBefore.hashCode() ^ this._offsetAfter.hashCode() >>> 16;
        };
        _proto.toString = function toString() {
          return "Transition[" + (this.isGap() ? "Gap" : "Overlap") + " at " + this._transition.toString() + this._offsetBefore.toString() + " to " + this._offsetAfter + "]";
        };
        return ZoneOffsetTransition2;
      }();
      function _init$1() {
        TemporalQueries.ZONE_ID = createTemporalQuery("ZONE_ID", function(temporal) {
          return temporal.query(TemporalQueries.ZONE_ID);
        });
        TemporalQueries.CHRONO = createTemporalQuery("CHRONO", function(temporal) {
          return temporal.query(TemporalQueries.CHRONO);
        });
        TemporalQueries.PRECISION = createTemporalQuery("PRECISION", function(temporal) {
          return temporal.query(TemporalQueries.PRECISION);
        });
        TemporalQueries.OFFSET = createTemporalQuery("OFFSET", function(temporal) {
          if (temporal.isSupported(ChronoField.OFFSET_SECONDS)) {
            return ZoneOffset.ofTotalSeconds(temporal.get(ChronoField.OFFSET_SECONDS));
          }
          return null;
        });
        TemporalQueries.ZONE = createTemporalQuery("ZONE", function(temporal) {
          var zone = temporal.query(TemporalQueries.ZONE_ID);
          return zone != null ? zone : temporal.query(TemporalQueries.OFFSET);
        });
        TemporalQueries.LOCAL_DATE = createTemporalQuery("LOCAL_DATE", function(temporal) {
          if (temporal.isSupported(ChronoField.EPOCH_DAY)) {
            return LocalDate2.ofEpochDay(temporal.getLong(ChronoField.EPOCH_DAY));
          }
          return null;
        });
        TemporalQueries.LOCAL_TIME = createTemporalQuery("LOCAL_TIME", function(temporal) {
          if (temporal.isSupported(ChronoField.NANO_OF_DAY)) {
            return LocalTime.ofNanoOfDay(temporal.getLong(ChronoField.NANO_OF_DAY));
          }
          return null;
        });
      }
      var SystemDefaultZoneRules = function(_ZoneRules) {
        _inheritsLoose(SystemDefaultZoneRules2, _ZoneRules);
        function SystemDefaultZoneRules2() {
          return _ZoneRules.apply(this, arguments) || this;
        }
        var _proto = SystemDefaultZoneRules2.prototype;
        _proto.isFixedOffset = function isFixedOffset() {
          return false;
        };
        _proto.offsetOfInstant = function offsetOfInstant(instant) {
          var offsetInMinutes = new Date(instant.toEpochMilli()).getTimezoneOffset();
          return ZoneOffset.ofTotalMinutes(offsetInMinutes * -1);
        };
        _proto.offsetOfEpochMilli = function offsetOfEpochMilli(epochMilli) {
          var offsetInMinutes = new Date(epochMilli).getTimezoneOffset();
          return ZoneOffset.ofTotalMinutes(offsetInMinutes * -1);
        };
        _proto.offsetOfLocalDateTime = function offsetOfLocalDateTime(localDateTime) {
          var epochMilli = localDateTime.toEpochSecond(ZoneOffset.UTC) * 1e3;
          var offsetInMinutesBeforePossibleTransition = new Date(epochMilli).getTimezoneOffset();
          var epochMilliSystemZone = epochMilli + offsetInMinutesBeforePossibleTransition * 6e4;
          var offsetInMinutesAfterPossibleTransition = new Date(epochMilliSystemZone).getTimezoneOffset();
          return ZoneOffset.ofTotalMinutes(offsetInMinutesAfterPossibleTransition * -1);
        };
        _proto.validOffsets = function validOffsets(localDateTime) {
          return [this.offsetOfLocalDateTime(localDateTime)];
        };
        _proto.transition = function transition() {
          return null;
        };
        _proto.standardOffset = function standardOffset(instant) {
          return this.offsetOfInstant(instant);
        };
        _proto.daylightSavings = function daylightSavings() {
          this._throwNotSupported();
        };
        _proto.isDaylightSavings = function isDaylightSavings() {
          this._throwNotSupported();
        };
        _proto.isValidOffset = function isValidOffset(dateTime, offset) {
          return this.offsetOfLocalDateTime(dateTime).equals(offset);
        };
        _proto.nextTransition = function nextTransition() {
          this._throwNotSupported();
        };
        _proto.previousTransition = function previousTransition() {
          this._throwNotSupported();
        };
        _proto.transitions = function transitions() {
          this._throwNotSupported();
        };
        _proto.transitionRules = function transitionRules() {
          this._throwNotSupported();
        };
        _proto._throwNotSupported = function _throwNotSupported() {
          throw new DateTimeException("not supported operation");
        };
        _proto.equals = function equals(other) {
          if (this === other || other instanceof SystemDefaultZoneRules2) {
            return true;
          } else {
            return false;
          }
        };
        _proto.toString = function toString() {
          return "SYSTEM";
        };
        return SystemDefaultZoneRules2;
      }(ZoneRules);
      var SystemDefaultZoneId = function(_ZoneId) {
        _inheritsLoose(SystemDefaultZoneId2, _ZoneId);
        function SystemDefaultZoneId2() {
          var _this;
          _this = _ZoneId.call(this) || this;
          _this._rules = new SystemDefaultZoneRules();
          return _this;
        }
        var _proto = SystemDefaultZoneId2.prototype;
        _proto.rules = function rules() {
          return this._rules;
        };
        _proto.equals = function equals(other) {
          if (this === other) {
            return true;
          }
          return false;
        };
        _proto.id = function id() {
          return "SYSTEM";
        };
        return SystemDefaultZoneId2;
      }(ZoneId2);
      var ZoneIdFactory = function() {
        function ZoneIdFactory2() {
        }
        ZoneIdFactory2.systemDefault = function systemDefault() {
          return SYSTEM_DEFAULT_ZONE_ID_INSTANCE;
        };
        ZoneIdFactory2.getAvailableZoneIds = function getAvailableZoneIds() {
          return ZoneRulesProvider.getAvailableZoneIds();
        };
        ZoneIdFactory2.of = function of(zoneId) {
          requireNonNull(zoneId, "zoneId");
          if (zoneId === "Z") {
            return ZoneOffset.UTC;
          }
          if (zoneId.length === 1) {
            throw new DateTimeException("Invalid zone: " + zoneId);
          }
          if (StringUtil.startsWith(zoneId, "+") || StringUtil.startsWith(zoneId, "-")) {
            return ZoneOffset.of(zoneId);
          }
          if (zoneId === "UTC" || zoneId === "GMT" || zoneId === "GMT0" || zoneId === "UT") {
            return new ZoneRegion(zoneId, ZoneOffset.UTC.rules());
          }
          if (StringUtil.startsWith(zoneId, "UTC+") || StringUtil.startsWith(zoneId, "GMT+") || StringUtil.startsWith(zoneId, "UTC-") || StringUtil.startsWith(zoneId, "GMT-")) {
            var offset = ZoneOffset.of(zoneId.substring(3));
            if (offset.totalSeconds() === 0) {
              return new ZoneRegion(zoneId.substring(0, 3), offset.rules());
            }
            return new ZoneRegion(zoneId.substring(0, 3) + offset.id(), offset.rules());
          }
          if (StringUtil.startsWith(zoneId, "UT+") || StringUtil.startsWith(zoneId, "UT-")) {
            var _offset = ZoneOffset.of(zoneId.substring(2));
            if (_offset.totalSeconds() === 0) {
              return new ZoneRegion("UT", _offset.rules());
            }
            return new ZoneRegion("UT" + _offset.id(), _offset.rules());
          }
          if (zoneId === "SYSTEM") {
            return ZoneId2.systemDefault();
          }
          return ZoneRegion.ofId(zoneId);
        };
        ZoneIdFactory2.ofOffset = function ofOffset(prefix, offset) {
          requireNonNull(prefix, "prefix");
          requireNonNull(offset, "offset");
          if (prefix.length === 0) {
            return offset;
          }
          if (prefix === "GMT" || prefix === "UTC" || prefix === "UT") {
            if (offset.totalSeconds() === 0) {
              return new ZoneRegion(prefix, offset.rules());
            }
            return new ZoneRegion(prefix + offset.id(), offset.rules());
          }
          throw new IllegalArgumentException("Invalid prefix, must be GMT, UTC or UT: " + prefix);
        };
        ZoneIdFactory2.from = function from(temporal) {
          requireNonNull(temporal, "temporal");
          var obj = temporal.query(TemporalQueries.zone());
          if (obj == null) {
            throw new DateTimeException("Unable to obtain ZoneId from TemporalAccessor: " + temporal + ", type " + (temporal.constructor != null ? temporal.constructor.name : ""));
          }
          return obj;
        };
        return ZoneIdFactory2;
      }();
      var SYSTEM_DEFAULT_ZONE_ID_INSTANCE = null;
      function _init() {
        SYSTEM_DEFAULT_ZONE_ID_INSTANCE = new SystemDefaultZoneId();
        ZoneId2.systemDefault = ZoneIdFactory.systemDefault;
        ZoneId2.getAvailableZoneIds = ZoneIdFactory.getAvailableZoneIds;
        ZoneId2.of = ZoneIdFactory.of;
        ZoneId2.ofOffset = ZoneIdFactory.ofOffset;
        ZoneId2.from = ZoneIdFactory.from;
        ZoneOffset.from = ZoneIdFactory.from;
        ZoneId2.SYSTEM = SYSTEM_DEFAULT_ZONE_ID_INSTANCE;
        ZoneId2.UTC = ZoneOffset.ofTotalSeconds(0);
      }
      var isInit = false;
      function init() {
        if (isInit) {
          return;
        }
        isInit = true;
        _init$m();
        _init$n();
        _init$l();
        _init$k();
        _init$3();
        _init$f();
        _init$1();
        _init$j();
        _init$2();
        _init$5();
        _init$4();
        _init$a();
        _init$i();
        _init$b();
        _init$c();
        _init$h();
        _init$g();
        _init$7();
        _init();
        _init$9();
        _init$d();
        _init$e();
        _init$6();
        _init$8();
      }
      init();
      var ToNativeJsConverter = function() {
        function ToNativeJsConverter2(temporal, zone) {
          var zonedDateTime;
          if (temporal instanceof Instant) {
            this.instant = temporal;
            return;
          } else if (temporal instanceof LocalDate2) {
            zone = zone == null ? ZoneId2.systemDefault() : zone;
            zonedDateTime = temporal.atStartOfDay(zone);
          } else if (temporal instanceof LocalDateTime) {
            zone = zone == null ? ZoneId2.systemDefault() : zone;
            zonedDateTime = temporal.atZone(zone);
          } else if (temporal instanceof ZonedDateTime2) {
            if (zone == null) {
              zonedDateTime = temporal;
            } else {
              zonedDateTime = temporal.withZoneSameInstant(zone);
            }
          } else {
            throw new IllegalArgumentException("unsupported instance for convert operation:" + temporal);
          }
          this.instant = zonedDateTime.toInstant();
        }
        var _proto = ToNativeJsConverter2.prototype;
        _proto.toDate = function toDate() {
          return new Date(this.instant.toEpochMilli());
        };
        _proto.toEpochMilli = function toEpochMilli() {
          return this.instant.toEpochMilli();
        };
        return ToNativeJsConverter2;
      }();
      function convert(temporal, zone) {
        return new ToNativeJsConverter(temporal, zone);
      }
      function nativeJs(date, zone) {
        if (zone === void 0) {
          zone = ZoneId2.systemDefault();
        }
        requireNonNull(date, "date");
        requireNonNull(zone, "zone");
        if (date instanceof Date) {
          return Instant.ofEpochMilli(date.getTime()).atZone(zone);
        } else if (typeof date.toDate === "function" && date.toDate() instanceof Date) {
          return Instant.ofEpochMilli(date.toDate().getTime()).atZone(zone);
        }
        throw new IllegalArgumentException("date must be a javascript Date or a moment instance");
      }
      function bindUse(jsJoda) {
        var used = [];
        return function use2(fn) {
          if (!~used.indexOf(fn)) {
            fn(jsJoda);
            used.push(fn);
          }
          return jsJoda;
        };
      }
      var _ = {
        assert: assert$1,
        DateTimeBuilder,
        DateTimeParseContext,
        DateTimePrintContext,
        MathUtil,
        StringUtil,
        StringBuilder
      };
      var jsJodaExports = {
        _,
        convert,
        nativeJs,
        ArithmeticException,
        DateTimeException,
        DateTimeParseException,
        IllegalArgumentException,
        IllegalStateException,
        UnsupportedTemporalTypeException,
        NullPointerException,
        Clock,
        DayOfWeek,
        Duration,
        Instant,
        LocalDate: LocalDate2,
        LocalTime,
        LocalDateTime,
        OffsetTime,
        OffsetDateTime,
        Month,
        MonthDay,
        ParsePosition,
        Period,
        Year,
        YearConstants,
        YearMonth,
        ZonedDateTime: ZonedDateTime2,
        ZoneOffset,
        ZoneId: ZoneId2,
        ZoneRegion,
        ZoneOffsetTransition,
        ZoneRules,
        ZoneRulesProvider,
        ChronoLocalDate,
        ChronoLocalDateTime,
        ChronoZonedDateTime,
        IsoChronology,
        ChronoField,
        ChronoUnit,
        IsoFields,
        Temporal,
        TemporalAccessor,
        TemporalAdjuster,
        TemporalAdjusters,
        TemporalAmount,
        TemporalField,
        TemporalQueries,
        TemporalQuery,
        TemporalUnit,
        ValueRange,
        DateTimeFormatter,
        DateTimeFormatterBuilder,
        DecimalStyle,
        ResolverStyle,
        SignStyle,
        TextStyle
      };
      var use = bindUse(jsJodaExports);
      jsJodaExports.use = use;
      exports2.ArithmeticException = ArithmeticException;
      exports2.ChronoField = ChronoField;
      exports2.ChronoLocalDate = ChronoLocalDate;
      exports2.ChronoLocalDateTime = ChronoLocalDateTime;
      exports2.ChronoUnit = ChronoUnit;
      exports2.ChronoZonedDateTime = ChronoZonedDateTime;
      exports2.Clock = Clock;
      exports2.DateTimeException = DateTimeException;
      exports2.DateTimeFormatter = DateTimeFormatter;
      exports2.DateTimeFormatterBuilder = DateTimeFormatterBuilder;
      exports2.DateTimeParseException = DateTimeParseException;
      exports2.DayOfWeek = DayOfWeek;
      exports2.DecimalStyle = DecimalStyle;
      exports2.Duration = Duration;
      exports2.IllegalArgumentException = IllegalArgumentException;
      exports2.IllegalStateException = IllegalStateException;
      exports2.Instant = Instant;
      exports2.IsoChronology = IsoChronology;
      exports2.IsoFields = IsoFields;
      exports2.LocalDate = LocalDate2;
      exports2.LocalDateTime = LocalDateTime;
      exports2.LocalTime = LocalTime;
      exports2.Month = Month;
      exports2.MonthDay = MonthDay;
      exports2.NullPointerException = NullPointerException;
      exports2.OffsetDateTime = OffsetDateTime;
      exports2.OffsetTime = OffsetTime;
      exports2.ParsePosition = ParsePosition;
      exports2.Period = Period;
      exports2.ResolverStyle = ResolverStyle;
      exports2.SignStyle = SignStyle;
      exports2.Temporal = Temporal;
      exports2.TemporalAccessor = TemporalAccessor;
      exports2.TemporalAdjuster = TemporalAdjuster;
      exports2.TemporalAdjusters = TemporalAdjusters;
      exports2.TemporalAmount = TemporalAmount;
      exports2.TemporalField = TemporalField;
      exports2.TemporalQueries = TemporalQueries;
      exports2.TemporalQuery = TemporalQuery;
      exports2.TemporalUnit = TemporalUnit;
      exports2.TextStyle = TextStyle;
      exports2.UnsupportedTemporalTypeException = UnsupportedTemporalTypeException;
      exports2.ValueRange = ValueRange;
      exports2.Year = Year;
      exports2.YearConstants = YearConstants;
      exports2.YearMonth = YearMonth;
      exports2.ZoneId = ZoneId2;
      exports2.ZoneOffset = ZoneOffset;
      exports2.ZoneOffsetTransition = ZoneOffsetTransition;
      exports2.ZoneRegion = ZoneRegion;
      exports2.ZoneRules = ZoneRules;
      exports2.ZoneRulesProvider = ZoneRulesProvider;
      exports2.ZonedDateTime = ZonedDateTime2;
      exports2._ = _;
      exports2.convert = convert;
      exports2.nativeJs = nativeJs;
      exports2.use = use;
    });
  }
});

// src/index.ts
var src_exports = {};
__export(src_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(src_exports);
var import_pino2 = __toESM(require_pino());
var import_client_ecs = require("@aws-sdk/client-ecs");
var import_client_ecr = require("@aws-sdk/client-ecr");

// src/ignore.ts
var import_client_ssm = require("@aws-sdk/client-ssm");
var import_assert = __toESM(require("assert"));
var import_pino = __toESM(require_pino());
var import_core = __toESM(require_js_joda());
var logger = (0, import_pino.default)({ level: process.env.LOG_LEVEL ?? "debug" });
var ssmClient = new import_client_ssm.SSMClient();
(0, import_assert.default)(process.env.IGNORE_SPECS, "Ignore spec ARN is required");
(0, import_assert.default)(process.env.SNOOZED_CLUSTERS, "Snoozed cluster ARN is required");
var ignoreSpecARN = process.env.IGNORE_SPECS;
var snoozedClustersARN = process.env.SNOOZED_CLUSTERS;
var ignoreSpecs = async (arn) => {
  const getParameterResult = await ssmClient.send(
    new import_client_ssm.GetParameterCommand({
      Name: arn
    })
  );
  (0, import_assert.default)(
    getParameterResult?.Parameter?.Value,
    "Failed to fetch ignore list from Parameter Store"
  );
  return JSON.parse(getParameterResult.Parameter.Value);
};
function attributeMatch(attrs, key, value) {
  for (const attr of attrs) {
    if (attr.key === key) {
      return Array.isArray(value) ? value.some((v) => v === attr.value) : value === attr.value;
    }
  }
  return false;
}
function isFindingIgnoredBySpec(finding, spec) {
  if (finding?.name !== spec.name) {
    return false;
  }
  if (!finding.attributes) {
    return false;
  }
  if (!attributeMatch(finding.attributes, "package_name", spec.packageName)) {
    return false;
  }
  if (spec.packageVersion && !attributeMatch(finding.attributes, "package_version", spec.packageVersion)) {
    return false;
  }
  return true;
}
function isFindingIgnoredBySpecs(finding, specs) {
  for (const spec of specs) {
    if (isFindingIgnoredBySpec(finding, spec)) {
      return true;
    }
  }
  return false;
}
var isFindingIgnored = async (finding) => {
  const ignored = await ignoreSpecs(ignoreSpecARN);
  return isFindingIgnoredBySpecs(finding, ignored);
};
var snoozeList = async (parameterARN) => {
  const getParameterResult = await ssmClient.send(
    new import_client_ssm.GetParameterCommand({
      Name: parameterARN
    })
  );
  (0, import_assert.default)(
    getParameterResult?.Parameter?.Value,
    "Failed to fetch snooze list from Parameter Store"
  );
  return JSON.parse(getParameterResult.Parameter.Value);
};
var clusterSnoozed = async (cluster, snoozed) => {
  const today = import_core.ZonedDateTime.now(import_core.ZoneId.UTC);
  for (const snooze of snoozed) {
    const snoozeDate = import_core.LocalDate.parse(snooze.snoozeUntil).atStartOfDay().atZone(import_core.ZoneId.of("UTC"));
    if (snooze.cluster === cluster && snoozeDate.isAfter(today)) {
      logger.debug(
        `Cluster: ${snooze.cluster} is snoozed until: ${snoozeDate}. It is now: ${today}`
      );
      return true;
    }
  }
  return false;
};
var isClusterSnoozed = async (cluster) => {
  return clusterSnoozed(cluster, await snoozeList(snoozedClustersARN));
};

// src/index.ts
var import_client_sns = require("@aws-sdk/client-sns");
var import_assert2 = __toESM(require("assert"));
var defaultLogger = (0, import_pino2.default)({ level: process.env.LOG_LEVEL ?? "debug" });
var ecr = new import_client_ecr.ECR();
var ecs = new import_client_ecs.ECS();
var snsClient = new import_client_sns.SNSClient();
var getEnv = () => {
  const { ERROR_TOPIC_ARN, ALERT_SEVERITY_LEVEL, AWS_ACCOUNT_ID, AWS_REGION } = process.env;
  (0, import_assert2.default)(
    typeof ERROR_TOPIC_ARN === "string",
    "'ERROR_TOPIC_ARN' missing from environment"
  );
  (0, import_assert2.default)(
    typeof ALERT_SEVERITY_LEVEL === "string",
    "'ALERT_SEVERITY_LEVEL' missing from environment"
  );
  (0, import_assert2.default)(
    typeof AWS_ACCOUNT_ID === "string",
    "'AWS_ACCOUNT_ID' missing from environment"
  );
  (0, import_assert2.default)(
    typeof AWS_REGION === "string",
    "'AWS_REGION' missing from environment"
  );
  const severity = Severity[ALERT_SEVERITY_LEVEL];
  (0, import_assert2.default)(severity !== void 0, "Invalid 'ALERT_SEVERITY_LEVEL'");
  return {
    ERROR_TOPIC_ARN,
    ALERT_SEVERITY_LEVEL: severity,
    AWS_ACCOUNT_ID,
    AWS_REGION
  };
};
var Severity = /* @__PURE__ */ ((Severity2) => {
  Severity2[Severity2["UNDEFINED"] = 0] = "UNDEFINED";
  Severity2[Severity2["INFORMATIONAL"] = 1] = "INFORMATIONAL";
  Severity2[Severity2["LOW"] = 2] = "LOW";
  Severity2[Severity2["MEDIUM"] = 3] = "MEDIUM";
  Severity2[Severity2["HIGH"] = 4] = "HIGH";
  Severity2[Severity2["CRITICAL"] = 5] = "CRITICAL";
  return Severity2;
})(Severity || {});
var getContainerImages = async (ecsClient, cluster, logger2) => {
  const clusterTasks = await ecsClient.send(
    new import_client_ecs.ListTasksCommand({ cluster })
  );
  if (!clusterTasks.taskArns || clusterTasks.taskArns.length === 0) {
    logger2.info(`No tasks found for ECS cluster '${cluster}', skipping image collection.`);
    return /* @__PURE__ */ new Map();
  }
  if (clusterTasks.nextToken) {
    throw new Error("Doesn't support clusters with >100 tasks.");
  }
  const tasks = await ecsClient.send(
    new import_client_ecs.DescribeTasksCommand({
      cluster,
      tasks: clusterTasks.taskArns
    })
  );
  const images = /* @__PURE__ */ new Map();
  if (tasks.failures && tasks.failures.length > 0) {
    logger2.error(tasks.failures);
    throw new Error(
      `Encountered failures when describing tasks for ${cluster}`
    );
  }
  if (!tasks.tasks) {
    throw new Error(`No tasks found for cluster ${cluster}`);
  }
  for (const t of tasks.tasks) {
    (0, import_assert2.default)(t.containers, `No containers found for task ${t.taskDefinitionArn}`);
    for (const c of t.containers) {
      if (!images.has(c.image)) {
        images.set(c.image, /* @__PURE__ */ new Set());
      }
      logger2.debug(
        `Found image '${c.image}' for container '${c.containerArn}'`
      );
      images.get(c.image).add(t.taskDefinitionArn);
    }
  }
  return images;
};
var parseImageURI = async (ecrClient, logger2, uri) => {
  const match = uri.match(
    /\/([A-Za-z0-9_-]+).(sha256:[A-Fa-f0-9]{64}|[A-Fa-f0-9]{40})$/
  );
  if (match === null || typeof match[1] !== "string" || typeof match[2] !== "string") {
    throw new Error("Unable to parse ECR Image URI.");
  }
  const repo = match[1];
  const imageID = match[2];
  if (imageID.length === 71) {
    logger2.debug(`We got a digest in the image URI: ${imageID}`);
    return {
      repositoryName: repo,
      imageId: {
        imageDigest: imageID
      }
    };
  } else if (imageID.length === 40) {
    logger2.debug(`We got a tag in the image URI: ${imageID}`);
    const input = {
      repositoryName: repo,
      imageIds: [
        {
          imageTag: imageID
        }
      ]
    };
    const details = await ecrClient.send(new import_client_ecr.DescribeImagesCommand(input));
    (0, import_assert2.default)(
      details.imageDetails !== void 0 && details.imageDetails[0]?.imageDigest,
      `DescribeImagesCommand failed for repo ${repo} on image ${imageID}`
    );
    return {
      repositoryName: repo,
      imageId: {
        imageDigest: details.imageDetails[0].imageDigest,
        imageTag: imageID
      }
    };
  } else {
    throw new Error("Something went wrong with our regex");
  }
};
var updateImageScan = async (ecrClient, image, now, logger2) => {
  let findings = null;
  logger2.debug(
    `Looking for existing scan for 'repository ${image.repositoryName}' digest '${image.imageId.imageDigest}'`
  );
  try {
    findings = await ecrClient.send(
      new import_client_ecr.DescribeImageScanFindingsCommand(image)
    );
  } catch (e) {
    if (e instanceof import_client_ecr.ScanNotFoundException) {
      logger2.debug(`No existing scan found.`);
    } else {
      throw e;
    }
  }
  if (findings) {
    if (!findings.imageScanStatus?.status) {
      throw new Error("Expected image scan status to be set.");
    } else if (findings.imageScanStatus?.status === import_client_ecr.ScanStatus.COMPLETE) {
      if (!findings.imageScanFindings?.imageScanCompletedAt) {
        throw new Error(
          "Expected completed scan to have completion timestamp."
        );
      }
      const scanCompleted = findings.imageScanFindings.imageScanCompletedAt.getTime();
      logger2.debug(
        `Existing scan is ${(now.getTime() - scanCompleted) / 1e3} seconds old`
      );
      if (now.getTime() - scanCompleted < 864e5) {
        return findings;
      }
    }
  }
  logger2.debug(
    `Starting new scan for repository '${image.repositoryName}' digest '${image.imageId.imageDigest}'`
  );
  return await ecrClient.send(new import_client_ecr.StartImageScanCommand(image));
};
var scanNeedsAlert = async (ecrClient, cluster, request, alertLevel, logger2) => {
  logger2.debug(
    `Checking scan results for repo '${request.repositoryName}' digest '${request?.imageId?.imageDigest}'`
  );
  do {
    let findings = await ecrClient.send(
      new import_client_ecr.DescribeImageScanFindingsCommand(request)
    );
    if (findings?.imageScanFindings?.findings === void 0) {
      throw new Error(
        "Expected imageScanFindings.findings to be set, even if empty"
      );
    }
    for (const finding of findings.imageScanFindings.findings) {
      if (finding.severity === void 0) {
        throw new Error("Expected finding.severity to be set.");
      }
      if (Severity[finding.severity] < alertLevel) {
        return false;
      }
      if (await isFindingIgnored(finding)) {
        logger2.debug(`Ignoring vulnerability '${finding.name}'`);
      } else if (await isClusterSnoozed(cluster)) {
        logger2.debug(`Cluster '${cluster}' has been snoozed. Skipping alert`);
      } else {
        logger2.debug(`Found open vulnerability '${finding.name}'.`);
        return true;
      }
    }
    request.nextToken = findings.nextToken;
  } while (request.nextToken);
  return false;
};
function formatResults(cluster, alertResults) {
  const now = /* @__PURE__ */ new Date();
  const { AWS_ACCOUNT_ID, AWS_REGION } = getEnv();
  const sortedLevels = [
    import_client_ecr.FindingSeverity.CRITICAL,
    import_client_ecr.FindingSeverity.HIGH,
    import_client_ecr.FindingSeverity.MEDIUM,
    import_client_ecr.FindingSeverity.LOW,
    import_client_ecr.FindingSeverity.INFORMATIONAL,
    import_client_ecr.FindingSeverity.UNDEFINED
  ];
  const lines = [
    `An automated ECR scan on images currently in use by the ECS Cluster '${cluster}' was performed on ${now.toString()}.`,
    "",
    "The following images contained open vulnerabilities:"
  ];
  for (let [key, value] of alertResults) {
    lines.push(`  - ${key}`);
    if (value.results.imageScanFindings?.findingSeverityCounts) {
      const counts = value.results.imageScanFindings.findingSeverityCounts;
      lines.push("");
      lines.push(`    Number of findings, by severity category:`);
      for (let level of sortedLevels) {
        lines.push(`      - ${level}: ${counts[level]}`);
      }
    }
    lines.push("");
    lines.push(`    This image is used by the following tasks:`);
    for (const task of value.tasks) {
      lines.push(`      - ${task}`);
    }
    lines.push("");
    const scanUrl = `https://${AWS_REGION}.console.aws.amazon.com/ecr/repositories/private/${AWS_ACCOUNT_ID}/${value.image.repositoryName}/_/image/${value.image.imageId.imageDigest}/details?region=${AWS_REGION}`;
    lines.push(
      `    The full results of the scan can be found here: ${scanUrl}`
    );
    lines.push("");
  }
  return lines.join("\n");
}
var handler = async (event, context, callback) => {
  const logger2 = defaultLogger.child({
    functionArn: context.invokedFunctionArn,
    awsRequestId: context.awsRequestId
  });
  const { ERROR_TOPIC_ARN, ALERT_SEVERITY_LEVEL } = getEnv();
  const now = /* @__PURE__ */ new Date();
  const clusters = Array.isArray(event.cluster) ? event.cluster : [event.cluster];
  for (const cluster of clusters) {
    const images = await getContainerImages(ecs, cluster, logger2);
    if (images.size === 0) {
      continue;
    }
    const scanResults = /* @__PURE__ */ new Map();
    for (const imageURI of images.keys()) {
      const imageDescriptor = await parseImageURI(ecr, logger2, imageURI);
      const img = await updateImageScan(ecr, imageDescriptor, now, logger2);
      scanResults.set(imageURI, img);
    }
    const alertResults = /* @__PURE__ */ new Map();
    for (const imageURI of scanResults.keys()) {
      const imageDescriptor = await parseImageURI(ecr, logger2, imageURI);
      let result = scanResults.get(imageURI);
      if (result.imageScanStatus?.status !== import_client_ecr.ScanStatus.COMPLETE) {
        result = await (0, import_client_ecr.waitUntilImageScanComplete)(
          { client: ecr, maxWaitTime: 600 },
          imageDescriptor
        );
      }
      let needsAlert = await scanNeedsAlert(
        ecr,
        cluster,
        imageDescriptor,
        ALERT_SEVERITY_LEVEL,
        logger2
      );
      if (needsAlert) {
        alertResults.set(imageURI, {
          image: imageDescriptor,
          results: result,
          tasks: images.get(imageURI)
        });
      }
    }
    if (alertResults.size > 0) {
      logger2.info(formatResults(cluster, alertResults));
      await snsClient.send(
        new import_client_sns.PublishCommand({
          TopicArn: ERROR_TOPIC_ARN,
          Message: formatResults(cluster, alertResults)
        })
      );
    }
    logger2.info(
      `Completed scan of cluster '${cluster}' - ${images.size} images scanned, ${alertResults.size} contained vulnerabilities.`
    );
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
/*! Bundled license information:

@js-joda/core/dist/js-joda.js:
  (*! @version @js-joda/core - 5.6.5 *)
  (*! @copyright (c) 2015-present, Philipp Thürwächter, Pattrick Hüper & js-joda contributors *)
  (*! @copyright (c) 2007-present, Stephen Colebourne & Michael Nascimento Santos *)
  (*! @license BSD-3-Clause (see LICENSE in the root directory of this source tree) *)
  (**
   * @copyright (c) 2016, Philipp Thürwächter & Pattrick Hüper
   * @license BSD-3-Clause (see LICENSE in the root directory of this source tree)
   *)
  (**
   * @copyright (c) 2016, Philipp Thürwächter & Pattrick Hüper
   * @copyright (c) 2007-present, Stephen Colebourne & Michael Nascimento Santos
   * @license BSD-3-Clause (see LICENSE in the root directory of this source tree)
   *)
  (*
   * @copyright (c) 2016, Philipp Thürwächter & Pattrick Hüper
   * @copyright (c) 2007-present, Stephen Colebourne & Michael Nascimento Santos
   * @license BSD-3-Clause (see LICENSE in the root directory of this source tree)
   *)
  (*
   * @copyright (c) 2016, Philipp Thürwächter & Pattrick Hüper
   * @license BSD-3-Clause (see LICENSE.md in the root directory of this source tree)
   *)
  (*
   * @copyright (c) 2016, Philipp Thürwächter & Pattrick Hüper
   * @license BSD-3-Clause (see LICENSE in the root directory of this source tree)
   *)
  (*
   * @copyright (c) 2016, Philipp Thürwächter, Pattrick Hüper
   * @copyright (c) 2007-present, Stephen Colebourne & Michael Nascimento Santos
   * @license BSD-3-Clause (see LICENSE in the root directory of this source tree)
   *)
  (*
   * @copyright (c) 2015-present, Philipp Thürwächter, Pattrick Hüper & js-joda contributors
   * @license BSD-3-Clause (see LICENSE in the root directory of this source tree)
   *)
*/
