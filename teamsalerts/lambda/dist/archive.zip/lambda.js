"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var src_exports = {};
__export(src_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(src_exports);
var import_assert = __toESM(require("assert"));

// node_modules/streaming-iterables/dist/index.mjs
async function* _batch(size, iterable) {
  let dataBatch = [];
  for await (const data of iterable) {
    dataBatch.push(data);
    if (dataBatch.length === size) {
      yield dataBatch;
      dataBatch = [];
    }
  }
  if (dataBatch.length > 0) {
    yield dataBatch;
  }
}
function* _syncBatch(size, iterable) {
  let dataBatch = [];
  for (const data of iterable) {
    dataBatch.push(data);
    if (dataBatch.length === size) {
      yield dataBatch;
      dataBatch = [];
    }
  }
  if (dataBatch.length > 0) {
    yield dataBatch;
  }
}
function batch(size, iterable) {
  if (iterable === void 0) {
    return (curriedIterable) => batch(size, curriedIterable);
  }
  if (iterable[Symbol.asyncIterator]) {
    return _batch(size, iterable);
  }
  return _syncBatch(size, iterable);
}
var TIMEOUT = Symbol("TIMEOUT");
async function _consume(iterable) {
  for await (const _val of iterable) {
  }
}
function consume(iterable) {
  if (iterable[Symbol.asyncIterator]) {
    return _consume(iterable);
  }
  for (const _val of iterable) {
  }
}
function pipeline(firstFn, ...fns) {
  let previousFn = firstFn();
  for (const func of fns) {
    previousFn = func(previousFn);
  }
  return previousFn;
}
async function* _asyncTap(func, iterable) {
  for await (const val of iterable) {
    await func(val);
    yield val;
  }
}
function tap(func, iterable) {
  if (iterable === void 0) {
    return (curriedIterable) => _asyncTap(func, curriedIterable);
  }
  return _asyncTap(func, iterable);
}

// src/util.ts
var import_http = require("http");
var import_url = require("url");
var MAYFLOWER_DUCKLING_YELLOW = "F6C51B";
var DEFAULT_TOPIC_INFO = {
  emoji_uni_hex: "26AO",
  // ⚠️
  human_name: "Unnamed Topic"
};
var formatMessagePart = (value) => {
  if (typeof value === "object") {
    return "`" + JSON.stringify(value) + "`";
  }
  return `${value}`;
};
var getImageData = (emojiHex) => {
  const base64 = Buffer.from(
    `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" height="100">
      <title>emoji</title>
      <text y="85" style="width: 100%; height:100%; font-size: 100px">&#x${emojiHex};</text> 
    </svg>
  `
  ).toString("base64url");
  return `data:text/svg;base64,${base64}`;
};
var enrichWithMessageCards = async function* (records, topicMap, context) {
  for await (const record of records) {
    const { Message, MessageAttributes, Subject, Timestamp, TopicArn } = record.Sns;
    const mappedTopic = topicMap.find(
      ({ topic_arn }) => topic_arn.toUpperCase().trim() === TopicArn.toUpperCase().trim()
    );
    const { human_name, emoji_uni_hex } = mappedTopic != null ? mappedTopic : DEFAULT_TOPIC_INFO;
    const sections = new Array();
    let messageJson = null;
    try {
      messageJson = JSON.parse(Message);
    } catch (_) {
    }
    const activityTitle = Subject || `New message on **${TopicArn}**`;
    const activitySubtitle = new Date(Timestamp).toUTCString();
    const activityImage = getImageData(emoji_uni_hex);
    sections.push({
      activityTitle,
      activitySubtitle,
      activityImage,
      ...messageJson ? {
        text: "#### Message contents:",
        facts: Object.entries(messageJson).map(([key, value]) => ({
          name: key,
          value: formatMessagePart(value)
        }))
      } : {
        text: Message,
        facts: []
      }
    });
    if (MessageAttributes) {
      sections.push({
        startGroup: true,
        text: "#### Message attributes:",
        facts: Object.entries(MessageAttributes).map(
          ([name, { Type, Value }]) => ({
            name,
            value: `${Type} - ${Value}`
          })
        )
      });
    }
    const messageCard = {
      "@context": "https://schema.org/extensions",
      "@type": "MessageCard",
      summary: `SNS alert: ${TopicArn}`,
      themeColor: MAYFLOWER_DUCKLING_YELLOW,
      title: `SNS alert from ${human_name}`,
      sections,
      potentialAction: [
        {
          "@type": "OpenUri",
          name: `View Logs`,
          targets: [
            {
              os: "default",
              uri: `https://console.aws.amazon.com/cloudwatch/home#logEventViewer:group=${context.logGroupName};stream=${context.logStreamName};start=${/* @__PURE__ */ new Date()}`
            }
          ]
        },
        {
          "@type": "OpenUri",
          name: `View Monitoring`,
          targets: [
            {
              os: "default",
              uri: `https://console.aws.amazon.com/lambda/home#/functions/${context.functionName}/versions/${context.functionVersion}?tab=monitoring`
            }
          ]
        }
      ]
    };
    yield {
      record,
      hasMappedTopic: Boolean(mappedTopic),
      messageCard
    };
  }
};
var publishToTeams = async function* (records, webhookUrl) {
  const urlParts = (0, import_url.parse)(webhookUrl);
  for await (const chunk of batch(10, records)) {
    const promises = chunk.map((record) => {
      const postData = JSON.stringify(record.messageCard);
      const options = {
        hostname: urlParts.hostname,
        port: 80,
        path: urlParts.path,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(postData)
        }
      };
      return new Promise((resolve) => {
        const req = (0, import_http.request)(
          options,
          ({ statusCode }) => resolve({
            ...record,
            publishResult: {
              success: Boolean(
                statusCode && statusCode < 300 && statusCode >= 200
              ),
              error: null
            }
          })
        );
        req.on(
          "error",
          (e) => resolve({
            ...record,
            publishResult: {
              success: false,
              error: e.message
            }
          })
        );
        req.write(postData);
        req.end();
      });
    });
    const results = await Promise.all(promises);
    yield* results;
  }
};

// src/index.ts
var handler = async function(event, context) {
  (0, import_assert.default)(
    process.env.TEAMS_WEBHOOK_URL && typeof process.env.TEAMS_WEBHOOK_URL === "string"
  );
  (0, import_assert.default)(process.env.TOPIC_MAP && typeof process.env.TOPIC_MAP === "string");
  const webhookUrl = process.env.TEAMS_WEBHOOK_URL;
  const topicMap = JSON.parse(process.env.TOPIC_MAP);
  await pipeline(
    () => event.Records,
    (records) => enrichWithMessageCards(records, topicMap, context),
    tap(
      (record) => record.hasMappedTopic ? void 0 : console.warn(`Unmapped topic: ${record.record.Sns.TopicArn}`)
    ),
    (records) => publishToTeams(records, webhookUrl),
    tap(
      (record) => record.publishResult.success ? console.log(
        `Successfully published ${record.record.Sns.MessageId} from ${record.record.Sns.TopicArn} to Teams`
      ) : console.error(
        `Failed to publish ${record.record.Sns.MessageId} from ${record.record.Sns.TopicArn} to Teams: %s`,
        record.publishResult.error
      )
    ),
    consume
  );
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
